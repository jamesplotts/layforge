---
id: the-lions-burden
title: "The Lion's Burden"
level_range: "3-8"
pvp_policy: pve_only
maturity_tier: standard
image_maturity_tier: family_friendly
shared_knowledge: strict
tone:
  - tragic
  - morally complex
  - political
  - bittersweet
author: AI-generated
chapters:
  - id: the-legend
    title: "The Legend"
    level_range: "3-4"
    summary: "The party arrives in the borderlands where every tavern song and roadside statue celebrates Sir Gareth the Lionheart. A bard's off-key verse, a half-finished mural, and a curious granddaughter hint that the celebrated dragon-slaying may not be the tale the kingdom tells. The party is invited to Gareth's mountain keep, where the old hero receives them with warmth, pride, and a quiet insistence that his story is settled."
  - id: the-truth
    title: "The Truth"
    level_range: "4-5"
    summary: "Investigations at Dragon Crag and in the archive hall unravel the official account. Documents reveal that King Aldric I commissioned the killing, that Vermithrax was a guardian rather than a raider, and that the Heart of the Mountain was taken under the pretense of heroism. Sir Gareth catches wind of the inquiry and forces the party into an uncomfortable choice: accept a reward for silence or face the consequences of speaking."
  - id: the-confrontation
    title: "The Confrontation"
    level_range: "5-7"
    summary: "The party must decide how to act on what they know. Lady Elara's allegiance — to her grandfather or to the truth — becomes a fulcrum. Morwen discovers the Heart of the Mountain still lies buried beneath the keep, and its awakening triggers tremors that threaten the entire valley. Gareth, desperate and proud, will not let the truth be spoken without a fight — whether that fight is political, physical, or personal."
  - id: the-resolution
    title: "The Resolution"
    level_range: "7-8"
    summary: "The final act: the party confronts the buried truth and the stirring Heart of the Mountain. They may destroy the gem, return it to the scattered descendants of Vermithrax, seal it away, or let the legend stand. Each choice reshapes the region — the statue in the square, the songs in the taverns, the name Gareth carries in history — and the party walks away carrying the weight of what they chose to preserve or unmake."
---

## Overview

For three decades, the people of the borderlands have sung the same verse: Sir Gareth the Lionheart, who stood alone against a dragon in the mountains and gave his kingdom its peace. The statue in Stonemarket's square is worn smooth by generations of children climbing its paws. The tavern songs are set to the same melody in every village from the coast to the pass.

But legends are just stories that survived. And stories, left long enough, begin to rot at the edges — a word dropped here, a line of verse replaced there, until the shape of the truth peeks through the varnish. In *The Lion's Burden*, the party follows that rot. They meet the hero, sit at his table, drink his wine, and watch a man who has spent forty years believing his own legend look them in the eye and ask them, gently, to leave him alone.

This is not a campaign about slaying a dragon. It is about what it costs when the person who killed one was doing the wrong thing for the right reason — or the right thing for the wrong reason — and the kingdom built its identity on the act. The party will not find a monster to slay. They will find a man, a gem, and a choice that no amount of steel can simplify.

## Hooks

- **The Cracked Verse.** In the Wayfarer's Rest, a bard stumbles over a line in Gareth's ballad and mutters something that sounds like an apology. A drunk in the corner slams his tankard and says the line is *wrong*. The party can press, or let it go. If they press, the bard goes quiet and offers to lead them to a woman in Stonemarket who has been looking for exactly what they're asking about.

- **The Worn Paws.** A child in Stonemarket's square shows the party a crack in the statue's base. Behind the stone, someone has carved a second, smaller figure — not a dragon, but something with wings folded and a gem set in its chest. The child's mother pulls them away quickly. The statue was re-cut. The party can chip away the plaster and find what was covered.

- **A Granddaughter's Question.** Lady Elara, visiting the keep in the borderlands, asks the party a simple question over dinner: *Did the dragon attack the village, or did the village attack the dragon?* She is not trying to start a fight. She is genuinely, quietly unsure, and she wants an answer she can live with. The party's response shapes her trajectory for the rest of the campaign.

- **The Archive Request.** Morwen the Historian, working out of a cramped room in the Archive Hall, has posted a notice seeking "independent witnesses to the events at Dragon Crag, 74th year of the Aldric reign." The party's names are not on the list. She does not know who they are. She does not yet trust them. But she has documents, and she is waiting for someone brave enough to read them.
