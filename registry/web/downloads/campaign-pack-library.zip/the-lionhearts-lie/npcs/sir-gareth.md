---
id: sir-gareth
location: gareth-keep
stat_block_ref: "SRD Veteran (reflavored as a retired knight, no combat intent in Chapter 1)"
voice: "Measured, warm, slightly formal; speaks in complete sentences; deflects sharp questions with a laugh and a pour of wine; will go quiet, very quietly, when pressed about the dragon's eyes in the painting"
chapter: the-legend
---

Gareth is seventy-three. His hair is white, his hands are thick-knuckled and steady, and he carries himself with the particular posture of a man who spent forty years being told he was the strongest person in the room and has not entirely stopped believing it. He is generous in the way that old soldiers are generous: too much wine, too many stories, a hand on the shoulder that lingers a moment longer than comfort requires. He will ask the party about their homes, their families, their reasons for traveling. He will remember their names. He will use them, correctly, in the next sentence.

What he is not is a villain. He is a man who did a terrible thing at twenty-nine, told himself it was necessary, and has spent the remaining forty-four years making the story large enough that the truth does not fit inside it. He believes — genuinely, completely — that the dragon was a threat. He believes the village was in danger. He believes the king's commission was righteous. These beliefs are load-bearing. Remove one, and the architecture of his identity collapses, and he knows it, and he will not let you remove one.

In Chapter 1, Gareth is a host. He is a story. He is a man sitting across a table from the party, pouring wine and asking them to tell him about their lives. He is not yet the confrontation. He is not yet the choice. He is the legend, still intact, still warm, still convincing. The party's job in this chapter is to meet him, to sit in his keep, to notice the painting, to feel the weight of what he is asking them to believe. The truth is not his fault. The truth is not their fault. The truth is just there, under the wine and the rug and the apple tree, waiting.
