---
id: morwen-historian
location: archive-hall
stat_block_ref: "SRD Scholar (Commoner framework, no combat role)"
voice: "Precise, slightly impatient, speaks in full sentences with specific dates and sources; will correct the party's grammar without meaning to; goes very quiet when she is uncertain, which is rare"
chapter: the-legend
---

Morwen is fifty-one, sharp-featured, and has the particular stillness of a person who has been sitting at a desk for so long that standing up is a small physical effort. She works in a room at the back of the Archive Hall that she has arranged into a grid of files, cross-references, and half-finished arguments pinned to the walls in a dense, colorful web. The room smells of ink and cold tea. There is a chair. She will offer it. She will not sit in it herself.

Morwen has been researching the events at Dragon Crag for eleven years. She has found documents that contradict the official account, and she has found them in a way that makes her position complicated: the documents are in the royal archive, in a section she was granted access to for a unrelated project on agricultural tax records. She is not a traitor. She is not a spy. She is a woman who read a file, found a contradiction, and could not un-read it.

In Chapter 1, Morwen is not ready to share what she has. She will test the party. She will ask them what they believe about Gareth, about the dragon, about the kingdom's history. She will listen. She will ask follow-up questions. She will not, in this chapter, hand them the documents. She will, however, give them a question: *Did the dragon have wings, or did it have a gem in its chest?* The question is a door. Walking through it is the party's choice. And the party's answer — whether they are curious, skeptical, or dismissive — will determine how much Morwen trusts them in the chapters to come.
