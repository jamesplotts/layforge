---
id: lady-elara
location: gareth-keep
stat_block_ref: "SRD Commoner (noble framework, no combat role in Chapter 1)"
voice: "Soft-spoken, deliberate, chooses words carefully; asks questions instead of making statements; has a habit of touching the back of her neck when she is thinking; laughs too quickly, as if she is trying to cover a pause"
chapter: the-legend
---

Elara is twenty-six. She is not in a hurry. She speaks in a low voice, not because she is shy but because she has learned that a low voice is harder to interrupt, and she has spent her life being interrupted by louder, older, more confident people who have already decided what the answer is. She is Gareth's granddaughter. She loves him. These two facts are not in conflict, and she has spent the last two years trying to figure out why everyone else in the family acts as if they are.

Elara found something. She does not know what it is, exactly. It is a gap in the story — a place where the official account of the dragon-slaying does not quite fit the physical evidence she has seen at Dragon Crag, where the timeline does not quite add up, where her grandfather's account of the battle has a half-second of silence in it that he cannot explain and will not explain. She has not told anyone. She has not written it down. She has just been carrying it, and it is getting heavier, and she is running out of room in the house to keep it.

In Chapter 1, Elara is present at the keep. She is in the background, pouring tea, listening, not speaking unless spoken to. If the party asks her directly, she will answer honestly and briefly. If they ask her to take a side, she will not. She will say, *I don't know yet*, and she will mean it. The party's behavior around her — whether they are kind, whether they are patient, whether they treat her as a person or as a witness — will matter. Not yet. Not in this chapter. But the seed is planted.
