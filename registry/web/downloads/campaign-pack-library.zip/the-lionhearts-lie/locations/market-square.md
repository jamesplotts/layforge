---
id: market-square
connections:
  - crossroads-tavern
  - archive-hall
  - dragon-crag
chapter: the-legend
---

Stonemarket is a town built on a wide, flat shelf of limestone overlooking a river valley. It is prosperous, orderly, and proud. The market square dominates the center: a broad oval of packed flagstone where merchants set up stalls every morning, where children chase each other between the legs of draft horses, and where, at the north end, the statue of Sir Gareth the Lionheart stands on a plinth of river stone.

The statue is life-sized, a little larger. Gareth is carved mid-swing, sword raised, his face set in the stern determination of a man who knows the thing he is about to kill is the last evil standing between him and peace. At his feet, the carved dragon rears, jaws open, wings spread in a frozen scream. The stone is worn smooth where generations of children have climbed it, polished by hands that have never seen a dragon and never will. The inscription reads: *Here stands Gareth, who saved us. Remember.*

What the casual observer will not notice: the base of the statue has a seam, a hairline crack running along the plinth where the stone was re-cut. The plaster over the joint is fresh — too fresh for a three-decade-old monument. And if the party looks closely at the dragon's chest, the carved scales are slightly different in texture from the rest, as though someone added them later. Or removed them. The town folk will tell you the statue is perfect. They will tell you it has always been this way. They will change the subject.

To the south of the square, the Archive Hall sits in a long, low building with a row of narrow windows that glow amber after dark. To the east, a mule track winds out of town and up into the hills toward Dragon Crag. To the west, the coast road leads back to the Wayfarer's Rest and the open borderlands beyond.
