---
id: gareth-keep
connections:
  - crossroads-tavern
  - dragon-crag
  - market-square
chapter: the-legend
---

Gareth Keep is not a castle in the way a child's drawing would suggest. It is a cluster of stone buildings set into the side of a mountain, their walls thick enough that a hand pressed to the interior face cannot find the outer surface. There is no curtain wall, no moat, no gatehouse. The entrance is a simple iron door in the rock, and beyond it a narrow stair spirals up into a courtyard where a single apple tree grows in a square of packed earth.

The interior is warm. Too warm, by the look of the mountain outside. The hearths are kept burning in every room, the floors are covered in thick woven rugs, and the walls are lined with shelves of books, maps, and small glass vials that catch the firelight. The great hall, at the top of the stair, is long and low, with a table wide enough for twelve and high-backed chairs that have clearly been used by large men and then by smaller ones who inherited them. Above the mantle hangs a single painting: Gareth, younger, sword raised, a dragon below. The brushwork is competent. The expression in the painted dragon's eyes is not rage. It is not quite peace, either. It is something a viewer will have to sit with for a moment.

The keep is staffed by four servants, a kitchen hand, and a stable boy who is, it transpires, the nephew of the stable boy from twenty years ago, who is, in turn, the nephew of the stable boy from before that. They are loyal. They are not stupid. They will answer questions about the keep's layout, the routines, and what is stored in the cellar. They will not answer questions about the dragon. When asked, they will look at each other, and the conversation will end.

From the keep, the mountain pass road descends to the Wayfarer's Rest in roughly two days. A shorter, steeper trail on the east face drops to the basalt shelf of Dragon Crag in half a day, though the path is narrow and the drop is considerable. The coast road, via Stonemarket, is a full day's ride.
