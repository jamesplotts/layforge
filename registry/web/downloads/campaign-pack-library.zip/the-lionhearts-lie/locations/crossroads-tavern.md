---
id: crossroads-tavern
connections:
  - market-square
  - gareth-keep
  - dragon-crag
chapter: the-legend
---

The Wayfarer's Rest sits at the junction of three roads: the coast road, the mountain pass, and the old king's highway that runs east into Stonemarket. The building is low, wide, and smells of roasting garlic and woodsmoke, its front wall a patchwork of timber and plaster that has been repaired so many times it looks like a palimpsest of its own history. Inside, a single long bar stretches under a ceiling low enough that the rafters are within reaching distance. Stools are crowded, ale is spilled, and the air is thick with the particular noise of a place where everyone is trying to be heard.

Every table in the Wayfarer's Rest has heard the ballad of Gareth the Lionheart. It is sung by the resident bard, Brenna, on every evening, and the regulars know the words well enough to finish her lines. The melody is the same in every tavern in the borderlands — four bars, a turn, a chorus that builds. What the party may notice, if they listen past the third verse, is that Brenna's voice catches on one line. She stumbles, mutters a different phrase, and covers it with a laugh. The regulars pretend not to hear. The party might.

From the Wayfarer's Rest, the mountain pass road climbs roughly two days to Gareth Keep. The coast road leads south to Stonemarket, a day's walk. The old highway runs east and, through a narrow defile in the ridge, opens onto the scarred basalt plateau of Dragon Crag, where the "dragon attack" supposedly took place three decades ago. Travelers heading to Crag often stop at the tavern to stock up; the pass beyond is thin, cold, and unkind to unprepared feet.
