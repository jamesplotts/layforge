---
id: dragon-crag
connections:
  - crossroads-tavern
  - gareth-keep
  - market-square
chapter: the-legend
---

Dragon Crag is a broad shelf of dark basalt that juts out from the mountainside roughly three hundred feet above the valley floor. The name is local and unflattering: the basalt is riddled with fractures, the surface is broken and uneven, and the wind that funnels up from the valley below whistles through the cracks in a sound that the villagers describe, with varying degrees of exaggeration, as "dragon's breath." There is no dragon here. There has not been one, the official account says, for thirty years. The name persists because names do not update.

The site of the supposed dragon attack is marked by a cairn of flat stones at the center of the shelf, with a small iron plaque bolted to the largest rock: *In Memory of the Dragon of Crag, Slain by Sir Gareth the Lionheart, 74th Year of the Aldric Reign.* The plaque is clean. The cairn is not. The stones are loose, shifted, some of them recently moved. The plaque's iron bolt is a different alloy from the iron of the surrounding rock — newer, shinier. Someone replaced it. Or added it.

Beneath the cairn, in a shallow depression in the basalt that the wind has filled with sand and grit, the ground is different. The stone here is not basalt. It is older, darker, threaded with veins of pale quartz that glow faintly in the dark. The depression is roughly circular, maybe eight feet across, and the stone at its floor is warm to the touch. Warmer than it should be, given that there is no geothermal activity at this elevation. The party will not see the full truth here — not yet. But the warmth, the wrong stone, the fresh plaque: these are threads. Pull one, and it will take them to Morwen, to the Archive Hall, and to the question that Sir Gareth has spent thirty years not asking: *what was actually in the ground?*

From Dragon Crag, the mule track descends to Stonemarket in an hour. The steep trail on the north face climbs to Gareth Keep in half a day. The longer road, down through the valley and around the base of the mountain, leads to the Wayfarer's Rest in a full day.
