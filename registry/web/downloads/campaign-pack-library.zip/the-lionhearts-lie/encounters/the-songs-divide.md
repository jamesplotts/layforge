---
id: the-songs-divide
location: crossroads-tavern
involves:
  - sir-gareth
chapter: the-legend
---

The encounter begins with a song. Brenna, the tavern's resident bard, is performing the ballad of Gareth the Lionheart for the third time that evening, and the regulars are halfway through their drinks and well into their opinions about the lyrics. The song is four verses long. The first three are the standard: the dragon rises, the village trembles, Gareth rides to the mountain. The fourth verse is where the regulars start to get specific about the outcome, and it is in the fourth verse that Brenna stumbles.

She sings the line: *And the dragon fell, and the kingdom was whole.* Then, very quietly, almost under her breath: *And the dragon fell, and the whole kingdom stole.* She catches herself. She laughs. She finishes the song and takes her coins. The room goes back to its noise.

But the party heard. And in the corner, a drunk named Corric — a farmer who lives in the valley below Dragon Crag — slams his tankard and says, loud enough for the table next to him to hear: *That's not the verse. That's not the verse, and I know it, and I was there when the dragon came, and it didn't come at us, and I will say that to the end of my days if I have to.* The room goes quiet. Brenna does not look at him. Corric does not look at anyone. He finishes his drink and leaves without a word.

The party can press Brenna. She will be evasive, then honest, then guarded. She learned the line from her mother, who learned it from her mother, and she does not know where it started. She knows it is wrong. She does not know what the right verse is. She will offer to take the party to Stonemarket, to a woman in the Archive Hall who has been asking questions about the dragon for a long time. She will not go with them. She will say, *I sing the song. I don't write it. You go and read it. I'll be here when you get back."

This encounter is a test of the party's attention. If they hear the line, if they follow Brenna's offer, if they go to the Archive Hall, the story opens. If they do not, the night ends, the tavern empties, and the party rides out in the morning with a song stuck in their heads that they cannot quite get the words of right. The story will find them again. It always does. But the door will be a little harder to open next time.
