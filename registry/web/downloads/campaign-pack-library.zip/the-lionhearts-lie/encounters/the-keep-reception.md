---
id: the-keep-reception
location: gareth-keep
involves:
  - sir-gareth
  - lady-elara
chapter: the-legend
---

The party arrives at Gareth Keep at midday on the second day of the climb. The iron door opens before they knock — the servants have been watching the pass road, and they know the party is coming, because Brenna told them, or because the wind carried the sound of their horses up the trail, or because old men in mountain keeps know when someone is coming and why. Gareth is waiting at the top of the stair.

He is exactly as the stories describe, and exactly not as they do. The stories say a warrior. He is a man. The stories say a lion. He is a man who is a little tired. He extends his hand. He asks their names. He remembers them. He walks them into the great hall and gestures at the high-backed chairs and says, *Sit. Eat. Drink. I will not ask you why you are here until you have had your fill, because I have been on the receiving end of that question too many times, and I have learned that a full belly is the only honest answer to most of them."

The meal is good. The wine is better. Gareth talks. He asks about their homes, their trade, the roads they have traveled. He asks about their families with a specificity that is either genuine curiosity or a careful mapping of what they might lose. He does not ask them what they want from him. He does not need to. He knows what they want. Everyone who comes to the keep wants the same thing: the story. The real one. The one behind the painting. He will give them the story. It will be the good one. The one with the dragon and the village and the sword. It will be warm and confident and, in the small details, slightly off. The party will hear it the way you hear a song in a minor key when you expected major: the words are right, the melody is right, but something in the interval is a half-step flat, and you cannot quite put your finger on it.

Elara is there. She is in the background. She will pour the wine. She will clear the plates. She will not sit. If the party speaks to her, she will be brief and kind. If they ask her about her grandfather, she will say, *He is who he is,* and change the subject. If they ask her about the dragon, she will go quiet for exactly two seconds, and then say, *I was not there. I don't know what I know. I know that he was there, and that he is still here, and that those two facts are not the same thing."

After the meal, Gareth will offer the party rooms in the keep. He will say, *Stay the night. The pass road is bad in the dark, and I would not have you come to harm on my watch.* It is a genuine offer. It is also a way of keeping them in the keep, in his space, in the orbit of his story, for one more night. The party can accept. The party can decline and ride out into the dark. Either way, the morning will come, and the painting will be above the mantle, and the dragon's eyes will be the same, and the question will be the same, and the party will have to decide what to do with it.
