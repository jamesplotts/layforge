---
id: the-crag-evidence
location: dragon-crag
involves:
  - morwen-historian
chapter: the-legend
---

The party reaches Dragon Crag in the late afternoon, the light going amber and thin over the basalt shelf. The cairn is where the plaque says it is. The plaque is where the cairn says it is. Everything is in its place. Everything is slightly wrong.

The evidence is subtle. It is not a skeleton, not a skull, not a dramatic artifact. It is: the iron plaque is new, and the alloy is different, and the bolt is a different shape from the iron of the surrounding rock. The cairn stones have been moved, some of them recently, and the arrangement is slightly different from the one described in the Archive Hall's records (if the party has visited, or if they ask Morwen, who will confirm the discrepancy with a small, satisfied nod). The depression in the basalt is warm, and the stone at its floor is not basalt, and it is threaded with quartz that should not be there at this elevation, and it glows faintly in the gathering dark in a way that is not natural and not magical and not either, but something else, something the party does not have a word for yet.

Morwen is not here. She is in the Archive Hall, in her room, with her files and her cross-references and her cold tea. But she will be here in the morning, if the party tells her what they found. She will come with a journal and a set of questions, and she will crouch in the depression and press her palm to the warm stone and go very quiet, and she will say, *I need a few days to think about what this means,* and she will mean it, and she will not elaborate, and the party will have to wait.

The encounter is not a fight. It is not a puzzle with a lock and a key. It is a moment. The party is standing on a shelf of stone at sunset, and the ground is warm under their boots, and the plaque says *In Memory of the Dragon of Crag,* and the dragon's memory is not here, and the thing that is here is warm and old and patient, and the party has to decide: do they dig? Do they leave? Do they go back to the keep and tell Gareth what they found, or do they go to the Archive Hall and tell Morwen, or do they go to no one, and carry it, and let it sit in the back of their minds for a few days, getting heavier, getting warmer, getting closer to the point where it can no longer be ignored?

The DM should let the party sit with the evidence. Do not rush them. Do not resolve the mystery in this encounter. The stone is warm. The plaque is new. The quartz is glowing. The party knows something is wrong. That is enough. The next chapter will take them further. This one just has to plant the seed and let it grow in the dark.
