---
id: vault-wards-awakened
location: royal-vault
involves:
  - keeper-morwenna
chapter: the-quest
---

The vault is not empty. Aldric, in his final清醒 days, warded the chamber with a series of iron-bound constructs that were, in their day, a small army. Three hundred years of stillness have not killed them. They have *paused*. They are standing in the alcoves, in the corners, behind the throne, in postures that are almost human and not quite. They are SRD Skeletons in form, but wrong: the bone is too dark, too dense, and the eye sockets are not empty. They are *waiting*.

The wards do not attack on sight. They attack on *intent*. The moment the party reaches for the Crown, the moment a hand closes around the circlet, the moment the first whisper is heard — the wards wake. They are not fast. They are not clever. They are *thorough*. They will not try to flank. They will not feint. They will stand in a line and advance, and if one falls, the others will not stop, and if the party kills them all, the last one to fall will kneel, and will not shatter, and will hold its hands up in a gesture that is not surrender and is not attack and is something older and more specific. It is the gesture Aldric used to make to the Crown. *I see you. I am not leaving. I will be here when you are ready. I will be here when you are not."

Morwenna will be in the room. She will be standing very still, with her hands in front of her, and she will say, "You do not have to take it. You do not have to put it on. You can put the plate on the floor and walk away, and I will watch it for another year, and it will be fine, and it will be patient, and you will not have to hear it." She will say this while the skeleton is still kneeling. She will not move. She is not going to move. She has not moved in a very long time, and she is not going to start now. The party's decision, in this moment, is the first real choice of the campaign, and it is a choice between two kinds of fear: the fear of the Crown, and the fear of the woman who has been holding it together for thirty-one years, and who is, in this moment, the only reason the vault is still a vault and not a mouth.