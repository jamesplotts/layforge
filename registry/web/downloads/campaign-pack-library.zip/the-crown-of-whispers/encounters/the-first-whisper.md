---
id: the-first-whisper
location: royal-vault
involves:
  - lord-harrington
  - keeper-morwenna
chapter: the-quest
---

The first whisper is not a voice. It is a *correction*. The party has just made a decision — they are going to take the Crown, or they are going to put the plate down and leave, or they are going to ask Morwenna a question, or they are going to reach for the iron door to get back to the surface. Whatever the decision is, the Crown *corrects* it. Not loudly. Not dramatically. A single phrase, in a voice that is almost the party member's own, spoken in a tone of gentle, patient, *reasonable* agreement. "You know that's the right call." Or: "You'll want to see what's behind that door. Just one look." Or: "He's lying. You can tell. You've always been able to tell."

The whisper is tailored. It is specific to the character. A fighter hears about the enemy they've been trying to find. A healer hears about the patient they lost last season. A spellcaster hears about the scroll they can't quite finish. The Whisper does not offer power. It offers *continuation*. It offers the next step in a story the character is already telling themselves. And it is, for one moment, *true*. The vision it grants is real. The future it shows is genuine. The problem is not the lie. The problem is that it is the truth, and the truth is enough, and the character does not need the lie, because the Crown has already made the truth feel like a *promise*.

Harrington is not in the vault. He is not here. But his name is in the whisper, and it is mentioned in a way that is almost warm, almost *proud*, as if the Crown is introducing the party to a colleague. "He's been waiting for you. He's a reasonable man. You'll see. He pours good wine." The Whisper does not know it is manipulating. It does not need to. It is simply *accurate*, and accuracy, applied consistently, over time, to a person who is already tired and already afraid and already holding a crown, is indistinguishable from a leash.

Morwenna will be in the room. She will hear the whisper. She will not react. She has heard it four hundred times. She will pour more of the bad tea and say, "You don't have to listen. You don't have to listen, and it will not stop, and that is the thing, and that is the thing about it, and I am sorry, and I am not sorry, and the tea is bad but it is hot and you should drink it and then you should make your decision and I will not stop you and I will not help you and I will be here when you are done and I will be here when you are not and I will be here and I will be here and I will be here." She will stop. She will look at the Crown. She will look at the party. She will go back to the tea.