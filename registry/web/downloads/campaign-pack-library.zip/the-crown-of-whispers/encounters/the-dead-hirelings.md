---
id: the-dead-hirelings
location: thornfield-village
involves:
  - brunhilde-the-innkeeper
chapter: the-quest
---

The party learns about the previous hires through Brunhilde, but the encounter is not a simple conversation. When the party asks about the four, Brunhilde goes quiet, and the tavern goes quiet with her, and the other patrons stop what they are doing and stare at the floor. It is not fear. It is *respect*, for the dead, and a kind of superstitious caution about speaking their names too easily, because the last name spoken too easily was the name of the woman in the river.

The encounter unfolds in layers. Brunhilde will give the basics: four people, hired three years ago, went east, did not come back. The third one came back for two days. That is where the conversation changes. The third one came back *changed*. Brunhilde will describe it in practical terms: the eyes were wrong, the voice was a half-beat too fast, the way they held their cup, the way they looked at the other patrons as if they were *data*. The third one paid for their room in coins that had never been minted. The third one spoke to the wall. The third one walked into the river on the second morning, and Brunhilde was watching from the window, and the water did not splash.

This is not a combat encounter. It is a *weight* encounter. The party is meant to feel, for the first time, that the Crown is not an artifact. It is a *process*. It does not kill. It *changes*, and the change is so thorough that the person who walks into the river is not the person who walked out of the tavern, and the village is not sure which one died. Brunhilde will finish her drink, set the mug down, and say, "So. You're going east, then." It is not a question. It is a door closing.