---
id: brunhilde-the-innkeeper
location: thornfield-village
stat_block_ref: SRD Human Commoner
voice: blunt, practical, drinks while she talks, uses names freely even when the names are of dead people, has a slight accent that marks her as from the river villages
chapter: the-quest
---

Brunhilde is forty, broad-shouldered, and has the hands of a woman who has been breaking casks and hauling kegs for twenty years. She runs the Closed Eye because her husband ran it before the fever took him, and she will not sell it, and she will not let the estate buy it, and she will not let anyone from the terrace road sit at the back table, which is where Lord Harrington's people sat three years ago, which is where the silence still lives.

She knows what happened to the four hirelings. She saw the last one walk into the river. She will not say the woman's name, but she will say *she was kind,* which in Brunhilde's vocabulary is a eulogy. She will tell the party that Harrington did not come to ask about them. She will tell them that the road east is the wrong road, and then she will take the words back, because the road east is the only road, and the party is going to take it, and she is not going to pretend otherwise.

She is not a fighter. She is not a source of magical aid. She is a woman in a tavern who will pour you a drink, tell you the truth, and then go back to mopping the floor, because the floor needs mopping and the dead do not care about it and the living do. If the party asks her for help, the help she can give is a clean room, a hot meal, and the knowledge that someone in this village will remember that they came here, and that they were, for one night, not a transaction.