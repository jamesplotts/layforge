---
id: lord-harrington
location: harrington-estate
stat_block_ref: SRD Human Noble
voice: measured, warm, never raises his voice, speaks as if the other person is a useful tool he has not yet decided to discard
chapter: the-quest
---

Lord Harrington is not a monster. He is a man who has been outmaneuvered by his peers for fifteen years and has finally found a lever that makes him the most powerful person in every room he enters. The Crown of Whispers showed him, three years ago, that his chief rival was three months from a fatal fever. It showed him that the king's tax collector would look the other way. It showed him that the party standing in his dining hall would accept a quest that had already killed four other people, because the quest was *simple*, and the reward was *real*, and the man offering it was *reasonable*.

He does not want to be evil. He wants to be *right*. The Crown makes him right, or rather, it makes the futures in which he is the one who is right the only futures he can see, and he cannot look away from them. He knows the Crown corrupts. He knows the four hirelings. He knows the last one walked into a river. He is not troubled by this. He is *practical*. The Crown requires a holder. The holder must be someone he can find, track, and approach. A hired sword is perfect. A hired sword who is already in the field, already worn by the Crown, already paranoid enough to believe that handing the Crown over to a reasonable nobleman is the safest option available — that is not a sacrifice. That is a *transaction*.

He will be kind to the party. He will pour them wine and ask about their home and remember their names. He will be kind in the way that a man who has already decided what they are for is kind: specifically, without waste, with the precise warmth of a hand closing around a tool. The party should feel, by the end of the meal, that they have met a decent man. That is the most important thing he does. That is the trap.