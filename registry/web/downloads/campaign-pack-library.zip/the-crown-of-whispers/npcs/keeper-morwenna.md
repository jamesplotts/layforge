---
id: keeper-morwenna
location: ashenfall-ruins
stat_block_ref: SRD Human Commoner
voice: flat, tired, speaks in short declarative sentences, rarely uses contractions, has the cadence of someone who has been talking to no one for a very long time
chapter: the-quest
---

Morwenna is seventy-three years old and has been in this palace for thirty-one of them. She was a scholar at the university before the Crown's first modern holder lost his mind and killed two colleagues. She went to Ashenfall to retrieve the Crown. She could not bring herself to put it on, could not bring herself to leave it, and has been sitting in the cold with it ever since, watching it, waiting for someone who can do what she cannot.

She is not a warrior. She is not a mage. She is a tired woman with a sharp mind and a failing body, and she has spent three decades memorizing the patterns of the Whisper's behavior so that she can tell the party exactly when it is lying and exactly when it is, for one brief, terrible moment, telling the truth. She will tell them this. She will also tell them that the Crown can only be destroyed by a sacrifice: a willing wearer, killed while wearing it, the entity fed to the void through the death. She will say this without drama. She will say it the way you would say *the door is locked.*

She is afraid. She has been afraid for thirty-one years, and the fear has become a kind of architecture, a structure she lives inside, and it is load-bearing. If the party asks her why she has not left, the honest answer is that she does not know, and the less honest answer is that if she leaves, the Crown is alone in the vault, and a Crown that is alone is a Crown that is *patient*, and she does not want to be the one who was not there when it found its next holder. She will not say this. She will make more tea. The tea is bad. She is proud of it. She is the most human thing in Ashenfall, and the party should remember that when they are making their decisions and she is not there to remind them.