---
id: crown-of-whispers
title: "The Crown of Whispers"
level_range: "3-8"
pvp_policy: pve_only
maturity_tier: standard
image_maturity_tier: family_friendly
shared_knowledge: strict
tone:
  - dark
  - seductive
  - gothic
  - morally-complex
author: AI-generated
chapters:
  - id: the-quest
    title: "The Quest"
    level_range: "3-4"
    summary: "The party is hired by Lord Harrington to recover a sealed ward from the ruins of Ashenfall, a kingdom destroyed by its mad king. The Crown of Whispers is offered as reward. Upon claiming it, the holder begins to hear whispers and see impossible futures. Traces of Harrington's dead hirelings hint at the Crown's true hunger."
  - id: the-corruption-spreads
    title: "The Corruption Spreads"
    level_range: "4-5"
    summary: "The holder's paranoia deepens and the Crown's entity becomes aware of the party. Lord Harrington reveals his true plan: he needs someone else to wear the Crown long enough for a transfer ritual. The ghost of King Aldric III appears, offering to contain the Crown in exchange for service. The party must decide whether to trust a mad king's spirit."
  - id: the-escalation
    title: "The Escalation"
    level_range: "5-7"
    summary: "The Crown's power compounds with each use. Harrington's agents close in with a transfer ritual ready. Keeper Morwenna reveals the only destruction method: a willing wearer must be killed while wearing it, feeding the entity to the void. The Whisper speaks directly to the party, offering everything they desire in exchange for one more wearing."
  - id: the-resolution
    title: "The Resolution"
    level_range: "7-8"
    summary: "The final confrontation. The party chooses: keep the Crown and risk total corruption, destroy it through sacrifice, surrender it to Aldric's ghost, or hand it to Lord Harrington. Each path reshapes the region and leaves a permanent mark on the characters. The weight of the choice is the point."
---

# The Crown of Whispers

A kingdom fell because a king looked into tomorrow and decided he deserved it. The crown that showed him his tomorrow still sits on his rotting skull in a buried vault, and it is patient. It has been patient for three hundred years. It is very, very patient.

**The Crown of Whispers** is not a curse in the way a dungeon trap is a curse. It is *beautiful*. It is *useful*. The visions it grants are genuinely true, genuinely helpful, and genuinely addictive. The holder sees which negotiation will succeed, which blade will miss, which friend is already plotting betrayal. The whispers are gentle at first. They sound like the holder's own thoughts, only sharper. Only *colder*.

This campaign is built around a single question the party will ask themselves more and more often as the sessions go on: *is it worth it?* Lord Harrington will make it look like the obvious yes. The Crown will make it feel like the only sane choice. And the dead faces of his previous hirelings will make sure the party remembers that the answer is never yes. Not really.

The tone is gothic and seductive. The Crown should never feel like an obviously evil object. Its offers should be *tempting*, tailored to what each character actually wants. The DM's job is to make the party feel the genuine pull, then make them live with the consequences. There is no easy answer, and the pack is designed so that every path forward carries a real, lasting cost.

Pacing note: let the corruption land slowly. The first whisper should feel almost pleasant. By the time the party realizes what they are holding, they should already be angry about it. That is the design.

## Hooks

**For the player table:** "A noble in a well-furnished room offers you a fortune for a job that sounds almost too easy. Walk through a ruined city, open a vault, bring back a crown. He even has the seal for it ready. The only thing that feels wrong is that he keeps smiling before you've even left the table."

**For a character who wants power or knowledge:** The Crown doesn't just grant visions. It *teaches*. Strategy, persuasion, the hidden levers of a court. A session's worth of roleplay with it makes the holder genuinely, measurably better at the things they already do. That is the trap. You don't need to be corrupted to feel the loss.

**For a character who values loyalty or duty:** Lord Harrington is not a cartoon villain. He is a man who has been outmaneuvered by every rival in his barony for a decade and has finally found a tool that makes him the smartest person in every room. He will talk about his children. He will pour you wine. He will be *reasonable*. The party's job is to notice that he has already decided what they are for.

**For the DM running this:** The Crown is a mirror. Whatever your party is most afraid of losing, the Crown whispers about. Whatever they most want, the Crown shows them a future where they already have it. Write the whispers *before* the session. Make them specific. Make them kind. That is what makes this work.