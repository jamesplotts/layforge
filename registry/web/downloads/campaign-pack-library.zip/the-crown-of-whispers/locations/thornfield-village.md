---
id: thornfield-village
connections:
  - harrington-estate
  - whispering-forest
chapter: the-quest
---

Thornfield is a village of roughly two hundred souls, clustered around a single cobbled lane that runs from the river ford to the terrace road. The houses are well-kept but the gardens are overgrown, as if the villagers tend the structures and have quietly given up on the land. There is a chapel, a smithy, a tavern called the Closed Eye, and a small graveyard on the hillside where the plots are new and the stones are still pale against the dark soil. Four of the plots have no names. A fifth has a name scratched out.

The village has a relationship with Harrington's estate that is not quite fealty and not quite servitude. The villagers pay no taxes. They receive no protection. They do not look at the terrace road. When the party asks about Lord Harrington's previous hirelings — the four who went to Ashenfall and did not come back — the answers are careful. *They were hired, aye. They went east. They did not come back.* No one says *they went mad.* No one says *the last one came back for two days and then walked into the river.* But everyone says *Lord Harrington did not come to ask about them,* which in this village is the strangest thing anyone has said all week.

The tavern, the Closed Eye, is the social center. Brunhilde runs it. She is not afraid of the party, but she is afraid of what they are going to do, and she is afraid that it will be the same thing the last group did, which is to go east, come back changed, and then go east again. She will give them what she knows. She will not give them the name of the woman who came back for two days. That one, she is not ready to say out loud.

The road east leaves the lane at the far end of the village and dissolves into the tree line of the Whispering Forest within a quarter mile. The trees do not whisper. The villagers say that, but their eyes go to the canopy and stay there a moment too long.