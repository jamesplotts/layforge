---
id: ashenfall-ruins
connections:
  - whispering-forest
  - royal-vault
chapter: the-quest
---

Ashenfall was a city of perhaps ten thousand, built around a river that has since shifted its course by two miles. What remains is a skeleton of stone: the lower courses of towers, the flat roofs of a market district, the hollow shell of a great hall whose columns still stand in a broken circle. The buildings are not in ruins so much as they are in *suspension*. The stone is intact. The mortar is sound. There are no collapsed walls, no rubble, no scorch marks. The city simply stopped. Doors are closed. A chair is set by a table. A child's shoe is on a step. Three hundred years of weather and root growth have threaded through everything, but the architecture holds, as if the city is waiting for someone to come back and explain what happened.

The streets are wide and the sightlines are long, which means the party can see the royal quarter from a distance. The palace is the largest structure, a broad low building of pale stone with a single tower that has lost its roof. The tower's upper floor is open to the sky, and the wind through it produces a low, sustained note, almost a hum. The palace's entrance is unbarred. The doors are open. No one has locked them, because no one was here to lock them.

Morwenna is not at the vault. She is in the palace, in a room on the ground floor that was, in Aldric's day, a chapel. She has made a home here. Her bed is a pallet of straw and a wool blanket. Her food is dried and cold. Her eyes are the eyes of a woman who has been awake for a very long time and is not certain she can still sleep. She has been here for thirty-one years. She will tell the party this before they have finished walking through the front door. She will also tell them, in the same flat, tired voice, that the Crown is in the vault, that it is on the king's head, that she has watched it for three decades, and that she is not strong enough to break it. She will say this as if it is a fact about the weather. Then she will make tea. It is bad tea. She is proud of it. She is the most human thing in this place, and the party should remember that.

The vault is below the palace, behind the lead-and-silver plate that Harrington wants. The stairs are a spiral, narrow and deep, and the air at the bottom is cold and smells of old blood and older stone. The door to the vault is iron, banded, and locked from the inside. It is not locked from the outside. Morwenna will explain this. She will not explain why.