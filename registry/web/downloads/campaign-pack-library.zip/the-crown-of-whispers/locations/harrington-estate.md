---
id: harrington-estate
connections:
  - thornfield-village
chapter: the-quest
---

Harrington's estate sits on a broad terrace above the village of Thornfield, all white stone and manicured hedges, the kind of place that looks expensive and feels cold. The family crest is a closed eye over a key, and every window in the east wing has been boarded from the outside. Servants move quickly and speak in clipped sentences. No one in the household makes eye contact for longer than a second.

The party is received in the long dining hall, where Lord Harrington presides over a table set for two — his and one other, as if he expects only a single representative. He is a lean, pleasant man of about fifty, silver at the temples, with hands that do not tremble and a voice that never rises above conversational volume. He speaks of the quest as a minor inconvenience to him, a small errand in a ruined country that his tax collectors no longer visit. He produces the seal, the map, the list of what King Aldric vaulted, and he produces the Crown of Whispers — or rather, a description of it, and a promise. "You bring me the ward. I give you the crown. No one else in this barony has a claim. I have the letters."

The details are generous. Too generous. The seal is genuine. The map is accurate. The ward he wants is a real object in the vault — a lead-and-silver locking plate that, in Aldric's final days, sealed the innermost chamber. He genuinely needs it, because behind that plate is the Crown, and behind the Crown is the thing he has been circling for three years. He will not say this. He does not need to. He has the letters.

The room smells of beeswax and faintly of something bitter, like old ink. The windows face east, toward the forest, and the light through them has the flat, even quality of an overcast afternoon. A servant refills the party's wine without being asked. A second servant, younger, stands a little too close to the door.