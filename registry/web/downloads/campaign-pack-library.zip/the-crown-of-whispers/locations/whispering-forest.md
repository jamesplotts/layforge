---
id: whispering-forest
connections:
  - thornfield-village
  - ashenfall-ruins
chapter: the-quest
---

The forest is dense, old, and wrong in a way that is not immediately obvious. The trees are healthy. The light is fine. The birds are singing. But the paths do not connect the way they should. A track that appears to lead east will, after an hour, deposit you at the same bend in a stream you passed twenty minutes ago. The canopy is so thick that the sky is a suggestion, a rumor, a pale smear between branches. Sound behaves oddly here: a shout returns to you a half-second late, slightly lower in pitch, as if the forest is *considering* whether to let it through.

The forest is not hostile in the way a monster's lair is hostile. It is *indifferent*, and that is worse. It has been growing over the old roads of Ashenfall for three centuries. The ruins are in there, under the root and the loam, and the trees do not care that they are holding the bones of a kingdom in their architecture. Travel through is possible but slow. A party that does not use a map, a compass, or a magic item to track direction will lose at least a full day to the looping paths. The trees do not attack. They simply *are*, and they have been *being* for a very long time, and they are not going to move.

At the forest's heart, where the canopy breaks and the old royal road re-emerges as a wide slab of cracked flagstone, the air changes. It smells of iron and old stone. The birds stop. And if the party has already seen the Crown — if one of them has held it, even for a moment — the whispering starts. Not from the trees. From the metal. A faint, sweet, almost musical tone, like a finger drawn around the rim of a glass. It stops when they move away. It starts when they stop.

The forest is the first test. Not of strength. Of patience. The party that rushes through will lose time, lose morale, and arrive at Ashenfall exhausted and irritable. The party that slows down, tracks carefully, and treats the forest with respect will arrive rested and clear-headed. The Crown will notice the difference. It always does.