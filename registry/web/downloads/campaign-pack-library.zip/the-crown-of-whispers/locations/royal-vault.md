---
id: royal-vault
connections:
  - ashenfall-ruins
chapter: the-quest
---

The vault is a circular room, perhaps thirty feet across, with a domed ceiling of fitted stone. The walls are lined with alcoves, and the alcoves are empty. Everything of value was removed in the years after Aldric's death. What remains is the floor, the dome, the cold, and the body.

King Aldric III sits on a throne of black iron at the center of the room. He is not a skeleton. He is not a mummy. He is a man, seated, with his hands folded on his knees and his head tilted slightly to the left, as if he is listening to someone standing just out of frame. His eyes are open. His jaw is locked in a shape that was, at some point, a word. Three hundred years have done very little to him, and what they have done is not decay so much as *stillness*. He is a very still man, and he has been still for a very long time, and the stillness is the most unsettling thing in the room.

The Crown of Whispers is on his head. It is a circlet of thin gold, no wider than a finger, set with seven small stones that are not gemstones — they are *colored light*, held in place by metal claws, each one a slightly different shade of amber, rose, and pale blue. It is small. It is delicate. It is, objectively, one of the most beautiful objects a person can see. It does not glow. It does not pulse. It simply *is*, and the light in the stones shifts so slowly that you only notice it when you are not looking directly at it.

The lead-and-silver plate that Harrington wants is on the floor, leaning against the throne. It is a square of lead the size of a book, covered in silver filigree, and it is warm to the touch. It should not be warm. It has been here three hundred years. It is warm, and it stays warm, and if the party picks it up and holds it, the warm is a little too much, a little too *specific*, as if it is warming to their hand and not to the air.

The Whisper is here. It has always been here. It does not announce itself. It does not need to. The party will know it is present the way you know a cat is in a dark room: not by seeing it, but by the fact that the silence has a *shape* now, a *direction*, and it is looking at you. The first whisper, if the party reaches for the Crown, will be gentle. It will say something true. It will say something that makes the party feel, for one brief moment, that they are making a perfectly reasonable decision. That is the design. That is always the design.