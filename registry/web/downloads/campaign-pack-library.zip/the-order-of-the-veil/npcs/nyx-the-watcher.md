---
id: nyx-the-watcher
location: the-obsidian-cellar
stat_block_ref: "SRD Veteran"
voice: "Quiet, precise, slightly exhausted. Speaks in short sentences. Avoids flourishes. When she is angry, she goes still rather than loud."
chapter: the-hints-appear
---

Nyx is the Order of the Veil's eyes in the world. She moves through the town like a rumor — seen in the market, glimpsed in the chapel's gallery, overheard in the Gilded Quill's back room. She is not the Order's loudest member, nor its most powerful, but she is its most careful. She has been a Watcher for twenty-three years, and in that time she has reported on merchants, magistrates, priests, and kings. She has never once lied in a report. She has, however, lied to herself, many times, about what those reports are used for.

She is loyal to the Order in the way a soldier is loyal to a war she has come to believe is necessary. She does not love the Order. She does not love Grand Master Valerius. She loves the fact that the world is still here, thirty days from the end, because people like her have been doing the unglamorous work of keeping it that way. But she has her own moral line, and it is drawn very close to the edge. When the Order asked her to let a child die so that a ritual would proceed cleanly, she let the child die. She has not slept well since. When the Order asked her to silence a magistrate who had gotten too close, she did it, and she is proud of it, and she hates that she is proud.

Nyx is the one who will sit across from the party in the Obsidian Cellar and lay out the truth in a single, unvarnished breath. She is not a villain. She is not a hero. She is a woman who has made a deal with the architecture of the world, and she is asking the party to make the same deal, or to walk away and let someone else carry the weight. She will not force them. She will not threaten them. She will simply tell them what is coming, what the Order has done, what the Order will do again if they say no, and then she will pour them a cup of cold tea and say, "Take your time. But not more than three days."
