---
id: master-pellin
location: duskmarket-crossroads
stat_block_ref: "SRD Commoner"
voice: "Warm, a little too cheerful, speaks in proverbs. Laughs when he should be tense. His kindness is real but his eyes are calculating."
chapter: the-hints-appear
---

Master Pellin is a spice merchant who has run his stall in Duskmarket Crossroads for nineteen years. His stall is the best-stocked in the row: saffron, cardamom, dried rose petals, and a small selection of rare ground silvers that he claims are "for the connoisseur." He is round, red-faced, and perpetually smiling. He greets every customer by name, remembers their preferences, and will often slip an extra pinch of cinnamon into a stranger's purchase "because the world is hard enough without your tea being bland."

He is a member of the Order of the Veil, and he has been for eleven years. He joined because a friend introduced him, and the friend said, "It's a good group, and the work is necessary, and you'll never have to worry about your stall again." That was true, in the narrowest sense. The Order has, in fact, ensured that his stall has never been taxed, raided, or competed with. In return, he provides information. He listens to every conversation that happens within earshot of his stall. He reports them, every week, to a contact he has never met in person. He does not know what the information is used for. He does not ask. This is, he tells himself, the arrangement. He is a spice merchant, not a spy, not a killer, not a man who should have to know why a child in the village of Thornhallow disappeared three years ago and was never found.

Pellin is not dangerous. He is not a fighter. He is a man who has built a comfortable life on top of a foundation he has chosen not to examine, and the party's presence in his stall — their questions, their too-sharp eyes, the way they looked at the symbol on his stall's back wall — has started to crack that foundation. If the party speaks to him, he will be warm, generous, and evasive. If they press, he will become quiet, and his eyes will lose their cheer, and he will say, very softly, "You should not be asking that question here. Or anywhere. I am begging you."
