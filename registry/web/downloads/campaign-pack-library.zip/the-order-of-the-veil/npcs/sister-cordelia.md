---
id: sister-cordelia
location: veiled-chapel-of-ash
stat_block_ref: "SRD Priest"
voice: "Measured, liturgical, precise. Speaks as though every word is a small prayer. Rarely raises her voice. When she is frightened, she recites scripture under her breath."
chapter: the-hints-appear
---

Sister Cordelia is the chaplain of Saint Ashen and has been for thirty-one years. She is tall, grey-haired, and moves through her chapel with the quiet certainty of a woman who has long ago stopped being surprised by what the world contains. She tends the altar, maintains the bell, and performs the small rites of the parish: baptisms, last words, the occasional mending of a broken bone with prayer and steady hands. She is beloved by the town's folk. They trust her. They bring her their grief and their small ailments, and she gives them both a cup of tea and a blessing.

She is also the Order's keeper of the chapel, the woman who maintains the physical site where the Unveiling takes place. She does not attend the sessions. She does not ask what is discussed. She locks the doors, lights the violet candle, and steps back. This is her arrangement, and it has been her arrangement for twenty years. She knows the Order exists. She knows the cellar is there. She does not know what the Convergence is, or what Valerius has done, or why the bell rings three-strikes-and-seven. She knows that the Order has asked her to keep the chapel ready, and she has kept it ready, and she has told herself that this is a small and manageable sin, the sin of looking away.

On the night of the Unveiling, Sister Cordelia will be present, standing at the back of the nave with her hands folded. She will not speak to the party unless spoken to. If they ask her what is happening, she will cross herself, look at them with an expression that is half-fear and half-grief, and say, "I am sorry. I am so sorry I did not stop this. But I could not. I could not. The candle is already lit. The door is already locked. And I am only the one who keeps the wicks trimmed." If the party asks her to help them leave, she will hesitate for a very long time, and then she will unlock the back door. She will not say why. She will not look at them. She will be shaking.
