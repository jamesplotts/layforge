---
id: order-of-the-veil
title: "The Order of the Veil"
level_range: "3-8"
pvp_policy: pve_only
maturity_tier: standard
image_maturity_tier: family_friendly
shared_knowledge: strict
tone:
  - mysterious
  - morally complex
  - atmospheric
  - conspiratorial
  - bittersweet
author: "AI-generated"
chapters:
  - id: the-hints-appear
    title: "The Hints Appear"
    level_range: "3-4"
    summary: "The party stumbles into a web of coded messages, secret gestures, and a shadowy gathering. A woman called Nyx offers them a choice that will define the campaign: step inside the veil, or walk away and pretend the world is simpler than it is."
  - id: the-society-revealed
    title: "The Society Revealed"
    level_range: "4-6"
    summary: "The party learns the Order's true purpose — preventing the Convergence, a planar alignment that will let an ancient evil cross into this world. They discover the terrible measures the Order has taken to delay it, and must decide whether to join, expose, dismantle, or manipulate the society from within."
  - id: the-intrigue-and-attack
    title: "The Intrigue and the Attack"
    level_range: "5-7"
    summary: "Infiltration and open conflict. The party uncovers Grand Master Valerius's private preparation for the worst: a plan that may involve sacrificing an entire village. The Order turns its full weight against the party, and Valerius himself reveals that the Convergence has already begun — possibly accelerated by the party's own actions."
  - id: the-resolution
    title: "The Resolution"
    level_range: "7-8"
    summary: "The final confrontation — with the Order, with the Convergence, or with both at once. The party chooses the region's fate: dismantle the society, seize it, let it endure in secret, or forge an entirely new path to stop the evil that is coming. The aftermath reshapes the world they knew."
---

The world is thirty days from the end. The planes are aligning, the old barriers are thinning, and something that has waited since before the first cities were raised is pressing against the membrane of reality. No one knows this — except for a handful of people who met in a cellar a century ago and swore an oath that outlived empires.

The Order of the Veil is not a villainy. That is the first thing the party will learn, and the hardest lesson of the campaign. Grand Master Valerius, ancient and hollowed out by knowledge, has ordered the death of innocents, the puppeteering of kings, and the quiet erasure of witnesses — all to buy time. Lady Isolde Vane, once his most devoted student, now whispers that the Order has become the very thing it was founded to prevent: a power that controls, silences, and sacrifices. And Nyx, the Watcher, the one who will sit across a table from the party and slide a vial of ink and a cipher key across it, believes that the world deserves to know what is coming even if the knowledge breaks it.

The campaign is structured as a slow unraveling. Chapter one is a game of whispers and half-seen symbols. Chapter two is a game of moral architecture — the party must weigh a righteous goal against monstrous methods. Chapter three is a game of blades and broken trust. Chapter four is a game of choices with no clean answer. The DM should let the mystery breathe. Let the party feel the weight of each revelation. Let them argue among themselves before they argue with the Order. The most important question is never "will the Convergence happen?" but "what kind of people will we be when we stop it — or when we can't?"

## Hooks

- **The Merchant's Gesture.** A spice trader in the market crosses his wrists, taps his thumb twice, and a stranger three stalls away nods. The party noticed. The trader noticed them noticing. He smiles and says nothing, but he will remember their faces.
- **The Gilded Quill.** A tavern the party frequents has begun receiving a strange parcel each evening: a single black rose, a vial of indigo ink, and a note that reads only, *"The veil lifts on the full moon. Come or be left in the dark."* The tavern keeper is terrified.
- **The Chapel Bell.** The small chapel of Saint Ashen has begun ringing its bell at odd hours — three strikes, a pause, then seven. The parishioners think it's a broken mechanism. The party, if they listen, will hear the bell sound like a word they almost recognize.
- **A Stray Message.** A courier's cart overturns on the street. Among the scattered letters is one bearing a seal the party does not recognize: an eye half-hidden behind a curtain of thread. The courier, a young woman with ink-stained fingers, sees the party looking and says, very quietly, *"Don't. Please. Don't read it. Just put it back and walk away."* Then she leaves.
- **The Invitation.** A card arrives at the party's lodging, pressed into the hand of a child who vanishes before the door closes. The card is heavy, cream-colored, and warm to the touch. On the front, in elegant script: *"You have seen the thread. The Order of the Veil invites you to the Unveiling. Bring no questions. The full answers will find you."* On the back, in a different, shakier hand: *"Go. But know that once you are inside, there is no going outside. — I.V."*
