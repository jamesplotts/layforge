---
id: the-gilded-quill-inn
connections:
  - duskmarket-crossroads
  - veiled-chapel-of-ash
chapter: the-hints-appear
---

The Gilded Quill is a mid-tier inn that caters to merchants, minor nobles, and the occasional adventurer. Its name comes from a large brass quill mounted above the entrance, which has been there so long that no one remembers who placed it or why. The common room is warm, wood-panelled, and smells of beeswax and spilled ale. A crackling hearth, a long bar, and a collection of mismatched tables make up the main floor. Upstairs, twelve rooms offer modest comfort; the best have a view of the crossroads and the chapel steeple.

The inn's keeper, a broad-shouldered woman named Dun, has been running the Gilded Quill for eleven years. She is not a member of the Order, but she is aware of them. She has kept quiet for eleven years. Lately, however, she has begun receiving strange parcels each evening: a single black rose, a vial of indigo ink, and a note. The notes are always different. The roses are always the same. She does not open them. She puts them in a locked chest under the bar and does not speak of them. If the party asks, she will tell them the truth: the Gilded Quill has been "marked," and she does not know what that means, but she knows that the people who send the roses are not the kind of people you want to ask twice.

The inn is also where the party receives their formal invitation to the Unveiling. The card will appear on their pillow, warm and heavy, and Dun will not have known it was coming. The card's second line — the one written in a shakier hand — suggests that not everyone inside the Order wants the party to come.
