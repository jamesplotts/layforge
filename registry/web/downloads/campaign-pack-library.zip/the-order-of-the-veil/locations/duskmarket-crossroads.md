---
id: duskmarket-crossroads
connections:
  - the-gilded-quill-inn
  - veiled-chapel-of-ash
  - the-obsidian-cellar
chapter: the-hints-appear
---

Duskmarket Crossroads is the commercial heart of the town, a jumble of cobblestone lanes where the smell of roasted garlic competes with the sharp bite of tanning chemicals. Stalls line the street in overlapping rows, their awnings a patchwork of faded reds and ochres. Merchants call out prices, children dart between legs, and the constant murmur of trade is the town's true heartbeat.

But beneath the noise, there is a second language. A spice merchant taps his thumb twice against his counter. A silk trader nods to a stranger who is not her customer. A cart driver pauses, looks at a building's facade, and mutters a phrase that sounds like a prayer but is not in any liturgy the party would recognize. These are the marks of the Order of the Veil, visible only to those who know to look. The coded gestures are subtle — a brush of the wrist, a tilt of the head, a particular way of folding a receipt — and they happen dozens of times a day, woven into the fabric of commerce so seamlessly that no outsider would ever notice.

The crossroads is also where the party first encounters the physical evidence: a half-burned letter in a gutter, a seal pressed into wax on a barrel's bung (an eye behind a curtain of thread), a chalk symbol scrawled on a wall in a narrow alley that the town's mason claims he "must have drawn by accident." The town is full of the Order's quiet presence, and the Order is full of the town.
