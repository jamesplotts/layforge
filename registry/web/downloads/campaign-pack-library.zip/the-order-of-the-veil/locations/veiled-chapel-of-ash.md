---
id: veiled-chapel-of-ash
connections:
  - duskmarket-crossroads
  - the-gilded-quill-inn
  - the-obsidian-cellar
chapter: the-hints-appear
---

The Chapel of Saint Ashen is a small, stone-walled place of worship that sits at the quiet end of the crossroads. It is not grand. The nave holds perhaps forty pews. The windows are plain glass, not stained. The altar is a simple slab of pale stone with a single candle in a black iron holder. But something about the chapel is wrong, or at least deeply strange, to an outsider's eye.

The bell rings at odd hours. Three strikes, a pause, then seven. The parishioners shrug. The candle on the altar is never lit by the parish priest — it is always already burning when anyone enters, as though it has been burning continuously for a very long time. The walls, if you look closely, are faintly scored with symbols that resemble script but are not in any language the party will recognize. And the door to the cellar — the small iron-banded door at the back of the nave, behind a shelf of old hymnals — has been recently reinforced with new locks and a fresh coat of paint that does not quite match the rest.

On the night of the Unveiling, the chapel is "in use." The parishioners have been politely redirected to a different service. The doors are locked from the inside. The candle on the altar burns a deep violet instead of its usual white. And in the nave, seated in the pews and standing at the front, are a dozen or more people the party may recognize: the spice merchant, the silk trader, the cart driver, a magistrate, a healer, and others from the crossroads and the inn. This is the Order of the Veil, in session, and the party is about to be noticed.
