---
id: the-obsidian-cellar
connections:
  - veiled-chapel-of-ash
  - duskmarket-crossroads
chapter: the-hints-appear
---

Below the Chapel of Saint Ashen, behind the hymnals and through a door that has been reinforced and repainted, a narrow staircase descends into the bedrock. The steps are worn smooth by centuries of feet. The air grows cool and dry. At the bottom, a low-ceilinged chamber opens: the Obsidian Cellar.

The walls are black basalt, polished to a dull sheen that drinks the light of the single oil lamp burning in the center of the room. The floor is flagstone. There is a table, long and narrow, with a chair at each end. On the table: a vial of indigo ink, a sheet of heavy cream paper, a small brass cipher key, and a black rose in a glass of water. The chair at the far end is empty. The chair at the near end has not been empty for a long time — a faint outline in the dust suggests someone has been sitting there, waiting, for hours.

This is where the Watcher keeps her station. This is where she has been waiting for the party, specifically, since they noticed the spice merchant's gesture. The cellar is small, inescapable, and smells of old stone and cold ink. If the party enters, they will find a woman sitting in the far chair, watching them with eyes that are tired and sharp at the same time, and she will say, very quietly, "You have three days. I will give you the rest now."
