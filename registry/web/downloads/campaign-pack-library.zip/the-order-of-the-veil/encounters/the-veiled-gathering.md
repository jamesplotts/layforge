---
id: the-veiled-gathering
location: veiled-chapel-of-ash
involves:
  - sister-cordelia
  - nyx-the-watcher
chapter: the-hints-appear
---

The party arrives at the Chapel of Saint Ashen on the night of the full moon, following the invitation card. The doors are unlocked. The candle on the altar is burning violet. The pews are full. The encounter begins with the party walking in and being seen.

The gathering is not what the party might expect. There are no hoods, no chanting, no dramatic monologues. The people in the pews are the town: the spice merchant, the silk trader, the magistrate, the healer, the cart driver, a baker, a schoolteacher. They are sitting quietly, some with their eyes closed, some with their hands folded, some watching the party with a stillness that is almost reverent. At the front, a man stands at the altar — tall, grey, ancient in a way that goes beyond his years. He does not turn to face the party. He is speaking, softly, to no one, or to everyone, and his words are a liturgy the party does not recognize. The air in the chapel is thick, and the candle flame is very steady, and the bell outside is silent for the first time in the party's memory.

Sister Cordelia is at the back, as described. She is watching the party with an expression of profound sorrow. The man at the altar finishes his words, and the room is quiet, and then the man turns, and his eyes find the party, and he says, "Ah. You came. Good. I was hoping you would. We have much to discuss, and the candle is burning down." He gestures to the pews. "Sit. There is room. And I would very much like to know what you have seen, because you have seen more than you know, and that is a dangerous thing to carry into a room full of people who have seen everything."

The encounter is a conversation, not a combat. The party is in a room full of witnesses, and the man at the altar is not going to let them leave until he has asked his questions. The DM should let the party feel the weight of the room, the quiet, the fact that everyone here is watching, and that the only person in the chapel who does not seem to be part of this is Sister Cordelia, who is not part of this, who is terrified, and who is, if the party asks, the only person in the room who will say the truth. The man at the altar will not fight. He will not threaten. He will sit across from the party and speak with the patience of a man who has been waiting a long time for someone to walk into his room and ask him questions, and who has decided, in this moment, that the world has earned an answer. But the answer he gives will be partial. It will be enough to be true. It will not be enough to be complete. And in the corner of the room, behind the hymnals, a door the party did not notice when they entered will creak open, and a figure will step out, and that figure will be Nyx, and she will be looking at the party with an expression that says: *you should have listened to me. You should have walked away. But you are here. So. Come. Downstairs. Now. Before he finishes."
