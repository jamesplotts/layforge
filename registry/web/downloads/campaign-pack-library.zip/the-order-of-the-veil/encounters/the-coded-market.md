---
id: the-coded-market
location: duskmarket-crossroads
involves:
  - master-pellin
chapter: the-hints-appear
---

The party arrives at Duskmarket Crossroads on an ordinary afternoon, but the ordinary is threaded with the extraordinary. The encounter begins innocently enough: the party is buying supplies, making observations, engaging with the merchants. But the DM should let the coded gestures accumulate. Over the course of ten to twenty minutes of in-game time, the party should witness at least four or five instances of Order behavior: the thumb-tap, the wrist-brush, the particular nod, the murmured phrase. These are not overt. They are easily missed, and the DM should let the party miss some of them. The point is not to present a list of clues but to create a texture of wrongness, a sense that the town is operating on two frequencies at once.

The encounter escalates when the party, or one of them, speaks to Master Pellin about what they have seen. Pellin's reaction is the key beat. He will not confirm or deny. He will offer them a free sample of cardamom, change the subject, and steer them toward the Gilded Quill ("You haven't tried their spiced ale? You must. I'll put in a word with Dun.") But if the party presses — if they show him the chalk symbol from the alley, or describe the seal on the barrel — Pellin's composure will shift. The proverbs stop. The cheer thins. He will become quiet, and his hands will start to shake, and he will say the line from his profile. The encounter ends with Pellin locking his stall early, sending the party on their way with a blessing that sounds more like a warning, and the faint sound of him calling someone on a speaking-stone in a voice that is flat and urgent and, for the first time in nineteen years, afraid.

If the party is aggressive or threatening during this encounter, Pellin will not fight. He will retreat into the back of his stall, and a second later, three other merchants in the crossroads will go very still, and the crowd will begin to thin, and the party will realize that something has been activated, and they do not know what. This is the first hint that the Order is not passive, and that noticing them is not the same as being safe.
