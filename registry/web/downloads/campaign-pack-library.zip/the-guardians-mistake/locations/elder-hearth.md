---
id: elder-hearth
chapter: the-heroic-act
connections:
  - thornhaven-village
---

Elder Miriam's longhouse sits at the highest point of Thornhaven, accessible by a spiral stair carved into the mountain's face. The structure is older than the village — the timbers are black with age, and the doorframe is wrapped in iron bands that hum faintly when touched. Inside, the hearth burns with a fire that is not quite fire: the flames are the colour of deep water, and they cast no light, only a cool blue glow that makes the room feel like the inside of a closed eye.

The walls are lined with woven tapestries depicting a history the village has kept secret for nine generations. The images show a great horned creature coiled around a crack in the earth, its body pressing the crack shut. They show a woman in elder's robes pressing her palm to the creature's brow. They show a darkness — not a creature, not a shape, but an *absence* — pressing back against the creature's flank like a thumb against a bruise. The last tapestry is unfinished. It shows a hand striking the creature with a blade. The face of the one who holds the blade is blank.

Miriam keeps a clay pot on the mantle, sealed with wax. Inside is a tooth — the Warden's, pulled from the corpse three months ago. It is cold to the touch, always, and when the party is within earshot, it makes a sound like a long, slow exhale. She will not let them touch it. She will not let them look at it for too long. She will tell them what they need to know, but she will not tell them everything, because some of what she knows would make them put the blade back in the Warden's grave, and that would be a mercy neither party deserves.
