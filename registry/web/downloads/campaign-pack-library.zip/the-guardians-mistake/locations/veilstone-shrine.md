---
id: veilstone-shrine
chapter: the-heroic-act
connections:
  - thornhaven-village
  - the-ashen-path
---

The Veilstone Shrine stands at the fork where the Ashen Path splits into two — one branch climbing toward the high passes, the other descending into the lowland. It is a standing stone, twelve feet tall, carved with a spiral that tightens inward to a point where the stone simply stops. Not broken. *Stopped.* As though the carver's hand ran out of purpose mid-stroke. The stone is warm to the touch, warmer than the air should allow, and the spiral is faintly ridged, as if it were meant to be felt rather than seen.

This is where the pact was sealed. Nine generations ago, a woman — Miriam's ancestor — pressed her palm to the stone and spoke a name that has since been unmade from the village's memory. The Warden came to the Hollow to keep the seal. The seal kept the thing on the other side of the world's skin. The stone is the hinge, the Hollow is the door, and the Warden was the lock.

Now the stone is cold. The spiral's ridges have filled with a black fluid that the party can smell from twenty paces — the same ozone-and-stars scent from the Hollow. The stone is not broken, but it is *empty*, the way a key is empty once the door it opens has been pried off its hinges. The thing on the other side does not need the key anymore. It is pressing its face against the wood.
