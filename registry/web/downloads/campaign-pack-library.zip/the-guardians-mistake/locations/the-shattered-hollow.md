---
id: the-shattered-hollow
chapter: the-heroic-act
connections:
  - thornhaven-village
---

The Shattered Hollow is the wound where the Warden lived. It is a cave mouth in the mountainside, thirty paces wide, with a lip of broken stone where the creature's body used to be coiled. Three months ago, the party's weapons carved the flesh off the bones, and the bones were carted away for tanning. What remains is a hollow of grey rock, a shallow pool of something that is not water and not blood, and a silence that presses against the eardrums like depth.

The walls of the Hollow are marked with carvings — not the rough scratchings of a beast's den, but *deliberate* work. Figures pressed flat against a central void, like hands pressed against glass from the other side. The void in the center of the carvings is not painted or carved. It is a patch of the rock that simply *isn't there*. Look at it for too long and the eyes water. The brain tries to fill it in with a shape, a face, a hunger, and fails. The pool at the Hollow's floor reflects the sky, but not the *current* sky. It shows a sky with no stars, and in the reflection, something vast is turning over, slow as a season, pressing its face toward the surface.

The horns the party took as trophies are embedded in the far wall, still attached to a fragment of skull. They pulse. Once every nine breaths. The black residue that seeps from them smells of the space between one thought and the next — that gap where the mind goes quiet and something else might, briefly, be listening.
