---
id: thornhaven-village
chapter: the-heroic-act
connections:
  - elder-hearth
  - the-shattered-hollow
  - the-ashen-path
  - veilstone-shrine
---

Thornhaven clings to the eastern face of a grey mountain ridge, its timber longhouses stacked one above another like a stack of kindling. The village was once a stop for shepherds and miners; now it is a place of three hundred souls who have spent three months celebrating a victory they are beginning to fear they do not deserve.

The party will find the celebration's remnants everywhere — a snapped banner over the well, half-empty flagons abandoned in the cobbled square, the smell of cold ash from bonfires that went out days ago. The villagers do not hide their suspicion. Warden Brenna stands at the gate with a crossbow, not aimed, but *ready*. Children are kept indoors. The elder's longhouse at the village's crown is the only place where the doors still open to strangers, and even that hospitality is thin, stretched over old grief.

At the edges of the settlement, where the torches do not reach, the shadows behave wrong. They pool. They *wait*. A dog that wandered too far has not returned. The villagers will not say what they saw it look at in the dark, but they will not let you walk the perimeter alone after sundown. The air tastes of iron and something older — like the inside of a sealed jar that has just been cracked open.
