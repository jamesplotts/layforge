---
id: the-ashen-path
chapter: the-heroic-act
connections:
  - thornhaven-village
  - veilstone-shrine
---

The Ashen Path is the only road out of Thornhaven, a narrow track of packed grey dust that winds up the mountain's spine and then down the other side toward the lowland settlements. It earned its name after the Warden's death: the creature's ichor, burned by the villagers to keep the carrion crows away, left a residue that turned the road's dust the colour of old ash. It still hasn't washed out. The colour is wrong. It has not faded in three months.

Travelers on the Path report that the shadows cast by the trees do not align with the sun. A birch on the left side of the road throws its shadow to the left, into the sun's direction, and the shadow is longer than the tree. The trees themselves are fine. The leaves rustle normally. The bark is the right brown. It is only the shadow that is wrong, and only in the Path's first half-mile, and only after the light has passed its zenith.

Further along, where the Path narrows between two granite slabs, there is a place where the ground is soft, like wet sand, and if you press your foot into it and *listen*, you can hear breathing that is not yours. The villagers call it the Soft Place. They do not walk it at night. They do not, as a rule, walk it at any time, but they will not say why, and they will not let the party ask twice.
