---
id: void-walkers-awakening
title: "The Weight of Heroism"
level_range: "3-8"
pvp_policy: pve_only
maturity_tier: standard
image_maturity_tier: family_friendly
shared_knowledge: strict
tone:
  - gritty
  - melancholic
  - morally-complex
  - tense
  - redemptive
author: AI-generated
chapters:
  - id: the-heroic-act
    title: "The Heroic Act"
    level_range: "3-4"
    summary: "The party returns to Thornhaven to a celebration that curdles into suspicion. The first shadows bleed from the Shattered Hollow, and the village they saved is beginning to unravel. Elder Miriam offers a fragment of truth before the village closes its doors."
  - id: the-unintended-consequences
    title: "The Unintended Consequences"
    level_range: "4-5"
    summary: "The party discovers the Guardian's true purpose and the broken pact that sealed the Void Walker. Aldric arrives with knowledge and a price. Vanishings multiply, and the shadows stretch past the village boundaries."
  - id: the-escalation
    title: "The Escalation"
    level_range: "5-7"
    summary: "The Void Walker fully manifests and speaks to the party. The region beyond Thornhaven begins to darken. Miriam reveals the full history of the pact, and the party must decide whether to renew the sacrifice, find a new guardian, or face the entity directly."
  - id: the-resolution
    title: "The Resolution"
    level_range: "7-8"
    summary: "The final confrontation with the Void Walker. The party's choice — sacrifice, negotiation, or a new bargain — reshapes the region. The aftermath redefines what their heroism actually cost, and what it can still mean."
---

# The Weight of Heroism

Three months ago, the party walked into Thornhaven as monsters and walked out as legends. They slew the Warden of the Hollow — a vast, horned beast coiled around a mountain pass, slitting throats and scattering livestock — and the village threw a festival in their name. Ale flowed. Songs were sung. The party's names were carved into a banner above the well.

Now the same banner hangs limp and grey in the wind. The festival tents have been torn down. The well is dry. And at the edges of the village, in the spaces between the torchlight, shadows move with a patience that has nothing to do with wind.

The creature the party killed was not a predator. It was a lock. And what it kept sealed behind the mountain is now pressing against the door, tasting the air for the people who killed its keeper. They do not hate the party. They are simply hungry, and the guilt the party carries is a flavor they find delicious.

This campaign asks the players to sit with a truth that has no clean answer: they did the right thing with the information they had. The thing they killed *was* killing people. The thing it protected *was* a monster. Both are true. And now they must find a third path — one that does not require them to be either the villain or the savior, but simply the ones who must live with what they broke.

## Hooks

- **The Summons:** A courier from Thornhaven arrives at the party with a bruised face and a desperate plea: *"You saved us. You have to come back. Something else is coming, and it knows your names."*
- **The Dream:** Each party member wakes on the same night with a shared image — a vast, eyeless face pressing against the inside of the world, whispering a single word: *yours."
- **The Hollow Calls:** The Warden's horns, kept as trophies, begin to bleed a black residue that smells of ozone and old stars. The Shattered Hollow is calling the party back to where they made their mistake.
- **Aldric's Letter:** A sealed letter arrives from no one in particular, bearing a wax stamp of an open eye. Inside: *"You killed a door. I can teach you how to build a new one. Meet me where the path ends. — A."*
