---
id: warden-brenna
location: thornhaven-village
stat_block_ref: "SRD Veteran"
voice: "Gruff, clipped, military. Uses commands instead of questions. Trust is shown by giving ground, not by smiling."
chapter: the-heroic-act
---

Brenna is forty, broad-shouldered, with a shaved head and a scar across her left palm that she never hides. She was a foot soldier in a border garrison before the Warden came, and she spent two years watching it from the ridge before the party arrived to finish it. She killed three of its herd-mates in single combat before the party got there, and she carries the weight of those three as a debt she does not know how to repay. The Warden was not attacking her. It was *herding* the livestock away from the village, and she did not see that. She only saw a monster, and she did what soldiers do.

Now Brenna is the village's warden in the truest sense: she is the last thing between the villagers and whatever is leaking out of the Hollow. She will not let the party leave Thornhaven until she is satisfied they understand what they are walking back into. She will not let them enter the Hollow unaccompanied. She will not let them touch the Veilstone without her standing behind them with a crossbow. Her suspicion is not hatred; it is the specific fear of a person who has already made one mistake and is terrified of the second one.

If the party earns her trust — slowly, over the course of the chapter, by asking questions instead of demanding answers — she will give them the name of the Soft Place on the Ashen Path and the hours when the shadows align wrong. She will not give them more than that. She is not Miriam. She does not have nine generations of context. She has three months of not-sleeping, and it has made her sharp and small and very, very tired.
