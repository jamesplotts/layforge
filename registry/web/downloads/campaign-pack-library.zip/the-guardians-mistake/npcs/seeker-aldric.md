---
id: seeker-aldric
location: the-ashen-path
stat_block_ref: "SRD Acolyte (modified)"
voice: "Measured, precise, slightly formal. Uses long compound sentences as a way of controlling information flow. Smiles when he should not."
chapter: the-heroic-act
---

Aldric is in his late fifties, lean, with ink-stained fingers and a travelling cloak that is too fine for a scholar and not fine enough for a noble. He studies the architecture of ancient pacts — the legal and spiritual mechanics by which one entity agrees to constrain another. He has spent twenty years in archives and ruin sites, building a map of the world's binding-points, and Thornhaven is the one he has been circling for six years. The Warden's death moved the timeline from "decades" to "days," and he is here now, on the Ashen Path, arriving the same morning the party is leaving, as though the path itself delivered him.

He is not evil. He is not kind. He is a man who has spent so long inside the architecture of bargains that he has begun to think in their terms: every interaction is a clause, every favour is a lien, every truth is collateral. He will offer the party real help — genuine knowledge of the pact's structure, the Void Walker's nature, the mechanics of renewal. In exchange, he wants a fragment of the Warden's skull from the Hollow. Not the horns. The skull. The part that *thinks.* He needs it for his research, and he will tell them this plainly, but he will not tell them what he will do with it, because the answer involves a second binding, a second pact, and a second creature he has been searching for, and that is a story for a later chapter.

His smile is the thing that should make the party uneasy. It is the smile of a man who has already decided the shape of the transaction and is simply waiting for the other party to agree to the terms.
