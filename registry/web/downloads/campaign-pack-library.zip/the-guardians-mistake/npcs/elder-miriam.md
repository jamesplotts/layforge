---
id: elder-miriam
location: elder-hearth
stat_block_ref: "SRD Commoner (modified)"
voice: "Speaks in short, weighted sentences. Pauses before difficult truths. Never raises her voice; the silence she leaves behind is louder."
chapter: the-heroic-act
---

Miriam is seventy-three, small, and built like a cord that has been twisted so many times it is about to snap. Her hair is white and kept in a practical knot; her hands are mapped with old burns from decades of tending the hearth. She was thirty when she first saw the Warden settle into the Hollow, and she remembers the weight of the silence it kept. She remembers the shape of the *other* thing, the one pressing against the world's skin, and she has never fully recovered from the memory. It is not a fear she can articulate. It is a pressure behind her sternum, constant, like a swallowed stone.

She does not blame the party. She wants them to understand that. They killed a creature that was killing people. That is not a wrong. But she also wants them to understand that the creature was doing the one thing it could, the one thing it was *made* to do, and that it was not free in its guardianship any more than a door is free in its standing. She will give them the truth in pieces, each one measured, because she has learned that the whole truth, at once, in one breath, will make them do something desperate and unthinking, and she has seen what desperation does to people standing in a Hollow with a blade.

Her goal is not to protect the party. It is to make sure they do not make the second mistake the first mistake makes possible: killing again, in a panic, before they understand what they are killing. She will test the party's readiness by how they handle the information — whether they reach for weapons, whether they rage, whether they sit still and let the truth be heavy. If they sit still, she will give them more. If they rage, she will close the door. She has three more pieces of truth in her, and she will spend them only on the party that can hold a terrible sentence in their mouth without spitting it out.
