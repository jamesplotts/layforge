---
id: celebration-turned-dark
location: thornhaven-village
involves:
  - warden-brenna
  - elder-miriam
chapter: the-heroic-act
---

The party arrives to find the festival half-demolished. The banner over the well has been taken down and is being re-hung, but the faces on it — the party's, painted in cheerful red and gold — have been scratched out with a blade. The square is empty of people, but not of presence: every doorway has a pair of eyes in it, and the silence has the texture of a held breath.

Brenna intercepts them at the well. She does not draw the crossbow. She does not need to. She says: *"You came back. Good. Sit down. Drink something. And then we are going to have a conversation, and I need you to hear it without swinging your sword, because I am not the enemy, and the thing that is the enemy doesn't have a sword, and it is already inside the walls, and I am the only one who can see it, and I have been seeing it for nine days, and I am tired."*

This is not a combat encounter. It is a confrontation with the party's own mythology. The villagers are not hostile the way a monster is hostile. They are hostile the way a parent is hostile when the child has broken the only thing keeping the house standing. They want the party to *feel* it. They want the party to look at the scratched-out faces and understand that the same hands that painted them are the hands that scratched them, and the gap between those two acts is the size of a Void Walker.

If the party attempts to leave without speaking to Miriam, Brenna will bar the Ashen Path with a line of villagers holding torches. Not a combat. A wall. They will hold the line until the party sits down and talks. If the party threatens violence, the villagers will not fight. They will *stop*. They will put down their torches, and they will step back, and they will let the party walk, and they will watch the party's backs, and the walking will be slower than the party intends, because the shadows on the Path will be *watching*, and the walking will feel like it is being *permitted*, and the party will understand, in their bones, that they are not leaving Thornhaven. They are being *released*. And the difference matters. And the difference is the shape of the wound they are about to try to close.

Miriam will appear at the edge of the square, watching. She will not approach. She will nod, once, to Brenna, and then lead the party — one at a time, if they are many — up the spiral stair to the hearth. The encounter ends when the party sits across from her, in the blue-glow, and she says: *"I am going to tell you what the Warden was. And then I am going to tell you what it was keeping out. And then I am going to ask you to put down your weapons, because you are not going to need them tonight, and the thing coming is not going to want your steel. It is going to want your shame. Sit down. Put them down. Drink the tea. It is bitter, but it helps."*
