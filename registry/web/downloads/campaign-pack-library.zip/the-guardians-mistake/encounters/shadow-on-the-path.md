---
id: shadow-on-the-path
location: the-ashen-path
involves:
  - warden-brenna
chapter: the-heroic-act
---

The party is sent to the Ashen Path to investigate the Soft Place — the patch of wet-sand ground between the granite slabs where the breathing can be heard. Brenna accompanies them. She will not go past the Soft Place. She will sit on a boulder, crossbow in her lap, and watch, and she will not look away, and her hands will be shaking, and she will not explain why, and the party can ask and she will say: *"I don't know what I'm afraid of, and I don't like it, and I am telling you to be careful, and that is all."*

The Soft Place is a sensory encounter. The ground is warm, like the skin of a sleeping animal. The breathing is slow — one breath every forty seconds — and it is not the breathing of a creature in the ground. It is the breathing of a creature *above* the ground, in the air, in the space between the world and the next world, and the ground is simply where the breath condenses. The party can try to dig, to cast detection, to listen. Nothing will find the source. Because the source is not *here*. It is adjacent. It is in the next room over, and the wall between rooms is getting thinner, and the breathing is the sound of the wall flexing.

If the party spends more than an hour at the Soft Place, the shadows on the granite slabs will begin to *detach*. Not fall. Detach. They will slide off the stone like a film of oil, pool on the ground, and *look up*. They have no faces. They do not need faces. They are the Void Walker's attention, stretched thin, testing the perimeter. They will not attack. They will not need to. They will simply *watch*, and the party will feel watched in a way that steel cannot answer, and Brenna will say, very quietly: *"We should go. Now. All of you. And we should go fast. And we should not look back at the shadows, because if you look at them, they will know you are afraid, and they are not here to be afraid of. They are here to be hungry. And they are learning the difference."*

The encounter resolves when the party retreats to Thornhaven. The shadows follow to the village boundary and stop. They pool at the edge of the torchlight. They wait. They have time. The party has less.

This encounter is the chapter's first true cliffhanger: the party has confirmed that something vast is *present*, that it is not a physical threat that can be killed, and that it is *learning them*. The chapter ends here, or in the Hollow, depending on which path the party chooses. Either way, the weight is in their hands now, and the weight does not get lighter, and the chapter is over, and the next one is harder, and the tea is cold, and Miriam is waiting, and the door is open, and the window is closing, and the voice is coming, and the party has to decide what they are going to do with the silence they made.
