---
id: greyhaven-crossroads
connections:
  - ivory-hall
  - marlowe-inn
  - border-ford
chapter: the-spark
---

Greyhaven Crossroads sits where the Aldermere River bends sharply toward the south, dividing the Kingdom of Morvayne from the Kingdom of Vane with a line of water that both sides claim belongs to them. The town is a muddy, bustling place of half-timbered buildings, salt-smelling air, and a permanent undercurrent of tension. Merchants from both kingdoms do trade here, but they do it with the careful distance of people who know that a spilled cup of ale could become a pretext for a sword fight. The streets are wide enough for carts, narrow enough that a crowd feels like a wall. Children chase dogs between market stalls selling smoked fish, forged nails, and, on quiet days, pamphlets with the crests of both kingdoms printed side by side — a jarring reminder that this place is supposed to belong to neither.

The town's only real institution is the Magistrate's Office, a squat stone building overlooking the river where Captain Sera Thorn holds court. The office is cluttered, underfunded, and perpetually short-staffed, but Thorn has held the peace here for six years through a combination of sharp questions and the quiet threat of a very long cell. The town also hosts the Marlowe Inn, where most of the traveling folk stay, and — most importantly — the Ivory Hall, a great meeting chamber built on a raised plinth at the town's center, where diplomatic business is conducted under the joint authority of both kingdoms. The Hall is old. Its walls are whitewashed, its floors are worn smooth by decades of shuffling diplomats, and its acoustics carry a whisper to the back row. The party will learn, too late, that this was by design.

On the day the party arrives, the town is alive with the energy of the summit. Morvayne's delegation has been in town for two days, setting up camp in the east quarter. Vane's envoy and his retinue arrived the morning before, taking rooms at a smaller inn in the west quarter. The streets are cordoned with rope, soldiers from both kingdoms patrol in separate pairs, and the air smells of river mud, roasting meat from the market, and the particular sharpness of fear that builds before a political meeting that both sides are hoping will go well and neither side believes will. The party's escort job brings them straight into the center of it. They will not leave this town the same people who arrived.