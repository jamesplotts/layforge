---
id: captain-sera-thorn
location: greyhaven-crossroads
stat_block_ref: SRD Guard
voice: sharp, fast-talking, asks questions in a rapid sequence as if the answer is always one sentence away and the silence is an insult
chapter: the-spark
---

Captain Sera Thorn has been the magistrate of Greyhaven Crossroads for six years, and in that time she has settled forty-three border disputes, presided over nine murder trials, and once ordered a Vane ambassador to leave the town because he kept interrupting her and she had a headache. She is not a noble, not a soldier, not a priest. She is a woman with a law degree from the River Confederacy, a very low opinion of both kingdoms' legal systems, and an abiding belief that the truth is a thing you can pin down if you are willing to look long enough and ask enough questions. The assassination at the Ivory Hall is, to her, not a political event. It is a crime scene, and she is going to work it the same way she works every other case: methodically, without regard for which kingdom the victim belonged to, and with a patience that is either admirable or maddening depending on who is on the other side of the desk.

The party is of interest to her for three reasons: they were in the room, they were holding a sealed diplomatic letter at the time of the assassination, and they left before the body hit the floor. None of this makes them guilty. All of it makes them important. She will not threaten the party, because threats are for people who have no other leverage, and Thorn has other leverage: the truth. If the party cooperates, she will protect them from both kingdoms' agents. If they do not, she will find out what they know anyway, and she will know it before they do, and she will be very, very disappointed in them. She is not on either side. She is on the side of the evidence, and in a town that has just become a crime scene, that makes her the most dangerous person in Greyhaven Crossroads.