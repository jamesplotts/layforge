---
id: general-marcus-stoneheart
location: border-ford
stat_block_ref: SRD Veteran
voice: blunt, economical, speaks in short declarative sentences and rarely uses a word when a gesture will do
chapter: the-spark
---

General Marcus Stoneheart commands the Morvayne border army, a force of four thousand infantry, six hundred cavalry, and a reputation for being the only Morvayne officer who has actually read the tactical manuals instead of just signing the attendance sheet. He is a good soldier. He is also a man who hates this. He has served Queen Isadora for eleven years, fought in three border disputes, and lost two friends to a skirmish over a river stone that both kingdoms claim. He did not sign up for a war. He signed up to be the last person who stops one. The distinction is academic now, but he makes it, every day, in the way he gives his orders: precise, minimal, and laced with a bitterness that his soldiers have learned to ignore because the man who tells them to hold the line at dawn is the same man who makes sure they have hot soup and a dry bed at night.

He will not fight the party. He will not recruit the party, unless they give him a reason to. He is not a villain and he is not a hero. He is a professional who is about to do a terrible job out of necessity, and he wants the party to understand that. If they approach him with questions, he will answer them. If they approach him with threats, he will look at them for a long time and then tell them, very calmly, that he has killed more people than they have and that the number is not a point of pride. If they approach him with a plan to stop the war, he will listen. He will not promise it will work. He will not promise he is not already preparing for the worst. But he will listen, and in the context of this war, that is more than most people will give them.