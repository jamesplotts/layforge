---
id: the-accidental-war
title: The Accidental War
level_range: "3-8"
pvp_policy: pve_only
maturity_tier: standard
image_maturity_tier: family_friendly
shared_knowledge: strict
tone:
  - grim
  - political
  - morally complex
  - weighty
  - consequential
author: AI-generated
chapters:
  - id: the-spark
    title: The Spark
    level_range: "3-4"
    summary: The party arrives in the border town of Greyhaven Crossroads for a seemingly simple escort job, only to find themselves at the center of a diplomatic assassination that ignites a full-scale war between the Kingdom of Morvayne and the Kingdom of Vane. Both kingdoms have legitimate grievances, and the party's accidental presence at the scene makes them the war's most wanted fugitives. They must flee, take a side, or attempt to stop the bleeding before it consumes everyone.
  - id: the-factions
    title: The Factions
    level_range: "4-5"
    summary: The party travels to court and battlefield alike, learning the true grievances of both crowns. Queen Isadora of House Morvayne offers resources and protection in exchange for loyalty; King Aldric of House Vane dangles wealth and titles. The party witnesses the human cost — destroyed villages, refugee columns, desperate civilians — and must choose whether to serve a cause, remain neutral, or seek a third path. The war marches toward the party's home region, and the stakes become personal.
  - id: the-battlefield
    title: The Battlefield
    level_range: "5-7"
    summary: "The conflict escalates into full war. The party participates in major engagements or diplomatic missions, seeing both sides commit atrocities that erode any simple notion of good and evil. Brother Aldric offers a chance to negotiate a truce, but both crowns may reject the gesture. The party's home region is overrun and destroyed, forcing an urgent decision: end the war now, by any means, or survive its aftermath and carry the guilt forward."
  - id: the-resolution
    title: The Resolution
    level_range: "7-8"
    summary: "The final confrontation — a decisive battle, a last diplomatic gamble, or a war against both crowns simultaneously. The party's accumulated choices determine which factions stand against them and which offer aid. The aftermath reshapes the region: new borders, new rulers, new debts. The party must reckon with the fact that they started this, and decide what kind of peace is worth the cost."
---

# The Accidental War

Two kingdoms that share a river, a history, and a hatred of each other stand on the knife-edge of annihilation. The Kingdom of Morvayne, ruled by Queen Isadora of House Morvayne, is desperate, pragmatic, and willing to make alliances no one else would touch to survive. The Kingdom of Vane, under King Aldric of House Vane, is ambitious, cruel, and certain that the war is its divine inheritance. Neither side is wholly right. Neither side is wholly wrong. And a party of adventurers, hired for a simple job, walks into the room where a diplomat dies — and the world breaks.

This is a campaign about the weight of accidental consequence. The party did not choose the war, but they were there, and now thousands of people will die because of it. Both kingdoms have legitimate grievances: Morvayne was denied trade rights it had held for a century, and Vane was insulted in a public audience that made the Vane crown look weak. The assassination at the Ivory Hall is the spark, not the cause. The party cannot undo what happened. They can only choose how they respond — and every choice carries a body count measured in the thousands.

The campaign is structured in four chapters, each roughly one level's worth of play. The DM should pace the war deliberately: let the party feel the weight of their involvement, make their factional choice feel earned, and ensure the moral complexity lands. The party is not the hero of this story. They are an accident that became a variable in a much larger equation. Their guilt is not something to resolve in a single conversation; it is a thread that runs through every chapter, every encounter, every NPC who looks at them and sees the people who started this.

## Hooks

- **The Simple Job:** The party is hired by a merchant or minor noble to escort a diplomatic envoy to a peace summit in the border town of Greyhaven Crossroads. The pay is good, the distance is short, the risk is minimal. Nothing in the briefing suggests that a dead diplomat's body will end up in their hands.
- **The Letter That Wasn't Delivered:** The party's escort job is interrupted — the envoy is killed before the letter reaches its recipient. The letter's contents (a proposed truce, a secret alliance, a confession of prior aggression) become the MacGuffin that both kingdoms now want, and the party is the only one who can say what it said.
- **The Witness Nobody Wanted:** The party is the only credible witness to the assassination. Both kingdoms send agents to find them: Morvayne wants a testimony that will justify total war; Vane wants a testimony that proves Morvayne was the aggressor. The party's account of what they saw becomes a weapon, and they must decide whose weapon to be — or whether to burn the story entirely.
- **The Monk in the Back:** Brother Aldric, the traveling monk, was in the room. He saw the assassin's face. He told no one, because he believed the assassination was a warning, not a declaration of war. Now he's looking for the party, and he's not happy about what they let happen.