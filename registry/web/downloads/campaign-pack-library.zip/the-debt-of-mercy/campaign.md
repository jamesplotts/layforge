---
id: debt-of-ash
title: "The Debt of Ash"
level_range: "3-8"
pvp_policy: pve_only
maturity_tier: standard
image_maturity_tier: family_friendly
shared_knowledge: strict
tone:
  - consequential
  - moral
  - political
  - tense
  - melancholic
author: AI-generated
chapters:
  - id: the-call
    title: "The Call"
    level_range: "3-4"
    summary: "Kaelen, the man the party spared in a battle long ago, appears at their doorstep with a courteous letter and a terrible debt. In Saltmere Harbor, the party is drawn into a web of gratitude and obligation as they learn the Kingdom of Ash has grown from a scattered remnant into a regional power. Whisper Nell, an old informant, holds fragments of the original event the party has half-forgotten. The chapter ends with the party standing on the Charred Shore, watching black ash drift down from a sky that has not been dark in three years, and realizing the mercy they showed was not an act of grace but the first thread of a rope."
  - id: the-repercussions
    title: "The Repercussions"
    level_range: "4-5"
    summary: "Kaelen's true demand is revealed: he wants the party to turn over their current allies—merchants, soldiers, a small city—to the Kingdom of Ash as tribute for the life he owes them. The party discovers their original act of mercy was based on a lie told by the Ash king, a lie that concealed a massacre of a neighboring village. The person they spared was guilty. Whisper Nell confirms what she overheard that night. Kaelen, when confronted with the truth, does not rage—he grieves, and his grief makes him more dangerous."
  - id: the-confrontation
    title: "The Confrontation"
    level_range: "5-7"
    summary: "The party must negotiate, fight, or scheme their way out of a debt that Kaelen genuinely believes is owed. Enforcer Darius arrives with a small company of Ash-trained soldiers and makes clear the deadline is real. In a twist that recontextualizes every prior scene, Whisper Nell reveals she was embedded by Kaelen from the beginning—her 'independence' was always his instrument. The party's current allies in Saltmere are marked for collection. The chapter ends in betrayal and flight."
  - id: the-resolution
    title: "The Resolution"
    level_range: "7-8"
    summary: "The final act is a choice: fulfill the promise and lose everything they have built, break it and face Kaelen's full force, or find the third path—confronting the Ash king directly and demanding the truth be aired before the region. The Kingdom of Ash must be dealt with not as a monster but as a consequence. The aftermath reshapes the political landscape, and the party carries the weight of what mercy costs when it is incomplete."
---

# The Debt of Ash

Somewhere in a session three or four sessions ago, your party did something merciful. They lowered a blade. They spoke a name into the dark and said *not today*. They let a captured noble walk away with his life, his kingdom, his people. They told themselves it was the right thing. They probably were right.

But right things have weight, and weight accumulates, and the person you spared did not simply vanish into the hills. He built. He armed. He remembered your face with the particular gratitude of a man who knows exactly what he owes and intends to collect every copper of it. Kaelen, once a trembling captive in the party's custody, has spent the intervening months and years forging himself into something with resources, soldiers, and a ledger in which the party's name is written in ink that will not fade.

This is not a villain-of-the-week module. Kaelen is not evil. He is *grateful*, and his gratitude is a blade wrapped in silk. The Kingdom of Ash, the polity the party's mercy allowed to survive, has grown from a band of refugees into a kingdom that now casts a shadow over the very region the party calls home. The ash falls in the morning now. The sky smells of cinders. And a letter with Kaelen's seal is waiting at the inn door.

The central question of this campaign is not *who to fight* but *what to do with a debt that was never yours to keep and is now too heavy to pay.* The party's past action was a genuine moral choice. The campaign asks them to sit with the consequences of that choice, to discover that their information was incomplete, and to decide—under pressure, under threat, under the weight of another person's grief—whether the mercy they showed was an act of grace or the first link in a chain they did not know they were forging.

## Hooks

**The Letter.** A thick envelope of grey paper, sealed with a wax stamp the party has no business recognizing. Inside, in a careful, educated hand: *You let me live. I remember. I have been counting the days since. Come to the Ashen Hall, and we will talk about what I owe. —K.*

**The Ash on the Wind.** For three nights running, a fine grey particulate has settled on Saltmere's rooftops. The harbor masters are uneasy. Ships from the east have stopped coming. The smell is new, and it does not go away.

**The urchin who knows.** A girl of perhaps fifteen, face smudged with soot, has been watching the party's inn for two days. She does not approach. She does not need to. She has been waiting for them to remember what she remembers.

**The debt in the ledger.** If the party has a scribe, a merchant contact, or any means of checking regional ledgers, they will find a new entry: a small kingdom, previously unlisted or listed as *extinct*, now with a treasury, a standing force, and a single recorded obligation. The obligation is addressed to them.