---
id: ash-on-the-wind
location: the-charred-shore
involves: []
chapter: the-call
---

The party goes to the Charred Shore to understand what they are being asked to acknowledge. It is a reasonable step. A party that is about to name a kingdom before a council should perhaps *see* the kingdom, or at least see what the kingdom leaves behind.

The shore is quiet. There is no one there. The tide is out, and the inlets are shallow pools of grey slurry that catch the afternoon light and throw it back in a faint, diffuse glow. The black sand is streaked with white residue. The rock is coated in grey. The smell is woodsmoke and mineral and something faintly sweet, like burnt sugar, the same smell as the Ashen Hall.

The party should spend time here. This is not a combat encounter. This is a *witnessing* encounter. The ash is falling. It is not a storm. It is not a gale. It is a slow, steady, almost gentle falling, like snow that is not cold. It lands on their hands, their shoulders, their hair. It does not irritate the skin. It does not burn. It simply *accumulates*. And the light on the horizon, the low amber glow that is not the sun and not a fire, is visible, and it is *steady*, and it has been steady for three weeks, and it is not going to stop.

The harbormaster, Cressa, is here. She has been here every day for three weeks. She is not a fighter. She is a woman with salt-stained hands and a practical mind, and she is *afraid*, and she is saying it in the flat, factual way of a person who has run out of metaphors and is left with the raw data. *It is not weather. It is not a storm. It is coming from the south. It is getting thicker. The ships have stopped. The trade routes are closed. And I do not know what it is, and I do not know how to stop it, and I do not know if I am supposed to be afraid, but I am, and I am telling you, because you are the ones who are going to decide what we do, and I need you to see it before you decide.*

The party should feel the weight of what they are being asked to name. The ash is not an army. It is not a fleet. It is not a siege engine. It is a *byproduct*. It is the visible residue of a kingdom that is not conquering, not invading, not attacking. It is *being*. It is existing. And the existence is producing ash, and the ash is falling on Saltmere, and the people of Saltmere are breathing it, and the trade is stopping, and the fear is growing, and none of this is a threat in the way the party is used to threats, and all of it is a threat in the way that matters.

The encounter ends not with a resolution but with a *question the party carries back to Saltmere*: what does it mean to name a kingdom that is not attacking you but is *changing the air you breathe*? And the answer is not a combat answer. The answer is a political one, and it is a moral one, and it is a question the party will not be able to close in this chapter, because the next chapter will make it worse, and the chapter after that will make it personal, and the final chapter will make it *theirs*.