---
id: the-summons
location: the-ashen-hall
involves:
  - kaelen
  - enforcer-darius
chapter: the-call
---

The party arrives at the Ashen Hall on foot, having walked the coastal road from Saltmere. The compound is visible from the last stretch of cliff, a dark rectangle in the grey morning light. The gate is open. The guards do not stop the party. They do not need to. Kaelen is waiting in the hall, and he is waiting *patiently*, which is more unsettling than if he had been pacing.

The meeting itself is not a confrontation. It is a *recognition*. Kaelen does not accuse. He does not threaten. He does not even, in the first ten minutes, mention the debt. He talks. He talks about the Ash, about the years since the ford, about the long, slow work of building something out of nothing. He is courteous. He is specific. He mentions the party by name—not as a title, not as a description, but by the names they use, which means he has been *listening* for a long time. He mentions a small detail about one of the party members, something from a session or two ago, something they said in a tavern or a market, something they had forgotten they said. He remembers. He remembers everything.

Then he makes the request. It is small. It sounds small. *A word. A name. A single act of recognition before the harbor council. A public acknowledgment that the Ash is a people, a polity, a kingdom with a right to exist on the regional map. Not a conquest. Not a demand. A name.* The party should feel, in the moment, that this is reasonable. That this is the kind of thing they would do. That this is *them*.

The cost is not in the request. The cost is in what the request *unlocks*. The harbor council will have to vote. The militia will have to acknowledge. The regional trade agreements will have to be amended. The kingdom that was *scattered remnants, no settled territory* becomes a kingdom, and the other kingdoms in the region will notice, and the notice will have *responses*, and the responses will have *costs*, and the party will not see all of those costs yet. Kaelen knows. Kaelen has seen the shape of the thing. He is asking for the first thread. The rest will come, and it will be heavier, and the party will be holding it.

Darius is at the gate. The party can see him from the hall's window, standing at attention, not looking in, not looking out, just *there*. If the party tries to leave without answering, he will not stop them. He will simply say, in his flat voice, *the number is noted*. And then he will go back to his post. And the party will walk back to the road. And the number will be noted. And it will be there when they get back to Saltmere, and it will be there when they sleep, and it will be there in the morning, and it will not go away, because it is not a threat, it is a *fact*, and facts do not go away, they just get *larger*.