---
id: nellys-den
connections:
  - saltmere-harbor
  - the-charred-shore
chapter: the-call
---

Beneath the market district of Saltmere, in a tangle of cellars, abandoned cisterns, and the old root-cellar network that the town was built on, there is a place that is not on any map. The entrance is behind the chandler's shop—past the shelves of tallow candles, through a door that is locked from the inside, down a flight of stone steps that are older than the shop above them. The air changes. The smell of tallow gives way to damp stone, candle smoke, and the particular must of a space that has been inhabited by a small number of people for a long time.

The den itself is a network of three rooms connected by narrow passages. The largest is a workshop: a workbench cluttered with half-finished mechanical components (gears, springs, a small clockwork bird that does not fly but *chirps*), a pile of correspondence in a variety of hands, a locked strongbox. The second room is a sleeping alcove—two thin mattresses, a child's blanket, a half-eaten loaf of bread. The third room is a small archive: shelves of papers, organized by hand, cross-referenced with a system of colored threads tied to wooden pegs. It is the workspace of someone who is very good at knowing things, and who has been doing it for a long time.

Whisper Nell is not a child in the way the town's children are. She is fifteen, perhaps sixteen, with a face that is weathered beyond her years and hands that are quick and small and never still. She speaks in short sentences. She does not say *yes* or *no*; she says *that is so* or *that is not the case*. She has been watching the party for two days, and she is not afraid of them, which is notable, because the people who come to the den are usually the kind of people who make fifteen-year-olds afraid.

The archive in the third room contains a file, bound in a strip of grey leather, labeled in Nell's cramped handwriting: *K. — the thing we did. The night at the ford.* The thread on this file is red.