---
id: the-charred-shore
connections:
  - saltmere-harbor
  - nellys-den
  - the-ashen-hall
chapter: the-call
---

The Charred Shore is a stretch of black sand and broken rock four miles south of Saltmere, where the coastline drops into a series of shallow inlets that fill at high tide and empty at low. It is called the Charred Shore because, in the town's local history, a fishing fleet was lost here in a storm two generations ago and the sand was blackened by the burning of the boats' tar. The name is old and the story is old, and for a long time it was just a name.

Now the name is a fact. The sand is black. The rock is black. The shallow inlets are filled with a fine, grey particulate that settles when the water drains at low tide, and the particulate smells of woodsmoke and something mineral, something that is not quite ash but is close. The tide brings it in from the south, from a direction the local charts mark only as *open water, no known settlements*. It has been coming in for three weeks. The amount is increasing.

The visual is difficult to ignore. At low tide, the inlets are shallow pools of grey slurry. The black sand is streaked with a fine white residue where the particulate has been washed and redeposited. The rock formations, normally a warm brown, are coated in a layer of grey that will not brush off. And on the horizon, on certain days, there is a *color*—a faint, diffuse amber glow that is not the sun, because it is visible at midday, and is not a fire, because there is no smoke column. It is simply *there*, a low, steady, sourceless light on the water, like a hearth seen through a very long glass.

This is where the party will see what the Kingdom of Ash has become. Not a kingdom in the abstract. A kingdom that is *burning*, or that is *made of burning*, or that is so deeply and fundamentally *changed* that the only visible evidence from this distance is the ash that falls like slow snow and the light that does not explain itself. The harbor masters are afraid. The militia is confused. The people of Saltmere are watching the sky and asking questions they do not want to ask out loud.

The shore is accessible from Saltmere by a coastal path that runs along the base of the cliff, or by a rough track from Nell's den that cuts through the salt marshes. The Ashen Hall's grounds are visible from the northern headland, a dark rectangle against the grey sky, a day's walk away but *there*, a fixed point on the landscape that was not there three months ago.