---
id: the-ashen-hall
connections:
  - saltmere-harbor
  - the-charred-shore
chapter: the-call
---

The Ashen Hall sits on a promontory a day's walk north of Saltmere, where the coastal road narrows between a cliff and a narrow river that feeds the sea. It is not a castle. It is not even a large house. It is a *compound*: a rectangle of flat stone walls, perhaps two hundred paces long, enclosing a courtyard, a long hall, and a handful of smaller buildings. The stone is dark grey, almost black, and it has the particular quality of ash-compactite—volcanic grit pressed into a building material. It is not local stone. The party will notice this. The locals will not be able to explain it.

The compound is *occupied*. There are perhaps twenty to thirty people in and around the walls: guards at the gate (armed, but not aggressive—pikes and crossbows, a disciplined posture that suggests training the region does not normally produce), workers hauling water and tending a small kitchen garden, a pair of scribes in a lean-to building near the hall entrance. There is a forge that is lit. There are horses. There is a sense of *function*, of a place that is not a ruin being inhabited but a purpose being maintained.

The hall itself is sparse and severe. A long table. Benches. A fire that is kept low and controlled. The walls are bare except for a single shelf of books—actually books, not scrolls—and a framed map of the region that the party will recognize from the local almanacs, except that one small kingdom, one that the almanacs list as *scattered remnants, no settled territory*, is now shaded in a deep, confident red. Kaelen's name is not on the map. He does not need it to be.

The air in the hall smells of woodsmoke, salt, and something faintly sweet, like burnt sugar. It is a small, cold, precise smell. It is the smell of a man who has been planning for a very long time and is not in a hurry to be interrupted.