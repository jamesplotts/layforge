---
id: saltmere-harbor
connections:
  - the-ashen-hall
  - nellys-den
  - the-charred-shore
chapter: the-call
---

Saltmere Harbor is a working coastal town of perhaps eight hundred souls, built into the crook of a rocky inlet where the grey sea meets a low headland. The architecture is practical: stone warehouses with salt-bitten timber framing, fishing nets drying on every available wall, the smell of brine and tar woven into everything. The town is not rich, but it is *lived-in*. There are children's games in the cobbles, a chandler's shop that smells of beeswax, a tavern called The Bilge where the ale is mediocre and the gossip is excellent. The party has been in or near Saltmere for the better part of a week, and the townsfolk have begun to recognize them—not as legends, but as *the visitors*, the ones who stay a little too long and ask a little too many questions.

The harbor itself is a tangle of moored fishing boats and two or three larger merchant vessels that come in seasonally. The sea is the color of pewter today, and there is a faint, almost imperceptible grey film on the water's surface that the locals dismiss as weather. It is not weather. The harbormaster, a broad-shouldered woman named Cressa, has noticed the film and said nothing, but her eyes follow the party when they look at the horizon.

The town's political structure is simple: a harbor council of five merchants, a militia of perhaps thirty able-bodied men and women who guard the docks at night, and a magistrate who handles disputes and keeps the roads clear. The militia is not trained for war. They are fishers and coopers with pikes. This is important, and the party will learn why before the end of the chapter.

The Ashen Hall is a day's walk north, up a coastal road that runs between the cliff face and the sea. Whisper Nell's den is closer—a web of abandoned cellars and service tunnels beneath the market district, accessible through a chandler's shop that does not officially exist.