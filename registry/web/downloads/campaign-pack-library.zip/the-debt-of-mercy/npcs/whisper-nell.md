---
id: whisper-nell
location: nellys-den
stat_block_ref: SRD Commoner
voice: short, flat, declarative; avoids contractions; speaks as if each sentence is a fact being recorded for a ledger she will show someone later; rarely uses the word 'I'
chapter: the-call
---

Whisper Nell was twelve when the party passed through the ford. She was not a combatant. She was a runner, a messenger, a child who had been sent to deliver a message to a man who was about to be captured and was not going to survive the next hour. She was hiding in the reeds. She saw the whole thing. She did not speak, because she was twelve and the people who were speaking were the people who made the rules, and the rules were being made with a blade and a choice, and she was not in the room.

She has been an informant ever since. Not because she is good at it, though she is. Because it is the one thing that lets her be *close to the story without being in it*. She gathers. She records. She keeps the threads. She does not act, because acting is what the people with blades do, and she does not have a blade, and she is not going to ask for one, and the story is the thing that matters and the story does not need a blade.

She remembers the night at the ford with a clarity that is not quite natural. Not magical—she is not a mage, she has no spell on her, she is a fifteen-year-old with a soot-streaked face and a locked strongbox. But she *keeps* it. The exact words. The exact order. The thing that was said, and the thing that was not said, and the thing that was said that was not true. She has kept it for three years. The red thread on the file in her archive is not a metaphor. It is a physical marker. She tied it herself, the night after, in the den that did not exist yet, with her own hands, because she could not forget it and she could not let it go and the only way to hold it was to put it somewhere she could find it again.

She is not working for Kaelen. She is not working for the Kingdom of Ash. She is working for the *accuracy of the record*. If the party asks her what she wants, she will say: *I want it to be true. I want the thing that happened to be the thing that is remembered. I do not want it to be the thing that is convenient.* This is not a neutral position. It is a position that will complicate every negotiation the party attempts, because the truth, as she has kept it, is not the truth the party told themselves.