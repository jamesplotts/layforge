---
id: enforcer-darius
location: the-ashen-hall
stat_block_ref: SRD Veteran
voice: blunt, economic, almost bored; speaks in fragments as if completing a sentence costs him something; refers to the debt as 'the number' and to Kaelen as 'the master' without affection or contempt, just identification
chapter: the-call
---

Darius is not at the first meeting. He is in the compound, at the gate, one of the disciplined guards, but he is not *engaged*. He is watching. He is not hostile. He is *accounting*. He looks at the party the way a clerk looks at a ledger entry that has been outstanding too long: not with anger, but with the quiet, persistent certainty that the entry will be resolved and that the resolution will be *final*.

He is Kaelen's lieutenant in the way that a load-bearing wall is a building's support: structurally essential, not decorative, not the point, but the thing the point stands on. He is not a villain. He is not a monster. He is a man who was in the Ash, who saw what the Ash was before the party's mercy and after, and who has made a simple arithmetic that he will not revise. The party spared the Ash. The Ash survived. The Ash is now a kingdom. The kingdom has a number. The number is owed. The number will be paid. This is not a negotiation. This is a *settlement*.

In this chapter, Darius does not speak to the party. He is present at the Ashen Hall, at the gate, in the compound. He is the reason the party feels *watched* when they walk the grounds. He is the reason Kaelen's request, which sounds reasonable, has a *weight* behind it that is not merely social. If the party tries to walk away, if they try to dismiss the debt, if they try to be clever—Darius is the thing that makes cleverness expensive. He does not need to draw a sword. He needs to *look at them* and say, in his flat, fragmentary way, *the number is not closed*. And then he goes back to his post. And the party walks back to the table. And Kaelen pours them a second cup of tea, because he is gracious, because he is grateful, because the debt is not a threat, it is a *fact*, and Darius is simply the fact's shape.

He will be more than a presence in later chapters. In this one, he is the ceiling on the party's options. He is the reason the answer to *what happens if we just leave* is not *nothing happens* but *the number follows*.