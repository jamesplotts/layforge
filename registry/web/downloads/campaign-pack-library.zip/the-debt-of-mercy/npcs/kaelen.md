---
id: kaelen
location: the-ashen-hall
stat_block_ref: SRD Knight
voice: measured, courteous, precise; never raises his voice, which makes every word land harder; speaks in complete sentences as if each one is a clause in a contract
chapter: the-call
---

Kaelen is not what the party remembers. They remember a captured noble, a retainer of the Ash king, bound and bleeding in the mud of a ford at night, begging not in eloquent terms but in the short, broken gasps of a man who has been hit and is not sure he will stand again. They remember choosing. They remember the weight of the choice in their hands. They do not remember what he said afterward, because he was too hurt to say much, and they were too busy deciding to listen.

Now he is standing in a hall that has a forge and a library and a map of the region, and he is *well*. Not merely unharmed. Well. His hands are steady. His voice is even. He has the particular calm of a person who has spent a long time being afraid and has finally, carefully, put the fear somewhere out of reach. He is not smiling. He does not need to. His gratitude is in the *structure* of the room, in the books on the shelf, in the disciplined guards at the gate, in the fact that he is here and not in a ditch and not dead and not scattered.

He is not evil. This is important. He believes, with the full weight of his conviction, that the party owes him. Not his life—he does not frame it that way, because he is not a man who thinks in transactions of flesh. He frames it as *continuity*. They let his line continue. They let his people survive. They let the story of the Ash go on. And a story that goes on has obligations. The debt is not a price. It is a *thread*, and he has been weaving it for a very long time, and he is coming to collect not because he is cruel but because the thread is complete and he does not know how to set it down.

His request, when he makes it, is reasonable on its surface. A small thing. A favor. A token. The cost, which he does not mention in the first meeting, is not small. The party will discover the cost later. Kaelen does not know that the party will discover it. He is not hiding it. He is *protecting them from the shape of it until they are ready to hold the shape*. This is not a lie. It is a kindness that has the geometry of a trap.