---
id: yara-voss
location: the-wardens-hold
stat_block_ref: SRD Scholar
voice: quick, precise, the cadence of someone reading from a text she wrote and is now embarrassed by
chapter: the-voyage-and-landing
---

Yara Voss is a geographer, a cartographer, a woman who has spent eleven years chasing an island that should not exist and has been told by three separate academic councils that she is either delusional or dangerous. She is neither. She is correct, and she is not done being correct. Her chart of Kaelthorne is the best they have, and it is wrong in at least six places, and she knows which six, and she will tell the party which six if they ask, but she will not tell them the seventh, because the seventh is the one that means the island is not where she thinks it is, and she is not ready to be wrong about that. She is sharp-tongued, sleepless, and she carries her instruments in a leather case that she holds against her chest like a child. She will argue with the party about headings, about tides, about the correct nomenclature for the wyverns they see overhead. She will not argue about the Loom. She has stopped believing there is a Loom. She has stopped believing there is a Chorus. She has stopped believing the island is a place. She believes it is a *process*, and she is afraid of what a process does when it is interrupted.
