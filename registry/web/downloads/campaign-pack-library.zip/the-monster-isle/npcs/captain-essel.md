---
id: captain-essel
location: the-wardens-hold
stat_block_ref: SRD Veteran
voice: clipped, flat, the words of someone who has stopped expecting the sea to make sense
chapter: the-voyage-and-landing
---

Captain Esstel Draak is forty-three, broad in the shoulders and narrow in the eyes, with a left hand that ends in three knuckles where a fourth used to be. She has made the crossing to Kaelthorne four times. She does not speak of the first three. She speaks of the fourth in short, practical sentences: the weather, the heading, the state of the hull. She does not speak of the crew. She does not speak of what the nails do when the water goes still. She will give the party their orders, their watches, their rations, and her one standing rule: *Do not go below the waterline without my leave. Do not go above the treeline without a rope. Do not look at the island before I tell you it is time to look.* When the party asks why, she will say: *Because looking is a conversation, and I have not yet decided what to say.* She is not brave. She is disciplined. There is a difference, and on the Warden's Hold, the difference is the only thing between the crew and the water.
