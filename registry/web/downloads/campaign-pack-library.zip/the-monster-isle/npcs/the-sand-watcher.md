---
id: the-sand-watcher
location: sorrow-bay
stat_block_ref: SRD Commoner (modified, beast-folk features)
voice: slow, deliberate, each word chosen as if it costs something, a voice that sounds like it is being spoken through water
chapter: the-voyage-and-landing
---

The Sand-Watcher stands at the tideline, knee-deep in the warm mineral surge that floods Sorrow Bay at high water. It was human once. The evidence is in the face: the jaw is right, the eyes are the right shape, the mouth moves the right way when it speaks. The rest is not. The skin is a deep grey-brown, scaled in fine overlapping plates from the collar down. The fingers are long, too long, and the nails are flat and dark and the shape of a wyvern's claw. The ears are set too low and too wide. It stands in the water and does not move, and when the party's longboat slides up the sand it does not startle, does not raise a hand, does not run. It waits. It has been waiting, it will say, for a time that does not have a number. It knows what the party is. It knows what the island wants. It does not know what the party wants, and this is the thing that interests it. It will guide them to the drowned path. It will not guide them past the clearing with the mouth in the rock. It will stand at the edge of the clearing and say: *You may go further. I will not follow. I have followed too far, once. I do not intend to follow that far again.* It does not explain what it followed. It does not need to. The tracks on the path are enough. The small human footprints, pressed deep, leading in. It was one of them. It is the only one that got out.
