---
id: kaelthorne-monster-island
title: "Kaelthorne: The Island of Teeth and Thorn"
level_range: "2-10"
pvp_policy: pve_only
maturity_tier: standard
image_maturity_tier: family_friendly
shared_knowledge: strict
tone:
  - gothic
  - survival
  - wonder
  - danger
  - ecological
author: AI-generated
chapters:
  - id: the-voyage-and-landing
    title: "The Voyage and Landing"
    level_range: "2-3"
    summary: "The party sails across the Cerulean Reach aboard the Warden's Hold, enduring a whispered storm, a dredging sea-beast, and a navigational crisis that nearly strands them. They make landfall at Sorrow Bay and face their first territorial creatures in the drowned jungle path, while a ruined lighthouse holds the last map of the island's surface."
  - id: the-monster-territories
    title: "The Monster Territories"
    level_range: "4-6"
    summary: "The party explores three distinct monster territories—the Bristlewood (a giant-ape dominion), the Ashen Spires (an elemental forge), and the Tidal Crypts (a drowned undead court)—uncovering the food chain that binds Kaelthorne's ecosystem and the rivalries between its apex predators."
  - id: the-chorus-stirs
    title: "The Chorus Stirs"
    level_range: "7-8"
    summary: "The island's central engine, the Convergence Loom, begins its seasonal feeding cycle. The party must navigate escalating conflicts between monster factions, broker impossible alliances, and descend into the volcanic caldera where the accumulated wills of ten thousand consumed creatures press against the surface of reality."
  - id: the-hollow-heart
    title: "The Hollow Heart"
    level_range: "9-10"
    summary: "The party confronts the Chorus itself at the magma-forged heart of Kaelthorne. They must choose: shatter the Loom and release the trapped wills (destroying the island's magic and the creatures it sustained), bind it and take on its burden, or find a third path the island's lost builders never imagined."
---

## Overview

Kaelthorne is not a place that appears on any chart. It drifts. Once every forty years, a volcanic island rises from the Cerulean Reach, wreathed in steam and the smell of iron and crushed orchids, and for a single season it holds a congregation of every predatory, magical, and monstrous creature drawn within its magnetic pull. Trolls walk the black-sand shores. Wyverns nest in the basalt teeth of the mountains. Something vast and patient coils in the caldera at the island's core, and the whole living web of Kaelthorne orbits it like moths around a lantern.

The island is the product of the Convergence Loom—an arcane engine built three thousand years ago by a civilization whose name has been ground to dust by the tides. The Loom was designed to harvest the kinetic force of predatory intent, converting the drive to hunt into ambient magical energy. It worked. Too well. It broadcast a signal across the material plane that every creature with fangs, claws, or a taste for flesh could hear, and Kaelthorne became a gravity well for every monster in the world. Those that survived the season were consumed at the Loom's peak, their wills folded into a collective consciousness the survivors of earlier cycles call the Chorus. Those that escaped carry fragments of the island's logic in their blood, and they hunt, they breed, they build small kingdoms in the jungle and the salt flats, and they fight over scraps of the Loom's radiance.

The party's reason for being here will vary—mercenary contract, scholarly obsession, a missing crewmate, a debt of blood. What is fixed is the shape of the problem: Kaelthorne is a closed system, and it is hungry. The party must thread a needle of fang and fire between the island's apex predators, survive its shifting geography, and reach the caldera before the Loom's next feeding cycle begins. What they do when they arrive is their own story.

## Hooks

- **The Cartographer's Debt.** Yara Voss, a disgraced geographer from the Archipelago Survey, has spent eleven years tracking Kaelthorne's drift. She has one chart, one season, and a contract with the party: get her to the island's center and back, or she dies owing a debt she cannot pay. She is not a hero. She is a mapmaker with a grudge against the world that dismissed her work.

- **The Warden's Hold.** The merchant vessel that carries the party across the Reach is not merely a ship. Its hull is studded with iron nails pulled from a temple no one will name, and its captain, Esstel Draak, has made this crossing four times. She does not speak of the three previous crews. The ship itself seems to know where it is going.

- **The Sand-Watcher.** A figure stands at the tide line on Sorrow Bay, patient as geology. It was human once. It was not, before. It watches the party land and does not flee. It wants them to come inland. It does not want them to come *too* far inland.

- **The Season's Clock.** The Loom feeds on the autumn equinox. The party has approximately three weeks of game time before the island's apex predators turn inward, the Loom's pull strengthens, and the Chorus begins to sing. Every hour spent exploring the surface is an hour closer to the caldera, and every territory they disturb shifts the food chain in ways they cannot fully predict.

- **The Missing Crew.** A fishing vessel went into the Reach six days ago and did not come out. Its log, recovered from a drift-wood cache in the jungle, ends with a single line: *It is not a monster. It is a garden.* What kind of garden grows in the bones of a ship?
