---
id: the-wardens-hold
connections:
  - sorrow-bay
chapter: the-voyage-and-landing
---

The Warden's Hold is a three-masted cutter of modest draft, her hull blackened with iron oxide and studded with rows of pale nails that do not belong to any smithy in the Reach. She is not fast, but she holds the line through seas that should break her. The deck is salt-worn and scarred with old gouges—claw marks, or something like them, run in long parallel lines across the portside rail. There is a faint smell of ozone and cold metal that no amount of scrubbing removes.

Below deck, the crew's quarters are cramped but clean. A chart table in the wheelhouse holds a hand-drawn chart of the Reach that updates itself in ways Yara Voss will describe as "convenient" and Captain Esstel will describe as "the sea's own handwriting." The ship's hold carries three weeks of supplies, a longboat, iron hooks, and a coffer that the crew does not open and the captain does not discuss.

The Hold is not a location so much as a moving room in a larger machine. During the voyage, the sea around her shifts. The water goes still in a way that is not calm but *paused*, the waves holding their shape like a held breath. The compass needle does not spin—it *points away*, as though the island is not a destination but a correction. The Hold resists this. She is built to. The nails hold. The hull groans but does not split. The crew moves with the practiced economy of people who have learned that the sea here is not a road but a throat, and the ship is the thing that must not be swallowed.

When the Hold finally breaks the last band of fog and Sorrow Bay opens below the bow, the transition is so abrupt that several crew will stagger at the rail. One moment: grey water, grey sky, the long silence of the open Reach. The next: black sand, green-black jungle pressed against the shore like a fist against glass, and the smell of the island—wet iron, crushed fruit, and something older, something that smells like the inside of a cave that has been breathing for a very long time.
