---
id: sorrow-bay
connections:
  - the-wardens-hold
  - the-drowned-path
  - broken-lighthouse
chapter: the-voyage-and-landing
---

Sorrow Bay is a crescent of black sand, broad enough for the Warden's Hold to beach on a gentle arc. The water at the shallows is the color of weak tea, then drops to a deep green-black within twenty yards of the shore. The sand is not sand so much as fine volcanic glass, ground to powder by tides that have been working it for centuries. It is warm to the bare foot and faintly gritty, and it holds the shape of footprints for hours before the heat erases them.

The bay is not empty. Along the tideline, the tracks of something large and multi-limbed press into the glass-sand in parallel lines. A wyvern's droppings—yellowish, still warm—sit in a patch of sea-grass near the head of the beach. The jungle at the bay's edge is thick and dark, a wall of fronds and twisted trunks that closes within forty paces of the waterline. The trees are not tropical in any way a botanist would recognize; their bark is ridged like bone, their leaves are broad and waxy and faintly iridescent, and they grow in dense clusters that leave the understory in near-total darkness. The air here is thick, humid, and carries the low, constant hum of insects that have no business being this large.

The sand at the bay's eastern end slopes upward to a low promontory where the broken lighthouse stands. Between the beach and the jungle, a path—worn, not natural, but not built by human hands—cuts inland toward the drowned path. The path's edges are lined with stones placed deliberately, each one carved with a symbol the party may recognize from Yara's charts: the old mark of the Reach, the compass rose of a civilization that should be three thousand years dead. The path leads in. The jungle does not want them to. The wyverns overhead are watching.

Tide tables matter here. The bay floods at high water, and the water that comes in is not the sea but a warm, mineral-rich surge from somewhere beneath the island's surface. It carries sediment, small bones, and occasionally things that are still moving. The crew must be ready to beach the Hold quickly and move inland before the next high water, or risk losing the ship to a tide that does not obey the moon.
