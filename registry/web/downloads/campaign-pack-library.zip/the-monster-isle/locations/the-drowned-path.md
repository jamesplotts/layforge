---
id: the-drowned-path
connections:
  - sorrow-bay
  - broken-lighthouse
chapter: the-voyage-and-landing
---

The drowned path is not a road. It is a corridor through the jungle, perhaps thirty paces wide, where the undergrowth has been cleared by something that does not use axes. The trees on either side lean inward, their canopies interlocking overhead in a vault of leaf and shadow. The path's floor is a mosaic of packed mud, exposed root, and the occasional flat stone that has been worn smooth by a great deal of traffic. The tracks here are layered: the broad four-toed prints of a giant ape, the narrow three-toed scuff of something reptilian, the parallel claw-gouges of something that drags itself, and—most unsettlingly—bare human footprints, small, pressed deep, leading in a direction the party is not yet going.

The air in the corridor is still. Not calm—still, as in the eye of a storm. The insects that hummed at the bay are silent here. In their place is a low, rhythmic sound, like breathing, coming from everywhere and nowhere. The humidity is so dense that moisture beads on exposed skin and the party's lanterns smoke and dim. The light that filters through the canopy is green and diffuse, and it does not cast shadows so much as *thicken* them, as though the darkness has a texture the light is struggling to part.

Halfway along the path, the corridor opens into a small clearing where a stream crosses. The stream is warm—blood-warm—and its water runs clear over a bed of pale stones. On the far bank, the tracks converge. The ape prints, the reptilian scuff, the drag-gouges, the small human footprints. All of them lead to the same point: a rock face where the jungle has been peeled back, revealing a seam of dark stone that runs down into the earth. It is a mouth. The stone is shaped like a mouth. And it is warm to the touch, and it smells of iron and something sweet, like overripe fruit left too long in the sun.

This is the island's first lesson: everything on Kaelthorne is connected. The stream feeds the jungle. The jungle feeds the creatures. The creatures feed the Loom. And the Loom feeds the Chorus. The party is in the middle of a chain, and the chain does not care what they are. The tracks of the small human footprints are the most dangerous sign in the corridor, because they mean someone else is here, someone else has been walking this path for longer than the party has been on the island, and someone else's story is already being told in the mud.
