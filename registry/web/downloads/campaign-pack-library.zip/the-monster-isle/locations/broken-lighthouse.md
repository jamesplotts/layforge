---
id: broken-lighthouse
connections:
  - sorrow-bay
  - the-drowned-path
chapter: the-voyage-and-landing
---

The lighthouse stands on a low basalt promontory at the eastern end of Sorrow Bay, and it is broken in the specific way that implies it was working until recently. The tower is white stone, roughly cylindrical, forty feet to its base. The top quarter is gone, sheared off at an angle that suggests not collapse but *cutting*. The interior is a wide stairwell that spirals up into the dark. The door at the base is open. It has been open for a long time. The hinges are worn to a glaze, and the door itself is missing one leaf, the other hanging at an angle that lets a slant of green light fall across the threshold.

Inside, the walls are lined with a material that is not plaster. It is a thin, translucent layer, like pressed resin, and beneath it, faintly, the shapes of things are preserved: a compass, a coil of rope, a small bird with its wings spread. The resin is warm. It pulses, very slowly, with a rhythm that the party will recognize if they press an ear to the wall: it matches the breathing they heard on the drowned path. The lighthouse is part of the island's web. It was built to be a signal, and the signal it sends is not light. It is *presence*. It tells things that are out in the water: *something is here. Something is standing still. Something is watching.*

At the base of the stairwell, a workbench holds a set of navigational instruments, a leather journal, and a chart. The chart is Yara's. It is three weeks out of date. The last entry in the journal is written in a hand that is not Yara's, in a language the party may not know, and it says, in a translation the party can make with effort: *The light is not for the ships. The light is for the teeth.*

Above the workbench, on the first landing, the stairwell is blocked by a screen of woven kelp and bone. Beyond it, the stairs continue up into the dark, and the air coming down smells of salt and sulfur and the particular sweetness of a place where many things have died and been kept. The lighthouse is a trap. It is also a map. It is also a tomb. The party will have to decide which of those they want it to be, and the island will not let them have all three at once.
