---
id: the-dredge
location: the-wardens-hold
involves:
  - captain-essel
chapter: the-voyage-and-landing
---

The Dredge surfaces on the third morning, and it is not a single creature. It is a colony. A mass of pale, segmented bodies, each one the length of a longboat, joined at the thorax in a lattice of chitin and cartilage that shifts and reconfigures as the party watches. It rises from the Reach in a column of disturbed water and silt, and its upper surface is a platform of interlocking segments, on which smaller creatures—things with too many legs and eyes the size of coins—scuttle in dense, coordinated clusters. The Dredge does not attack. It *positions*. It moves to the Hold's port side and holds, its segments grinding and clicking in a rhythm that the party will recognize, with a sickening lurch, as the same rhythm as the breathing in the drowned path. The Dredge is part of the chain. It is a mid-link. It is here because the island needs it here, and it is patient, and it is waiting for the Hold to make a mistake.

The encounter is a negotiation conducted in the language of threat. Captain Esstel will not engage. She will hold course, slow speed, and she will order the crew to stand the guns ready but not to fire. The Dredge's smaller creatures will press close to the hull, tapping, testing the nails, probing the seams. The party's role is to hold the ship steady, to manage the crew's fear, to keep the longboat ready for the two crew members who will want to go below and will need to be stopped. The Dredge will hold for an hour. Then it will subside, slowly, with a sound like a great exhalation, and the Reach will be empty, and the water where it was will be warm, and the Hold will be four hours closer to the shore, and the nails in the hull will be warm to the touch, and no one will discuss it.
