---
id: first-blood
location: sorrow-bay
involves:
  - the-sand-watcher
chapter: the-voyage-and-landing
---

The party lands at Sorrow Bay on a morning tide, the Hold beached on a gentle arc of black glass-sand, the longboat pulled up the shingle. The air is thick and warm and the jungle is a wall of green-black at the bay's edge. The Sand-Watcher is at the tideline, as it has been, as it will be, standing in the mineral surge with its long grey-brown fingers trailing in the water. It watches them come. It does not speak until the longboat is fully on the sand and the crew is ashore and the Hold's anchor is weighed. Then it says, in its slow, water-thick voice: *You are early. The others were early, too.* It will ask the party what they are. It will not accept the answer it is given. It will ask again, in a different way, and the second question will be harder to answer.

The first blood is not a fight. It is a *claim*. As the party moves from the beach toward the drowned path, the jungle presses in. The tracks are layered. The wyverns overhead shift their perches, their calls rising in pitch, a sound like glass dragged over glass. The Sand-Walker will pause at the tree line, where the light thickens and the insects resume their hum, and it will say: *The path is yours. The clearing is not. Do not go past the mouth. I cannot protect you past the mouth. I can only tell you that the mouth is not a mouth, and the breathing is not breath, and the things that live in the breathing are not the things you will expect.* It will point inland. It will step back into the water. It will stand in the tide, watching, until the party is out of sight in the green-dark of the corridor, and then it will be gone, and the sand where it stood will be smooth, and the water will be warm, and the hum of the insects will be very loud, and the wyverns will be very high, and the path will be waiting, and the path will not be waiting, and the party will have to decide which of those is true and move accordingly.
