---
id: storm-of-whispers
location: the-wardens-hold
involves:
  - captain-essel
  - yara-voss
chapter: the-voyage-and-landing
---

The storm comes on the second night of the crossing, and it is not a storm. The sky does not darken. The wind does not rise. The sea does not heave. Instead, the air *thickens*. The sound of the waves stops, and in the silence that follows, the party hears voices. Not words, at first. Shapes. The grammar of speech without the content, the cadence of a language they almost recognize. The voices are coming from the water, from the air, from the wood of the Hold's hull. They are coming from inside the party's own skulls, and this is the part that is not fair.

The storm lasts six hours. During it, the crew must maintain the ship's course against a resistance that is not wind but *intention*. The compass needle pins to a heading that is not the island's. Yara's chart begins to redraw itself, lines shifting, coastlines migrating, the island's position on the page sliding a few degrees to the east and back. Captain Esstel takes the helm and holds the line with a discipline that the party will have to match at the rigging, at the bilge, at the lookout. The whispers are not random. They are *testing*. They are listening to the party's thoughts, finding the gaps, the doubts, the fears, and they press on those gaps with a pressure that is not physical but *structural*, as though the storm is looking for the load-bearing wall in the party's resolve and applying a slow, even weight until it cracks.

The resolution is not a fight. There is no monster to kill, no spell to cast. The storm breaks when the party chooses, collectively, to stop listening. Not to resist. To stop. To let the voices be just voices, just sound, just the sea being the sea. The moment the last voice is acknowledged and then *released*, the air thins, the waves resume, the compass finds its needle, and the Hold heels into the real wind. The crew will be shaken. Two will be weeping. Esstel will pour a measure of rum and hand it to the nearest person and say, in her flat, practical voice: *We are four hours from the shore. Do not speak of what you heard. We are four hours from the shore.*
