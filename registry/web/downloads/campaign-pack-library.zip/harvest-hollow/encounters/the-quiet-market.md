---
id: the-quiet-market
location: harvest-square
involves:
  - mayor-pembroke
chapter: the-normal-town
---
The party enters Harvest Square on a bright morning, and the first thing
they notice is the smell: bread, honey, woodsmoke, and the green, clean
odor of cut grass. Vendors are setting up. A woman in a flour-dusted
apron is hanging a sign that reads *TODAY: WARM BUNS — 2 COPPER*. A
child of perhaps eight is running between the stalls, laughing, and
everyone is looking at her and smiling. It is lovely. It is also, within
five minutes, slightly wrong.

The wrongness is in the pattern. The vendors are too uniform in their
friendliness: every one of them offers the party a sample, a discount,
a seat, a glass of something. No one haggles. No one is impatient. No one
has a bad attitude about the weather or the price of eggs. The child who
was laughing stops running when a vendor calls her, and she walks over
quickly, and the vendor pats her head, and the smile on the vendor's face
does not quite reach the eyes.

Mayor Pembroke arrives mid-scene, in a clean coat, shaking hands with
half the square. He is charming, attentive, and warm. He introduces
himself. He asks where the party is from. He offers them a place to stay.
He is also, in the course of the conversation, very casually redirecting:
*"The Grange is closed for cleaning this week, but the Hollow Chapel has
a guest room, and the Alder Grove is lovely at this hour. And the
festival is in three days—three days, a full week of feasting, you won't
want to miss it."* He is building a cage out of politeness.

The constable, a heavy-set man named Davan, is on the square as well.
He is friendly. He is also counting the party. He will ask, with genuine
interest, how many of them there are. He will ask if they have weapons.
He will smile and say *"No offense, of course. The town is safe, but the
valley roads have been a little rough."* If the party mentions that
they heard something about a missing traveller from the next town, Davan
will smile, and the smile will be a fraction too long, and he will say
*"Ah, that. Yes. A small matter. Solved. Let me pour you some cider.*"

The scene resolves with the party accepted into the town, welcomed, fed,
and gently steered toward the Hollow Chapel for lodging. They are
comfortable. They are watched. And on the first night, one of the PCs
wakes at three in the morning to the sound of the ground breathing, and
cannot find the words for it in the morning.