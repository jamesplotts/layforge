---
id: the-herbalist-warning
location: greenweave-apothecary
involves:
  - elder-thalia
chapter: the-normal-town
---

Thalia gives the warning at dusk, in the apothecary, with the back door
locked and the front shutters half-drawn. The green light in the pot on
the stove is pulsing, slowly, in a rhythm that is not quite random. She
will not look at the party while she speaks. She is looking at the pot.

*"Three days. The drawing is in three days. I know who it is. I have
always known who it is, because it is always the same seven families, and
my name is in the list, and it has been in the list since Lily was nine,
and I have been in the list for twenty-two years, and I have not left,
and I do not know why I have not left, and I am asking you to leave for
me, because I cannot, because if I leave the town will come for what is
mine and I am not strong enough and you might be, and I am asking you
to find the green ledger in the Grange basement and read it and then
bring it to the chapel and give it to Sister Miriam, and then you will
know, and then you will decide, and I will be here, in this shop, in
this light, and if you do not come back I will understand, and if you
do come back I will be here, and I will not say thank you because there
is nothing you can do that is enough, but I will be here.*"

She will not give them the name of the child. She will not say Lily. She
will say *"a child, from a family you will know, because you have been
in this town for two days and you have seen the square and you have seen
the faces, and you will know, and that is enough."*

If the party asks her to come with them, to the chapel, to the grove,
to the Grange, she will say no. If they ask her why, she will say:*
"Because the last time I left this shop after dark, the constable was
in the lane with two men, and they were very polite, and I went back,
and I have been in the shop every night since, and I am not going to
be in the lane again."*

The scene ends with Thalia handing them a small cloth bundle: a sprig of
hollow moss, pressed between two sheets of waxed paper. *"If you go to
the grove after dark, and you hear the breathing, put this in your hand.
It will not stop it. But it will let you hear it clearly, and then you
will know that it is not your mind. And that is something. That is
enough for now."*