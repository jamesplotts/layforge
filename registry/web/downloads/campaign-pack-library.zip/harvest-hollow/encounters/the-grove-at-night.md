---
id: the-grove-at-night
location: the-alder-grove
involves: []
chapter: the-normal-town
---

The Alder Grove at night is not an encounter in the traditional sense.
There is nothing to fight. There is nothing to roll against. There is a
place, and a presence, and the party must sit with the fact that the
thing beneath them is real, and vast, and patient, and not hostile in
the way that a monster is hostile, because it does not have a concept
of hostility. It has a concept of hunger, and a concept of the
arrangement, and in the arrangement, the town brings it what it wants,
and it gives the town what the town needs, and it does not understand
why the town is afraid of it, because from where it stands, the
arrangement is simply the shape of the world.

The party arrives on foot, at night, either following Thalia's hint or
because Miriam suggested it. The grove is dark and still. The stream has
stopped, or rather, it is still there, but the sound has changed,
become lower, as if the water is moving more slowly, as if the ground
itself is pulling the water down. The moss is thick underfoot. The air
is warm. Not comfortable warm. *Warm* in the way that a living thing is
warm. The hollow beneath the alders is a depression in the earth, maybe
four paces across, and the soil in the center is soft, and if a PC kneels
and presses their hand into it, the ground is *warm*, and the warmth is
not from the sun, and the warmth has a rhythm, and the rhythm is slow,
and it is patient, and it is *aware* in the way that a deep current is
aware, not conscious, but present, and the fact of its presence is
enough to make the hair on the back of the neck rise, and the party
should feel, for a moment, like they are standing in the mouth of
something that is not angry but is *waiting*, and the waiting is not
malice, the waiting is simply the shape of a thing that has been
waiting for a very long time and does not experience time the way the
party does.

No damage. No saving throw. No encounter table. Just a moment of
profound, quiet wrongness, and the party should feel it, and it should
stay with them, and when they leave the grove and walk back to the
square, the square will be brighter, and the vendors will be friendlier,
and the bread will smell better, and the contrast will be the point.

If a PC asks Whisper a question—out loud, or in their mind—the answer
is not a voice. The answer is a feeling, a pressure behind the eyes, a
sense of *recognition*, as if the thing below is looking at them and
finding them *interesting* in the way that a child finds a new insect
interesting, not with malice, not with hunger in the way the party
understands hunger, but with the vast, patient curiosity of a mind that
has been thinking about the same thing for a thousand years and has
only now, for the first time, encountered something that is not part of
the arrangement.