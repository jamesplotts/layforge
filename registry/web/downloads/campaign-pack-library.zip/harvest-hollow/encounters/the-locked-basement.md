---
id: the-locked-basement
location: the-grange
involves:
  - mayor-pembroke
chapter: the-normal-town
---

The party finds the false panel on the second night, either through a
Perception check (DC 15) while exploring the Grange's archive room, or
because Thalia's whispered hint in the apothecary gives them the specific
location (the back wall, above the floor, where the wood grain runs
different). The panel opens onto a narrow staircase. The air coming up
from below is cool, dry, and faintly sweet—lavender, and something
older, something mineral and deep.

The cellar is as described in the location text. The ledgers are the
prize. Reading them is a DC 10 Investigation check to identify the
pattern: the same seven families appear in every Harvest record. The
"lottery" is not random. The dates are five years apart, to the day.
And in the final entry, dated three days from now, there is a name that
Thalia has already told the party: Lily Greenweave. The entry reads:
*"Selected by drawing. Family: Greenweave. Status: Accepted. Steward
assigned. White cloth prepared."*

Mayor Pembroke arrives at the top of the staircase at some point during
this reading. He does not raise his voice. He does not draw a weapon. He
stands in the doorway with his hands at his sides and says, very quietly,
*"I was hoping you would come this way, eventually. I was also hoping
you wouldn't. Sit down, please. There is something I need to tell you,
and I need you to hear it before I tell you why I cannot let you leave
with what you have just read."*

This is the first confrontation, and it is not a fight. It is a
disagreement between two people who both believe they are protecting
something. Pembroke will explain, in careful, measured language, what the
Harvest is. He will not defend it. He will *explain* it, the way a doctor
explains a necessary surgery: *"The entity below this town has been here
before the town. Before the valley. It feeds, and when it is fed, the
land is good. When it is not fed, the land is not. I have read the
older records. The ones before the town. I will not describe them. The
Harvest is a small, contained, predictable cost. I would rather pay it
every five years than find out what happens when it does not get what
it needs."*

The party can leave with the ledgers. They can take them to Miriam. They
can confront Thalia. They can go to the grove at night. They can also,
if they are not careful, trigger the first of three warnings from the
town: the constable will appear at the chapel door and say, very
courteously, *"The town has been asked to offer you a private audience
with the Mayor. I think you should go. I think it would be in
everyone's interest if you went."* And the smile will be a fraction too
long.