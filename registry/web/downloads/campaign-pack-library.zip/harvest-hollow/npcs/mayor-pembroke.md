---
id: mayor-pembroke
location: the-grange
stat_block_ref: SRD Veteran
voice: measured, paternal, quietly authoritative; never raises his voice, never needs to
chapter: the-normal-town
---

Mayor Aldric Pembroke has led Harvest Hollow for eleven years. He is a
tall, clean-shaven man in his early fifties, with the kind of hands that
have worked a desk and a field in equal measure. He shakes hands warmly.
He remembers names. He asks about the party's travels and then, naturally,
offers them a place to stay for the festival, because *"a town is nothing
without guests, and you look as if you have a long way to ride yet."*

He is not cruel. That is the important thing, and the thing that makes
him difficult to oppose. He genuinely believes the Harvest is necessary.
He has seen the ledgers. He has stood in the cellar and watched the green
light in the bowl and felt the warmth rise through the stone. He has
decided, with the cold arithmetic of a man who has to keep three hundred
families fed through winter, that three lives every five years is a
price the town can pay. He tells himself it is the only price. He tells
himself the "volunteers" are drawn fairly, by lottery, from families who
are already struggling, and that the town sends a steward to their homes
before the drawing to make sure they understand. He tells himself they
understand. He does not check whether they do. He does not check because
checking would mean looking at a mother's face, and he has not yet found
a way to look at a mother's face and still sleep.

In Chapter One, Pembroke is a host. He is welcoming. He is watchful. He
will not threaten the party, but he will *steer* them—toward the festival,
toward the chapel, toward the grove for a walk, away from the Grange
basement, away from Thalia's shop after dark. If pressed, he will become
quiet, formal, and final: *"The affairs of this town are its own. I am
sure you have a long road ahead. Let me see you to the door."* He means
it as a dismissal, not a threat. That is worse.