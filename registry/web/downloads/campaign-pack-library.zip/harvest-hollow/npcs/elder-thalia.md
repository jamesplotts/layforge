---
id: elder-thalia
location: greenweave-apothecary
stat_block_ref: SRD Commoner
voice: soft, rapid, slightly breathless; speaks in fragments as if she is used to stopping herself mid-sentence
chapter: the-normal-town
---

Elder Thalia Greenweave is a woman who has been afraid for twenty-two
years and has learned to make her fear look like calm. She is small,
grey-haired, and her hands are always doing something—stirring, folding,
pinning a dried sprig into a bundle—because stillness is when the
thoughts come back. She runs the apothecary because it is a reason to be
in the square, in the light, among people, and because the herb work is
meditative enough to keep the worst of the memory at bay.

Her daughter Lily was nine when the town took her. Thalia was in the
back room, grinding yarrow, when a man in a clean coat came to the door
and said, very politely, *"Your daughter has been selected for the
Midsummer offering. It is a honour. The town will see to her comfort."*
Thalia did not go to the door. She went to the back door and walked into
the Alder Grove and sat on the stone bench and did not move for two days.
The townsfolk brought water. They brought bread. They did not bring
Lily back.

Thalia does not hate the town. That is the part that makes her
complicated. She loves the square, the bakery, the way the light comes
through the alders in September. She loves that the town feeds its
children and mends its fences and remembers the old songs. She loves it
enough to stay. She is also, in the deep hours, a woman who is counting
the days, gathering herbs, and waiting for the next time the lottery
comes back to her name, because it always does, because the poor families
are always the same poor families, because the town has a list and the
list does not change and the lottery is not a lottery.

She will not fight. She will not run. She will tell the party what she
knows, and she will give them the date, and she will ask them to do what
she cannot do, which is to go into the Grange basement and read the
ledgers and understand the shape of the thing she has been afraid of for
twenty-two years. If they ask why she does not speak to the whole town,
she will be quiet for a long time, and then she will say: *"Because the
last person who spoke was the constable's wife. And she is not here. And
I will not be in her place."*