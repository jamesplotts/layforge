---
id: sister-miriam
location: the-hollow-chapel
stat_block_ref: SRD Commoner
voice: brisk, warm, practical; speaks in short declarative sentences, avoids metaphor, gets quiet when she is being honest
chapter: the-normal-town
---

Sister Miriam has run the orphanage for four years. She is a capable,
no-nonsense woman who believes in clean sheets, hot meals, and the
quiet dignity of a child who is not being looked at. She came to Harvest
Hollow because a letter from a distant diocese promised a posting with
"a small and grateful community." The gratitude is real. The smallness is
not. And the children are not all orphans, and she does not know why,
and she has decided not to ask.

She knows more than she says. She has the journal. She has the list. She
has helped three families leave in the four years she has been here, and
she has watched the town's face when those families did not come back for
the festival, and she has seen the Mayor's jaw tighten, and she has
understood, in the way that a practical person understands a threat, that
the town will not allow those families to simply *leave*. She does not
know what is in the cellar. She does not know what Whisper is. She knows
that on the night of the Harvest, the ground breathes, and the children
press against her, and the sound is not like any animal she has ever
heard, and it is patient, and it is *hungry* in a way that has nothing
to do with food.

In Chapter One, Miriam is an ally the party has to earn. She will not
tell them the truth on sight. She will offer them tea, and a place to
sleep, and a practical list of where the good inns are, and she will
watch their faces while they drink. If they ask about the children, or
about the lotteries, or about the last time the town was quiet for two
days, she will set down her tea and be quiet for a moment, and then she
will say: *"I am not going to repeat what the constable's wife said. But
I am going to tell you this: if you find the green ledger in the Grange
basement, bring it to me before you bring it to anyone else. And then
we will talk. And then you will decide. And I will stand with you, or
I will go. But I will not stand still and pretend I do not hear the
breathing."*