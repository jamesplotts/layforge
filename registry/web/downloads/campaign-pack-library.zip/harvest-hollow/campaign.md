---
id: harvest-hollow
title: Harvest Hollow
level_range: "3-8"
pvp_policy: pve_only
maturity_tier: standard
image_maturity_tier: family_friendly
shared_knowledge: strict
tone:
  - gothic
  - mystery
  - moral-complexity
  - quiet-horror
  - pastoral
author: AI-generated
chapters:
  - id: the-normal-town
    title: The Normal Town
    level_range: "3-4"
    summary: >
      The party arrives in Harvest Hollow, a suspiciously idyllic farming
      community. Beneath the friendly small-town surface, small oddities
      accumulate—no children play, no one speaks of last year, and a locked
      basement in the town grange hides records of periodic "volunteer
      offerings." Elder Thalia Greenweave warns the party in whispers that
      the Harvest returns in three days.
  - id: the-dark-secret
    title: The Dark Secret
    level_range: "4-5"
    summary: >
      Investigation reveals the town's true pact: every five years, three
      people drawn from poor families by lottery are fed to an entity below
      the town. A young girl, Lily, daughter of Thalia, has been chosen. The
      party can rescue her, but doing so brands them outlaws in the eyes of
      the entire community, and Mayor Pembroke mobilizes the townsfolk
      against them.
  - id: the-confrontation
    title: The Confrontation
    level_range: "5-7"
    summary: >
      The party confronts Mayor Pembroke and learns the full two-century
      history of the ritual. Sister Miriam reveals that each Harvest makes the
      entity more powerful and dangerous. The entity—Whisper—is an ancient fey
      creature bound to the land, not a demon. As the ritual is disrupted,
      the ground shakes and the town's unnatural prosperity begins to fade.
  - id: the-resolution
    title: The Resolution
    level_range: "7-8"
    summary: >
      The final confrontation with Whisper beneath the town. The party must
      choose: end the ritual and face the entity's wrath, continue the
      sacrifice and accept its moral cost, or find a third path—renegotiating
      the ancient binding in a way that spares no one's life. The aftermath
      reshapes the town, its people, and the party's legend.
---

Harvest Hollow sits in a broad valley where three creeks meet, ringed by
orchards heavy with late-summer fruit. From the road it looks like a postcard:
white-picket fences, a church steeple catching the morning light, a market
square where farmers haw tomatoes and honey with easy laughter. The town has
been prosperous for two hundred years—unusually so, for a settlement of its
size—and the people are warm, communal, and fiercely proud of their way of
life. Children are well-fed, debts are settled before winter, and no one goes
hungry.

But the prosperity has a price the townsfolk have agreed to forget.

This campaign is a slow-burn investigation across four chapters, escalating
from pastoral charm to gothic moral horror. The central question is not
*whether* the party can stop a sacrifice, but *what they are willing to
accept* in the process. The entity beneath the town is not a villain; it is an
ancient, hungry, non-human intelligence that simply does not understand
human ethics. The mayor is not a cackling tyrant; he is a man who has
convincing himself that three lives every five years is a fair exchange for
hundreds of families eating every winter. The party must navigate that
grey space, and their choices will echo in the aftermath.

Pacing note for the GM: let the idyll breathe. The first session should feel
almost too pleasant. The horror lands harder when the reader and the players
have already fallen in love with the bakery smells and the friendly
strangers. Save the revelations for beats, not walls of text. Let the party
ask questions, let the town deflect, let the small wrongnesses accumulate
like a pressure building under water before it cracks the surface.

## Hooks

- **The Commission:** A travelling merchant or noble courier hires the party to escort supplies into the valley and deliver a sealed letter to the mayor. The letter is the trigger for the next Harvest lottery, and the party arrives two days before the drawing.
- **The Missing Traveller:** A cart from the next town over hasn't returned. Its driver was last seen entering Harvest Hollow three days ago, smiling and waving, and has not reappeared. The local constable waves the party off, but a nervous stablehand leaves a note: *"Ask the herbalist about the quiet room in the Grange. And don't go at night."*
- **The Dream:** Each PC wakes in the night on the road into the valley to the same half-remembered dream: a vast, dark mouth beneath the soil, breathing slowly, and a whisper like dry leaves skittering across stone. They cannot agree on what the whisper said, but they all remember the feeling of being *noticed*.
- **The Invitation:** A warm, official-looking invitation arrives at the party's inn, bearing the town seal: *"You are cordially invited to the Midsummer Harvest Festival at Harvest Hollow. The town's door is always open. Come, eat, and rest. You will not want to miss it."* The handwriting is immaculate. The ink is slightly too red.