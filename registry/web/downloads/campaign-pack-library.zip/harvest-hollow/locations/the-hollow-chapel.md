---
id: the-hollow-chapel
connections:
  - harvest-square
chapter: the-normal-town
---

The Hollow Chapel is a small stone building with a single bell tower, its
roof slate-grey and its door painted a deep, deliberate green. It stands
on a slight rise to the east of the square, and from the market you can
see the faint smoke of its kitchen chimney, which means someone is cooking.
And they are. The chapel runs the town's orphanage in its upper floor:
seven children, ages six to fourteen, sleep in a long dormitory above the
nave. They are well-mannered, well-fed, and—this is the detail that
should snag in a PC's mind—there are no children under six.

Sister Miriam is a broad-shouldered woman of perhaps forty, with short
cropped hair and hands that are constantly in motion, kneading dough,
wringing cloth, adjusting a child's collar. She is warm. She is also
watchful. She watches the square from the chapel steps. She watches who
goes into the Grange after dusk. She watches the constable's shift change
and counts the seconds between the two events. She has been doing this for
four years, since the last Harvest, and she has a small leather journal
hidden beneath a floorboard in the kitchen that lists every "volunteer"
she has been able to identify, cross-referenced against the town's
poorest households. She has also, three times, helped a family leave
before the drawing. She does not tell anyone. She does not know if she
has saved them or merely moved them to a different danger. She does not
know what is down there. She knows what it sounds like, on the night of
the Harvest: a low, rhythmic vibration that the other townsmens describe
as "the earth settling" and that she, standing in the chapel with the
children pressed against her, describes in her journal as *"the breathing."*

If the party asks her what she knows, she will not lie. She will be vague.
She will say *"I am not in a position to discuss it, but if you find the
ledger in the Grange basement, bring it to me. I will show you what it
means. And then you will decide what to do, and I will stand with you.*"
She means it. She also means that if the party does nothing, she will do
it herself, and she will be less prepared than she would like to be.