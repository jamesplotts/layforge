---
id: the-alder-grove
connections:
  - harvest-square
  - greenweave-apothecary
chapter: the-normal-town
---

The Alder Grove is a small public park at the western edge of town,
where three creeks meet and the land drops away into a soft, mossy
hollow. The trees are old—far older than the town, older than the
founding, older than the soil above them. Their roots arch over the
hollow floor like the ribs of a great buried animal, and the light
through the canopy is green and still. A stone bench, worn smooth, sits
at the center. This is where Thalia comes when she needs to think.
This is where the ground is warm in January.

The grove is peaceful by day. The moss is thick, the air smells of damp
cold and wood resin, and a small stream murmurs over smooth pebbles. A
local tradition holds that the oldest alder tree at the grove's center was
planted by the town's founder, but its trunk is wider than any human
hand could have measured, and its roots do not look planted. They look
*grown*. They look like they are reaching for something.

At night, or in the deep shade beneath the canopy, the grove changes.
The sound of the stream drops away. The air goes still in a way that is
not merely quiet but *attentive*, as if the space is listening. The
warmth from the ground is stronger here, and if a PC presses their palm
flat to the moss, they can feel—faintly, irregularly, like a pulse
far below—something moving beneath the soil. Something vast. Something
that has been sleeping, or waiting, for a very long time. It does not
attack. It does not speak. It simply *is*, and the fact of its
presence is enough to make the hair on the back of the neck rise.

This is the closest the party gets to Whisper in Chapter One. It is not
an encounter. It is a feeling. Let it land.