---
id: harvest-square
connections:
  - the-grange
  - greenweave-apothecary
  - the-hollow-chapel
  - the-alder-grove
chapter: the-normal-town
---

Harvest Square is the beating heart of the town. A broad flagstone plaza, wide
enough for the weekly market and the seasonal festivals, is ringed by
low two-story timber buildings with painted shutters and flower boxes. A
wrought-iron well stands at the center, its pump handle worn smooth by
generations of hands. On market mornings the square fills with the smell of
baked bread, roasting chestnuts, and cut hay; vendors call out prices in a
merry, competitive chorus, and children—mostly the children of shopkeepers—
race between the stalls with apples clutched in their teeth.

The prosperity is visible in the details: every window is clean, every
fence is freshly whitewashed, the cobblestones are scrubbed free of moss
that should, given the valley's damp, be thick by now. There is a strange
uniformity to the town's appearance, as if someone has ironed the whole
place. The people are kind. They smile. They offer the party a seat at a
baker's table, a glass of cider, a warm biscuit. No one is rude, no one is
grudging, no one is *angry*. It is, in a word, perfect.

And that is precisely what is wrong.

The oddities are small enough to brush off. No children under ten play in
the square; the only small ones visible are the well-groomed offspring of
wealthier families, chaperoned. A few vendors glaze slightly when the
party mentions the word "lottery" or asks about last summer. The constable
on duty is overly eager to point the party toward good inns and taverns,
keeping them in the light, in the center, in plain sight. And at the far
edge of the square, where the flagstones give way to a narrow lane, a sign
reads: *The Grange — Town Hall & Community Hall. All welcome. Doors close at
dusk.*

The doors do close at dusk. The party should notice that. And the constable
should notice them noticing.