---
id: greenweave-apothecary
connections:
  - harvest-square
  - the-alder-grove
chapter: the-normal-town
---

Elder Thalia Greenweave's apothecary is a squat, fragrant shop wedged
between the chandler's and the milliner's on the north side of the square.
The windows are thick with dried bundles—lavender, rosemary, yarrow,
nightshade (labelled clearly, in a hand that trembles slightly), and a
strange silver-veined herb Thalia calls "hollow moss" that no other vendor
in the valley sells. The interior smells of cedar shavings and warm tea.
Shelves line every wall, and a heavy oak counter blocks the view into the
back room, where a pot of something green and faintly luminescent simmers
on a low stove.

Thalia is a small, grey-haired woman in her late sixties, with soil under
her fingernails and a permanent expression of gentle, exhausted
kindness. She has been in the valley for twenty-two years, ever since her
daughter Lily was nine. She says she came for the air. She does not say
what happened to Lily. She does not say it because she was told, in a quiet
room, by a man in a clean coat, that the child was "volunteering for the
good of the whole" and that talking about it would bring trouble. She has
not talked about it since. She has, however, been searching for two hundred
and twenty-six days of every year, in a pattern no one else in the town has
noticed, gathering herbs that grow only in the soil directly above the place
where the ground goes soft and warm in the middle of winter.

She is afraid. She is also, beneath the fear, very stubborn. And if the
party asks the right question—*Who took your daughter? Who made her
volunteer? Why do you stay?*—she will talk. She will talk in a whisper, she
will look over her shoulder, and she will give them the date. Three days.
She will also give them the name of the child who has been chosen this
time, and the name will be her own daughter's name, because the lottery
returned the same family again, and this time Thalia is not going to
stand in the back room and watch the green light in her pot and pretend
she does not hear the bells.