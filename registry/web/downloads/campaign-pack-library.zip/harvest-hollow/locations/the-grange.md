---
id: the-grange
connections:
  - harvest-square
chapter: the-normal-town
---

The Grange is a long, low building of pale timber and dark stone, its roof
heavy with ivy that has been trimmed—actually *trimmed*, in neat rectangles,
which is unsettling in a way the person trimming it probably did not notice
it was odd. The front doors are wide and welcoming, and the interior is
broad, warm, and smelled of wood polish and beeswax. A long table dominates
the main hall, set with mismatched chairs that suggest a hundred years of
community meetings. A notice board near the entrance is pinned with
festival schedules, a recipe for apple compote, a hand-drawn map of the
valley, and a small, unremarkable card that reads: *Midsummer Harvest
Festival — Three days. All townsmen are requested to attend the evening
prayers at the Hollow Chapel. Bring a white cloth. Do not ask questions.*

The notice is the most important thing in the building, and it is the
least conspicuous. A PC who lingers, who flips through the notice board
methodically, who reads the *"Do not ask questions"* line twice, will feel a
small, cold prickle. The rest of the Grange is unremarkable: a kitchen,
a small archive of ledgers, a side room used for town council meetings.

The basement is the other story.

Beneath the main hall, behind a false panel in the back wall of the
archive room (a DC 15 Perception check to notice the seam, or a DC 10
Investigation if the party specifically asks about what is stored below), a
narrow staircase descends into a cold, dry cellar. The walls are old stone,
older than the building above. Along the back wall stands a stone alcove,
its interior carved with a pattern of concentric rings around a small
central depression worn smooth. Before it sit a bowl of dried lavender,
three small candles in iron holders, and a stack of leather-bound ledgers
bound in faded green cloth. The ledgers are the records of past Harvests:
dates, names, the family of origin of each "volunteer," and a single
scrawled note in a different hand, the same in every entry, that reads
*"Fed and satisfied. The land holds."*

The door to the cellar is locked. A key hangs on a hook inside the Grange,
within Mayor Pembroke's reach. Whether the party finds the panel before the
Mayor does is the first true test of the chapter.