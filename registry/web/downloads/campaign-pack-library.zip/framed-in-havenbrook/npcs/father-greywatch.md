---
id: father-greywatch
name: "Father Tomas Greywatch"
location: thornwell-courthouse
stat_block_ref: "SRD Commoner"
voice: "Gentle, deliberate, and weighted with the particular exhaustion of a man who has said the right words into a room that does not want to hear them, and said them again, and said them again."
chapter: the-accusation
---

Father Tomas Greywatch is sixty-one, a broad man with a beard that is half grey and a face that carries the specific weariness of a person who has spent thirty years listening to the confessions of a town that does not confess well. He serves the Temple of Saint Aldren, the small stone church on the north edge of the market square, and he has served it for twenty-two years. He is kind. He is careful. He is bound.

Temple law in Thornwell is not the gentle, abstract thing that the party may imagine. It is a codified set of obligations that bind the priest to the magistrate's authority in matters of public order. Greywatch has the theological authority to speak for the party in the courtroom. He has the moral authority to tell the truth. He does not have the legal authority to prevent Ashford from signing the execution warrant, and he knows this, and the knowing is what has kept him awake for two nights running.

He suspects the party is innocent. He has looked at the evidence. He has looked at Ashford's face when the evidence was presented, and he saw something in it—not triumph, exactly, but relief, the relief of a man who has been waiting for a problem to hand itself to him. He knows Voss. He has heard, in the confessional, from a woman in the Vane household, a fragment of a conversation that did not sit right. He has written it down. He has not shown it to anyone. He does not know what he will do with it.

He will help the party if they come to the temple and ask, and if they are gentle about it, and if they do not ask him to break a vow he has kept for twenty-two years. He will not break the vow. But he will not, if asked, close the door on them. And in the space between those two things—the space where he can be kind without being complicit—there is room for something. Something small. Something that might be enough.
