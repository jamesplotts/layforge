---
id: detective-cross
name: "Detective Seraphine Cross"
location: thornwell-courthouse
stat_block_ref: "SRD Veteran"
voice: "Measured, direct, and faintly tired—the voice of a person who has been saying the same true thing to the same wrong person for longer than is comfortable."
chapter: the-accusation
---

Seraphine Cross is thirty-eight, broad-shouldered, with a scar that runs from her left ear to her jaw and a habit of pressing her thumb into the base of her skull when she is thinking. She served six years in the river fleet as a gunner's mate before the fleet dissolved and she came to Thornwell with a letter of introduction and a head full of the kind of practical, hard-won knowledge that does not appear in any manual. She was appointed Ashford's deputy two years ago. She has been trying to do her job ever since.

She does not believe the party is guilty. She has read the file. She has looked at the evidence. The dagger is the wrong shape for a trained hand. The coin purse was torn with a cloth, not a blade. The timeline does not work. She wrote this down, in a clear, orderly hand, and placed it on Ashford's desk. He read it. He did not respond. The next morning, her file had been reclassified and her access to the Voss murder dossier was revoked. She was told, by a clerk who would not meet her eyes, that the case was "closed pending sentencing" and that her duties for the day were to inventory the constables' armory.

She is still investigating. She is doing it in the margins: a note here, a question there, a file she has copied and hidden in a book in the temple library. She knows who she suspects. She is not certain. She is certain enough to be afraid, and afraid enough to be careful, and careful enough to keep her mouth shut in the courtroom while she writes the word *Vane* in a margin that will be torn out before the next court session.

She is not a hero. She is a woman doing a job she was told to stop doing, in a town that does not want her, for a boss who will destroy her if she gets in the way. But she is there, in the witness box, writing in her ledger, and if the party can find her, and if they can make her trust them, and if they can get her to put her name on a document before Ashford gets to her first—then something might move. Something small. Something that might be enough.
