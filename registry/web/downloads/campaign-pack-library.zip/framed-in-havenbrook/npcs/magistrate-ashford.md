---
id: magistrate-ashford
name: "Magistrate Corvin Ashford"
location: thornwell-courthouse
stat_block_ref: "SRD Commoner"
voice: "Precise, clipped, courteous in the way a blade is courteous—each word chosen to draw a little blood without the other party noticing the cut."
chapter: the-accusation
---

Corvin Ashford is fifty-three, lean, and immaculately dressed in the black and grey of the magistrates' office. His hair is silver, combed back from a high forehead. His hands are long-fingered and still, the hands of a man who has spent thirty years reading documents and writing them with equal care. He does not raise his voice. He has never needed to. The silence that follows his sentences is more frightening than any shout.

Ashford is not, in his own mind, a villain. He is a magistrate who was appointed to a town that did not want him, who has spent eleven years building a system of authority that works because people believe in it, and who has now found himself in a position where the system requires a guilty party and the guilty party is conveniently standing in front of him, bound at the wrists, with the evidence in their pack. He has made his decision. He has written his verdict. He will sign the execution warrant on the third day if the party does not confess, because the alternative—opening the file, admitting that Voss's murder is connected to the Vane household, letting the trade council crack open like a walnut—is a risk he will not take.

His alliance with Lord Cedric Vane is not a friendship. It is a transaction. Vane pays for silence; Ashford pays for power. They have never spoken warmly. They do not need to. Ashford's private chamber has a locked drawer, and in the locked drawer is a ledger that does not belong to the magistrate's office, and in that ledger are names, dates, and sums that would unmake him. The ledger is the lock. The party is the key that Vane is trying to remove before anyone else can use it.

He is not invincible. He is a man who can be cornered in a room with a door that locks from the outside, and he is a man who has a fear that he has spent thirty years burying: the fear that the system he built is only as strong as the last person who believes in it.
