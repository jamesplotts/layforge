---
id: whisper-nell
name: "'Whisper' Nell"
location: thornwell-old-mill
stat_block_ref: "SRD Commoner"
voice: "Quiet, rapid, and economical—every word is a coin she is deciding whether to spend. She doesn't monologue. She answers. Sometimes."
chapter: the-accusation
---

Nell is eleven. She is thin in the way that is not healthiness but survival—wiry, quick, with a face that looks like it has been folded and unfolded too many times. Her hair is a dark tangle that she does not bother to manage. She moves through Thornwell like water through a crack in a wall: everywhere, nowhere, and no one seems to notice until they need something she has.

She is not a street urchin in the romantic sense. She is an informant who sells what she sees to the highest bidder, and the highest bidder changes weekly. She has sold information to Ashford's constables, to the Vane household, to the temple, and to the fishmonger's wife, who pays in bread. She does not trust any of them. She does not trust the party. She will not tell them what she knows until she has decided, with the slow and careful calculus of a child who has been burned by adults before, whether they are the kind of people who will put a knife in her when they are done with her.

What she saw: the night of the murder, she was in the mill, as she always is. The river was low. The lane from the square was dark. She saw a figure in a long coat leave the inn at roughly the third bell, walking fast, heading north toward the courthouse. She saw the figure stop at the corner, turn, and look back at the inn. She did not see the face. She saw the coat. She saw the walk. And she has been carrying that image for six hours, turning it over, and she is terrified that the image is wrong, or that it is right and someone will come for her because she saw it.

The note she slipped under the cell door was not an invitation. It was a test. If they come to the mill alone, it means they are willing to meet a child in a ruin, which means they are either desperate or kind, and both of those things are useful. If they don't come, she goes back to the mill and forgets their names and the whole thing never happened. She is not naive. She is not brave. She is a child who has learned that the only safe place in the world is the one no one else wants.
