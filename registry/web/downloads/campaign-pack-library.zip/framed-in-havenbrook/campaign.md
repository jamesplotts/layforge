---
id: thornwell-verdict
title: "The Thornwell Verdict"
level_range: "3-8"
pvp_policy: pve_only
maturity_tier: standard
image_maturity_tier: family_friendly
shared_knowledge: strict
tone:
  - suspenseful
  - politically-charged
  - morally-ambiguous
  - claustrophobic
author: "AI-generated"
chapters:
  - id: the-accusation
    title: "The Accusation"
    level_range: "3-4"
    summary: "The party arrives in Thornwell, a mid-sized river town. Overnight a powerful merchant is slain in the inn's second floor, and the party is found at dawn with the murder weapon in their luggage. Magistrate Ashford's guards arrest them before they can breathe. The chapter ends with a note slipped under the cell door by a child named Nell, asking them to come to the old mill alone."
  - id: the-investigation
    title: "The Investigation"
    level_range: "4-5"
    summary: "Freed, hiding, or still in cells, the party pieces together the true crime. Lord Voss was blackmailed by a cult operating under the merchant house of Cedric Vane. Each clue tightens the noose. A second identical murder occurs, the safehouse is raided, and Ashford issues a forty-eight-hour ultimatum: confess or an ally dies."
  - id: the-truth-and-the-trap
    title: "The Truth and the Trap"
    level_range: "5-7"
    summary: "The cult's ritual and Vane's plan come into focus. Vane, aware of the party's inquiries, engineers a third framing or kidnaps a captured ally. A chase through Thornwell's underbelly forces the party to choose: expose Vane publicly, act in shadow, or flee. The final twist reveals the very person who hired them to come to Thornwell was Voss's rival and co-conspirator."
  - id: the-resolution
    title: "The Resolution"
    level_range: "7-8"
    summary: "The party faces the climax: a public trial, a night of blades in the merchant quarter, or a desperate escape past Ashford's seal. Their reputation is either washed clean or branded permanently. The town shifts in the aftermath—power vacuums, cult remnants, and the question of whether justice in Thornwell means anything at all."
---

# The Thornwell Verdict

Thornwell is a town of ten thousand souls built where the Thorn River bends sharply before it meets the marshland. It is a place of honest trade, temple bells, and a magistrate who has recently discovered that honesty does not pay the rent on ambition. The party has been hired—or perhaps merely directed—here to handle a business matter, a favor, a lead on a contact. Whatever brought them, it is irrelevant now.

Because on the first night, Lord Aldric Voss, master of the Voss Textile Consortium and the single wealthiest man in Thornwell, is murdered in the inn room adjacent to the party's own. By morning, a dagger with the party's signet is in his throat, their coin purse is torn open beside the body, and Magistrate Corvin Ashford has already written the verdict before a single witness has been heard.

This is not a simple "find the killer" investigation. The killer is a merchant prince with a seat in the trade council and a shadow-rite in his cellar. The magistrate is his shield. The town's institutions—temple, market, constabulary—are all threaded with loyalty to power. The party must decide, at every turn, whether the law is a tool they can wield or a wall that will crush them. They can fight, talk, bribe, hide, or run. They can win the town's sympathy or disappear into the marshes with a bounty on their heads. Every path is real; none is safe.

The campaign rewards creative problem-solving over combat. Most encounters can be resolved through wit, social cunning, and resourcefulness. Combat is available as a last resort but is deliberately made costly: the party is in a town of ten thousand, and killing a constable does not end the problem.

## Hooks

- **The Letter.** A sealed letter from a contact the party knows arrives three days before the journey, naming Thornwell and the Voss Textile Consortium as the destination. The letter's true author is not the one it claims to be.
- **The Debt.** A patron or guild owes the party a favor and has directed them to Thornwell to "collect on a debt of information." The patron has no idea what they are stepping into.
- **The Wound.** A member of the party's company was previously hired by a Thornwell agent to travel with the group, carrying a package the party does not yet know about. The agent is already in town, waiting.
- **The Rumor.** A tavern tale in the previous town mentioned a merchant who "bought a man's life for the wrong reasons" and was heading for the river. The party went to investigate. They were right to go. They were wrong about everything else.
