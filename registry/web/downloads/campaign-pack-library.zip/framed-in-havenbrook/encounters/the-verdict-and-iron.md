---
id: the-verdict-and-iron
name: "The Verdict and the Iron"
location: thornwell-courthouse
involves:
  - magistrate-ashford
  - detective-cross
  - father-greywatch
chapter: the-accusation
---

The party is brought before the courtroom. The bench is occupied. Ashford is writing in a ledger as they are led in, and he does not look up until the constables have bound their wrists and they are standing on the dock. When he does look up, his expression is the expression of a man who has read a document three times and is now reciting it from memory, which is a more dangerous expression than anger, because anger implies uncertainty and this does not.

"You are charged with the premeditated murder of Lord Aldric Voss, master of the Voss Textile Consortium. The evidence presented to this court includes: the murder weapon, bearing your sigil; the stolen coin purse, torn and recovered from your effects; the testimony of the innkeeper, Dace, who placed you in the building at the time of the crime; and the absence of any alibi. You will state your name, your trade, and your plea."

The plea does not matter. The name does not matter. The trade does not matter. Ashford is not asking. He is performing. The courtroom is a stage and the party is the actor who has been handed a script they did not write and the audience is in the gallery, and the audience is not there, because the gallery is empty, because Ashford does not want a jury, because a jury would ask questions, and questions are the one thing Ashford cannot control.

Cross is in the witness box. She is writing. She is not looking at the party. But her hand is moving, and if the party can see what she is writing—through the margin of her attention, through the particular angle of her wrist—she is writing the word *Vane*. She is writing it in the margin of the official record. She is writing it in ink that will be visible under a lamp but not under a candle. She is writing it for the party, and she is writing it for herself, and she is writing it because if she does not write it down in this moment, in this room, in this ledger, it will not exist, and if it does not exist, then the three days will end and the warrant will be signed and the whole thing will be over and she will have said nothing and done nothing and believed nothing and it will have been enough to keep her alive and not enough to keep anyone else's.

Father Greywatch is in the back of the courtroom, standing, because he is not a constable and he does not have a seat. He is watching the party. He is watching Ashford. He is watching Cross. And when the party's eyes find his, he does not nod. He does not shake his head. He simply closes his eyes for a moment, and when he opens them, his expression is the expression of a man who is deciding, in the space between two heartbeats, whether to step forward and say the words he has been keeping for three days, and the decision is not made yet, and the party has to make it for him, because if they do not ask, he will not say it, and if he does not say it, the words will die in his throat and the whole thing will be over and no one will ever know.

The encounter resolves in one of three ways, depending on the party's actions: they are taken to the Undercroft and the three-day clock begins; they are released on the condition of surrender within three days, which is a more dangerous freedom because it means they are in the open and Ashford is watching; or, if they manage to get Cross to stand up and speak, to say the word *Vane* aloud in the courtroom, the scene fractures, Ashford's composure cracks, and the whole thing becomes something else entirely. Any of these outcomes is valid. The party's choice determines which one it is.
