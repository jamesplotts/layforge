---
id: the-silted-mill-meeting
name: "The Silted Mill Meeting"
location: thornwell-old-mill
involves:
  - whisper-nell
chapter: the-accusation
---

The party reaches the Silted Mill at dusk. The river is low and dark and the water sounds like a hand rubbing slowly over wet cloth. The lane from the market square is empty. The fishmonger's shop is shuttered. The chandler's door is closed. There are no constables on the lane. There are no eyes on the lane. The lane is, for the first time since the party arrived in Thornwell, unwatched.

The mill door is unlocked. The door is open. The interior is dark and smells of wet wool and old iron and the faint, sweet rot of silt that has been disturbed. The party steps inside. The floor gives slightly underfoot. The sound of their boots is swallowed by the dark. And then, from the upper floor, a small sound: the creak of a floorboard, the shift of weight, the faint scrape of a small hand on a rough wall.

Nell does not come down. The party must go up. The stairs are narrow and the rungs are missing and the dark is complete and the only light is the grey river-light through the single window on the upper floor. When the party reaches the top, Nell is sitting on the floor with her back to the wall and her knees drawn up and a mug of something in her hands. She is not looking at them. She is looking at the river.

"You came," she says. Not a question. "I didn't think you'd come. Most people don't come to the mill. They send a constable. Or a knife. You came. That's either stupid or kind and I don't know which one is worse."

The information she has is not the whole truth. It is a piece. The figure in the long coat. The walk. The direction. She will say it if they ask, and she will say it plainly, and she will not say it unless they ask, and she will not say it unless they sit down first, and she will not sit down if they do not sit down first, and the sitting down is the first thing that has to happen, and it is a small thing, and it is the whole of the encounter, because what happens after the sitting down depends on what the party says next, and what they say next depends on what they believe about her, and what they believe about her depends on whether they are the kind of people who look at a child in a ruined mill and see an informant, or a witness, or a person.

The encounter is a trap if Ashford's people are waiting on the lane. The party should be wary. The lane is not empty. It is quiet, which is not the same thing. The fishmonger's shop is shuttered, but the shutter is not locked. The chandler's door is closed, but the gap under the door shows the flat glow of a lantern that is not there a moment later. The party must decide, before they go down the stairs, whether to check the lane, and checking the lane means leaving the mill, and leaving the mill means leaving Nell, and leaving Nell means she will close the door and the whole thing is over and they will never know what she was going to say.

If the party is cautious, the trap is avoided. If the party is bold, the trap is sprung and the encounter becomes a fight in the mill, and the fight is not fair, because the mill is narrow and the stairs are one way and the river is at the party's back and Nell is in the corner with her mug and her flat eyes and her small, terrified, furious face, and she is not a combatant, she is a child, and the party has to decide, in the middle of the fight, whether to stop fighting and put her down, and the decision is the encounter, and the encounter is the test, and the test is whether the party is the kind of people who can win a fight without losing the thing they are fighting for.
