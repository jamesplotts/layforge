---
id: the-undercroft-escape
name: "The Undercroft Escape"
location: thornwell-jail
involves:
  - magistrate-ashford
  - detective-cross
chapter: the-accusation
---

The party is in cell three. The iron bars are six inches thick. The lock has three pins. The wall is weeping. The Thorn River is running far below, and the sound of it is the only thing in the world that is not controlled by Ashford. The three-day clock is running. The first day is over. The second day is running. The party has perhaps twelve hours before the trial, and the trial is a formality, and the formality is a warrant, and the warrant is a rope, and the rope is the end of the story if no one does something before the ink dries.

The false panel in cell six is behind the straw pallet. It is not hidden well—it is hidden by a layer of mortar that has been applied in a hurry, and the mortar is a different color from the surrounding stone, and the color is the kind of color that a person who is looking will see, and the party is looking, because they are in a cell and the walls are the only things they have, and the walls are the only place a way out can be.

The passage is narrow. It is dark. It is damp. It runs at a gentle downward slope for two hundred feet, and the air gets colder the further they go, and the smell changes from wet stone to wet rot to the particular mineral smell of the river silt, and then the passage opens, and the opening is low, and the party has to crawl, and the light at the end of the crawl is the grey river-light of the Silted Mill, and the sound at the end of the crawl is the sound of the water wheel that is not there, the sound of the water moving over the stones where the wheel used to be, and the party is on the gravel bank, in the dark, in the cold, in the smell of the river, and the mill door is ten feet away, and the mill door is open, and the light inside is not the light of a fire, it is the light of a window, it is the light of the river, and someone is in the mill, and the someone is small, and the someone is watching the party crawl out of the dark, and the someone is deciding, in the space between two heartbeats, whether to open the door wider or close it.

If the party comes through the passage, they arrive at the mill with no constables on the lane, no eyes on the river, no boots on the gravel. They are in Nell's territory. They are outside Ashford's sight. And the three-day clock is still running, and the party is free, and the freedom is the first real thing that has happened to them since they walked into the Crooked Compass, and the freedom is terrifying, because it means the next decision is theirs, and the next decision is the one that determines whether the story ends in the Undercroft or in the river or in the courtroom or in the mill, and the party has to choose, and the choice is the whole of the chapter, and the chapter is the whole of the story so far, and the story so far is the party being in a cell and now being free, and the freedom is the cliffhanger, and the cliffhanger is the note, and the note is under the cell door, and the note says: *The mill. Alone. Come before the bells. — N.*

The party is free. The party is in the mill. The party is watching Nell. Nell is watching the party. The river is running. The bells are not yet ringing. The three days are still running. The choice is the party's. The choice is now.
