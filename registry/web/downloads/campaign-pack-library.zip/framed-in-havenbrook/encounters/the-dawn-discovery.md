---
id: the-dawn-discovery
name: "The Dawn Discovery"
location: thornwell-inn
involves:
  - magistrate-ashford
  - detective-cross
chapter: the-accusation
---

The party wakes to the sound of boots on the stair and the smell of iron. The door to room seven is already open. Two constables stand in the doorway, halberds across their chests, their faces set in the particular blankness of men who have been told what they will find and are confirming it. Behind them, at the top of the stair, stands Magistrate Ashford, hands clasped behind his back, his expression one of mild, professional regret—the expression of a man who has already made his decision and is now delivering it.

"Lords and Ladies, or whatever it is you are. I am Magistrate Corvin Ashford of Thornwell. You are being detained in connection with the murder of Lord Aldric Voss, which occurred in the adjacent room sometime between the second and fourth bell of the night." He does not say *I think* you did it. He does not say *we are investigating*. He says *you are being detained*, and the sentence is closed, and the sentence is final, and the constables are already moving to take the party's wrists.

The scene is not a surprise to the party—they were there, they are innocent, and the evidence in their pack is not theirs—but it is a surprise in the way that the whole thing is already over. Ashford has already written the charge. The constables have already been briefed. The crowd in the square has already formed. Detective Cross is in the back of the group, not in the front, and her eyes, when they find the party's, are not the eyes of a colleague. They are the eyes of a woman who knows the party is innocent and does not know how to say it without destroying herself.

The party has a very short window—perhaps thirty seconds before the constables complete their bindings, perhaps less—to make a choice: comply and go to the courthouse, fight (a constable is a commoner with a halberd and the crowd is hostile, and this will not end well), or attempt to escape through the window. The window is forty feet to the square. The square is full of constables. The back stair is blocked. The kitchen alley is guarded. The choice is not *how* to escape but *whether* to escape, and what the escape costs.

If the party complies: they are led to the courthouse. Ashford reads the charge aloud. The courtroom is empty. Cross is in the witness box, not looking at them. The sentence is: *Detained pending trial. Trial to commence in three days.* The three days are the window. The three days are the whole of chapter one's tension, compressed into a single, suffocating countdown.

If the party fights: two constables fall. The crowd screams. The innkeeper locks the back door. The party is now a fugitive in a town of ten thousand, and Ashford's face, when it appears at the window, is not the face of a man who is surprised. It is the face of a man who has been waiting for this, who has a contingency, who has already sent a rider to the marsh guard with the party's description. The clock is still three days, but the stakes have changed.

If the party escapes through the window: the fall is survivable but not painless. The square is a gauntlet. The market stalls are shields. The fishmonger's knife is a threat. The party gets to the edge of the square, to the lane that runs toward the mill, and then they are running, and the boots behind them are getting closer, and the only door that is open is the one into the Silted Mill, and Nell is watching from the window, her face flat, her hands still, her eyes on the party with the particular intensity of a child who is deciding, in real time, whether to open the door.
