---
id: thornwell-market
name: "Thornwell Market Square"
connections:
  - thornwell-inn
  - thornwell-old-mill
  - thornwell-courthouse
chapter: the-accusation
---

The Market Square is Thornwell's heartbeat. A rough oval of packed gravel hemmed in by two-story shops, the temple of Saint Aldren to the north, the fishmongers' row to the south, and the Gray Hall of Justice rising at the west edge like a stone fist. On a normal morning the square churns: cart wheels grinding, hawkers calling, the smell of frying dough and river fish braiding through the air. Children dart between legs. A fountain in the center, fed by a channel cut from the Thorn River, runs with a thin, mineral-tasting trickle.

The morning after the murder, the square is a different animal. A crowd has gathered—two hundred, three hundred strong—pressed against the barriers the constables have thrown up around the Crooked Compass. Faces are hard. Fingers point. A woman shouts that the party killed "a good man" and should be hanged from the fountain. A child throws a stone. It hits the inn's shutter and rolls down the wall. The crowd is not uniformly hostile—there are faces that look confused, faces that look guilty as if they are the ones being accused, faces that simply want to be somewhere the shouting is.

The square is a place of information as much as commerce. The fishmonger on the south row sold Voss his morning catch the day before. The baker's apprentice was the last person to see the party enter the inn the previous evening. The temple's bell-ringer, a thin old man, watched the constables storm the inn and saw, with the particular clarity of the elderly, that something about the whole affair was wrong. But he says nothing to the crowd, and when the party's eyes find him, he looks away.

The square is a crossroads. The west gate leads directly to the courthouse steps. The east lane, behind the inn, narrows and winds south toward the river and the old mill district. The north path runs past the temple and into the temple's walled garden. The south road, wide and paved, leads out of town toward the marshland and the ferry crossing. Each direction is a choice, and each one is watched by at least one pair of Ashford's eyes.
