---
id: thornwell-jail
name: "The Undercroft"
connections:
  - thornwell-courthouse
  - thornwell-old-mill
chapter: the-accusation
---

The Undercroft is not a prison in any dignified sense. It is a natural cavern in the bedrock beneath the courthouse, expanded over the centuries into a series of low-ceilinged cells that smell of wet stone, old iron, and the particular mustiness of bodies that have not been washed in a long time. A single iron-gated door, set in the wall at the top of the stair, is the only entry. The door locks from the outside. The key is heavy, iron, and shaped like a thorn—the same thorn that appears on the magistrate's seal.

The cells are six feet by four, with a straw pallet, a clay water jug, and a chamber pot. The walls are weeping. The floor is packed earth that has been trampled into a grey paste. Light comes from a narrow slit in the wall, high up, angled so that at certain hours of the day a thin blade of sun cuts across the cell floor and illuminates a line of dust motes. At night it is dark and cold and the only sound is the distant, low thrum of the Thorn River moving through its channel beneath the foundation.

The party, if they are here, are in cell three. The iron bars are thick. The lock is a tumbler mechanism of unusual design—three pins, not the standard two—which suggests Ashford had it fitted specifically, at some cost, to make picking difficult. It is not, however, impossible. A lockpick of reasonable skill has a chance. A lockpick of exceptional skill, or a shillelagh of appropriate size, has a better one.

Behind cell six, the wall is not solid. Behind a false panel of dressed stone, hidden by a decades-old layer of mortar, there is a passage. It is narrow—barely wider than a person's shoulders—and it runs at a gentle downward slope for perhaps two hundred feet before opening into the root system of the old mill. The passage is dark, damp, and smells of rot. It has not been used in a long time. It is not on any plan of the courthouse. It is not known to any of Ashford's staff.\ It is known to one child who sleeps in the mill and has been slipping through that wall since she was six years old.
