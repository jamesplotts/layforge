---
id: thornwell-old-mill
name: "The Silted Mill"
connections:
  - thornwell-market
  - thornwell-jail
chapter: the-accusation
---

The Silted Mill sits where the Thorn River bends south, on a low gravel bank where the water runs slow and dark. It was once a grain mill, then a tannery, then nothing. The water wheel is gone. The millstone is cracked. The shutters hang open, broken, and the interior is a tangle of rusted gears, rotted timber, and a floor of packed silt that gives slightly underfoot. The smell is of wet wool and old iron. In the corner, behind a collapsed shelving unit, there is a pallet of straw, a cold hearth, and the faint grease-mark of a child's small hands on the wall, high up, where no adult would reach.

This is Nell's territory. She has slept in the mill since she was seven, when the tannery foreman's wife locked her out of the yard and the winter came. The mill is hers. The river is hers. The narrow lane that runs from the market square down to the mill, past the fishmongers and the chandler's shop, is a lane that Ashford's constables do not patrol, because it is too narrow for their horses and too far from the square for their interest. It is the one road in Thornwell that runs outside the magistrate's direct sight, and Nell has used it for years.

The meeting, if the party comes, will be in the mill's upper floor, where a single window faces the river. The light through the window is grey and flat. Nell will be sitting on the floor with her back to the wall and her hands wrapped around a mug of something that is not quite tea. She will not stand. She will not look the party in the eye until they sit down. And when she speaks, it will be in a voice that is flat and careful, the voice of a child who has learned that every word she says might be the last one she gets to say.

The mill is reachable from two directions: the lane from the market square, which is public and possibly watched, and the passage from the Undercroft, which is hidden and known to very few. The choice of which door to come through is a choice the party must make, and it is a choice that says something about who they are and who they trust.
