---
id: thornwell-inn
name: "The Crooked Compass Inn"
connections:
  - thornwell-market
  - thornwell-courthouse
chapter: the-accusation
---

The Crooked Compass squats at the eastern corner of Market Square, its timber frame blackened by a decade of cooking smoke and its sign—a brass compass with the needle bent permanently toward the north—dangling on a single hinge. The common room smells of lard, cheap ale, and the particular damp that settles in old wood. A fire roars in the hearth. A half-dozen patrons sit at tables, but conversation stops the moment the party's boots cross the threshold on the morning of the arrest.

The party's room is on the second floor, room seven, overlooking the square. Room eight, directly across the corridor, was occupied by Lord Aldric Voss. A thin partition of lath and plaster divides the two rooms—thin enough that, on a quiet night, a raised voice carries. The murder weapon, a stiletto with a pommel engraved in the party's sigil, was found in the party's pack. The coin purse, torn open, was stuffed beneath the bed with a deliberate cruelty. The innkeeper, a broad woman named Dace, stands in the doorway with her arms crossed and her jaw working, unable to meet the party's eyes. She saw nothing. She heard the thump of a body on the flagstones at roughly the third bell. She was in the bar, polishing the same glass for an hour, and she will not say why.

By the time the constables come through the front door, the common room has emptied to two men who are pretending to be asleep. The back stair to the cellar is blocked with overturned chairs. The only exit is the front, and the front is where Ashford's men are waiting. The inn's kitchen door opens onto a narrow alley that runs along the south wall toward the courthouse, but it is guarded. Dace, when the party's eyes find her, shakes her head slowly. *I'm sorry. I can't. He'll take the whole house if I move.*

The room itself: a narrow bed, a washbasin, a writing desk with a half-finished letter the party was composing. The window has no bars. The square below is perhaps forty feet of open space. The square is now full of constables.
