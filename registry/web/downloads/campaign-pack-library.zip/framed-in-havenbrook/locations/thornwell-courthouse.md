---
id: thornwell-courthouse
name: "The Gray Hall of Justice"
connections:
  - thornwell-market
  - thornwell-inn
  - thornwell-jail
chapter: the-accusation
---

The Gray Hall is a squat, severe building of local granite, no taller than three stories, with a clock face above the main door that has not been wound in a month. Inside, the entrance hall is wide and cold, polished to a mirror shine that reflects the party's own faces back at them distorted and unfamiliar. Marble columns. A long gallery of portraits—every magistrate who has sat in this chair, going back six generations, their eyes following the party with the same cold patience.

The courtroom is on the ground floor, behind the entrance hall. It has already been set: the bench is occupied. The witness box is occupied by Detective Seraphine Cross, who is writing in a ledger and not looking up. The gallery is empty. There is no jury. There has never been a jury in Thornwell; Ashford sits as judge, jury, and executioner in one, and the law does not distinguish. The party, if they are brought here, will be bound at the wrists, led to a rough-hewn dock, and asked to state their name and trade. The answer they give will be written down. The answer will not matter.

Above the courtroom, on the second floor, is Ashford's private chamber. The door is oak, banded in iron, and it does not open for constables. The window faces the square. On the desk behind the door, visible through the glass on a clear day, sits a half-drunk glass of wine and a sheaf of papers stamped with the magistrate's seal. A servant stands in the corridor outside, arms folded, refusing to look at anyone who approaches the door with anything less than a writ.

Below the entrance hall, reached by a narrow stair to the left of the great hall, the Undercroft jail descends into the bedrock. The door is iron. The key is Ashford's. The cells are damp, cold, and small. The party, if they are still in there, will know the weight of the stone above their heads and the sound of the Thorn River running far below, patient and indifferent.
