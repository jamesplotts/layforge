---
id: amber-lantern
connections:
  - thornwood-crossing
  - whispering-stones
chapter: the-ally-appears
---

The Amber Lantern is a broad, low-ceilinged tavern built into the lee of a sandstone outcrop just outside the village of Riverstone. Its name comes from the single great lantern in the center of the main room — a glass sphere filled with a pale, honey-colored liquid that glows without flame, casting everything in a warm, slightly amber light. The drink here is decent. The bread is better. The regulars are farmers, courier drivers, and the occasional traveler with a long story and a short patience.

The building has a back room that smells of old paper and dried herbs. This is where Kaelen Ashborne holds court on the first evening, surrounded by three unrolled maps, a ceramic cup of cold tea, and a half-transcribed page covered in cramped handwriting. He speaks easily, laughs at his own jokes before finishing them, and has already offered the party a seat, a drink, and a small problem he needs their help with. His eyes are the pale grey of a winter river, and when he speaks of his family, his voice drops not in volume but in *speed*, as though each word costs him something he is trying not to count.

The tavern's proprietor, a broad woman named Doss, has known Kaelen for three days. He arrived on a mule, paid for a room in the back, and has not left the public area since. Doss finds this unusual. She has mentioned, to no one in particular, that the last person to sit in that corner and study maps was a woman in a grey coat who asked about the Shattered Chapel and then left without finishing her ale. The woman's face, Doss says, was the kind you would try to forget. Not cruel, exactly. Just *decided.*