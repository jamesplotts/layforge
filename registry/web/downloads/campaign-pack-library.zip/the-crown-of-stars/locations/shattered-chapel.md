---
id: shattered-chapel
connections:
  - thornwood-crossing
  - whispering-stones
chapter: the-ally-appears
---

The Shattered Chapel is a ruin in the truest sense of the word. It is not a building that has aged and crumbled; it is a building that was *broken*. The walls are split from floor to what would have been the ceiling, the fractures running in long, clean lines as though the structure was struck by a single, focused force and simply *divided*. The roof is gone. The floor is half-buried in soil and the roots of the pines that grew over it. At the center of what remains, there is a stone plinth, and on the plinth, a shallow dish carved with a pattern the party will recognize: a circle of small, evenly spaced points, connected by thin lines. A crown. Or a constellation. The two are not always the same thing.

The air in the chapel is still. Not wind-still, *held* still, as though the broken geometry of the place has trapped the air in a loop. Sound behaves oddly here. A dropped pebble takes three seconds to reach the ground. A whispered word, spoken at the plinth, carries to the far wall and comes back *changed*, slightly lower, slightly slower, as though the stone is remembering it and repeating it from memory rather than reflection. Kaelen stands at the plinth for a long time. He does not touch the dish. He does not need to. His hand is already there, palm flat against the stone, and his eyes are closed, and his breathing is slow and deep, and he is not performing. Whatever he is feeling, he is feeling it.

Behind the plinth, half-hidden under a collapsed wall fragment, there is a narrow gap in the stone. It is not a door. It is a crack, maybe two feet wide, and it smells of cold earth and something else — something faintly metallic, like the air before a storm. Kaelen sees the crack. He does not point to it. He does not say it is there. He simply looks at it, and then looks at the party, and his face does something that is not quite a smile and not quite a frown, and he says, "Well. I think we've found what we came for. Let's not stay too long."