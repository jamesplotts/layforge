---
id: whispering-stones
connections:
  - amber-lantern
  - shattered-chapel
chapter: the-ally-appears
---

The Whispering Stones are a circle of seven standing stones set in a shallow bowl of dry grass, a half-day's walk from the Amber Lantern. The stones are not old in the way of ancient ruins. They are old in the way of the earth itself: smooth, grey, slightly tilted, covered in a thin film of lichen that no amount of rain has ever fully removed. They are warm to the touch, even in cold weather. They hum. Not audibly, not in a way that registers on the ear, but in the *bones* — a low, subsonic vibration that settles in the sternum and the base of the skull and makes the jaw ache slightly. Standing in the circle for more than a few minutes, a person feels as though they are being *read*, as though the stones are listening and the listening is a kind of question.

Kaelen comes here to think. He says so, plainly, without prompting, on the first evening at the Amber Lantern. "I need to stand somewhere that doesn't talk back," he says. "These stones are honest. They don't argue. They just *are*, and I find that very comforting." He is not lying. He is not, exactly, telling the truth. The stones, if the party spends time here and pays attention, are not neutral. They are a *record*. They hold the residue of whatever happened here last, and whatever happened here last was not natural. The hum is not ambient. It is a *memory*, playing on a loop, too low to hear but too strong to ignore. Brother Aldric, if present, will feel it immediately and say, "These stones are grieving." He will not explain what he means. Not yet.

The approach to the stones is a long, straight path through open grass, and the path is *kept* — the grass is cut, the surface is packed, and there are footprints in the dirt. Many footprints. Recent. And one set, slightly larger than the others, that stops at the edge of the circle and does not continue into it. Whoever wore those boots stood at the boundary and looked in and then left. They did not enter.