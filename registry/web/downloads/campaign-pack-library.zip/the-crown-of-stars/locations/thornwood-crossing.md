---
id: thornwood-crossing
connections:
  - amber-lantern
  - shattered-chapel
chapter: the-ally-appears
---

Thornwood is not a forest so much as an argument between the trees and the earth they are planted in. The pines grow in tight, knotted clusters, their roots splitting the soil into raised ridges that make walking slow and uneven. The undergrowth is thick with bramble and low fern, and the canopy is dense enough that noon looks like dusk. The air is cool, damp, and faintly sweet — the smell of pine resin and wet bark. Birds are quiet here. Not silent, but watchful, as though the forest is listening to the party the way the party is listening to the forest.

The Crossing is a narrow point where the path narrows to a single-file track between two ridgelines. A fallen birch blocks the middle of the path, its pale trunk snapped cleanly at the base, as though something with very large hands simply *broke* it. The break is fresh. The sap is still wet. Kaelen crouches beside the tree, examines the break with a scholar's careful fingers, and says, "We should go around. I don't like it." He is not wrong. The forest is not wrong. But Kaelen is the only one who has been here before, and his certainty is *specific* in a way that will matter later if the party is paying attention.

Beyond the Crossing, the path opens slightly. There is a small clearing where the undergrowth has been trampled flat, and in the center of the clearing, something has been dug out of the earth and left exposed: a patch of root system, pale and tangled, with a faint bioluminescent glow at the tips. It pulses. Slowly. Like breathing. Kaelen touches one of the glowing tips and pulls his hand back sharply. "That's not natural," he says. Then, quieter, almost to himself: "That's not *supposed* to be here."