---
id: thornwood-ambush
location: thornwood-crossing
involves:
  - kaelen-ashborne
  - warden-garrick
chapter: the-ally-appears
---

The ambush is not a trap. This is important. It is a *collision*. Two groups of desperate, frightened people in a forest that is not safe, meeting on a path that is not wide, and the first thing that happens is a hand on a weapon and a shout and then the shouting gets complicated and someone is bleeding and someone else is shouting *not like this, not like this*, and the forest is quiet and the birds have gone and the only sound is breathing and the wet sound of a blade being wiped on a sleeve.

What the party is facing: a small band of six woodcutters and foragers, armed with axes and a short bow, who have been driven out of their clearing by a creature they call the Thornmother — a large, vaguely bear-shaped thing that has been feeding on the bioluminescent root system in the clearing and has become aggressive, territorial, and very, very angry about the party being in its space. The woodcutters are not hostile to the party. They are hostile to *the forest*, and the forest has sent the Thornmother, and the Thornmother is in the clearing, and the woodcutters have been trying to drive it back, and they have failed, and they are now in the path, and they are scared, and their leader, a broad woman with a split lip, says, "We don't want to fight you. We want to fight *it*. Can we help you?" and her voice is steady but her hands are not.

The Thornmother is a large, vaguely ursine creature — think a bear the size of a small cart, with too many joints in its legs and a coat of matted fur that glows faintly at the tips, matching the bioluminescent roots it feeds on. It is not evil. It is *hungry*, and the roots are the only food it has found, and the party is in the way, and it will try to push them out of the clearing with the same indifferent force it uses to push a tree trunk out of its path. It hits. It does not aim. It does not hate. It simply *is*, and the clearing is its, and the party is an irritation.

Kaelen handles this with competence and care. He identifies the creature, names the root system, and says, "It's not attacking us on purpose. It's defending its food source. If we give it a way out, it will go." He is correct. The party can fight it, which is possible and will cost them, or they can work with Kaelen to find the creature's den — a small, warm hollow under the largest of the glowing roots — and either drive it out gently or, if they are willing, simply *wait* for it to leave, which takes an hour and is boring and is the right answer and Kaelen will stand there with them and say "It'll be fine, it's just scared" and mean it.

The complication: Warden Garrick is watching from the tree line. He does not intervene. He does not help. He is *noting*. After the encounter, the party will find, at the edge of the clearing, a boot print in the mud. Large. Careful. The tread pattern is distinctive. Kaelen sees it. His face does something small and quick. He says, "Old print. Days old, at least." This is not true. The mud is damp. The print is fresh. The party may or may not notice. Brother Aldric, if present, will notice, and he will not say anything, and the party will feel the silence and not be able to name why it is heavy.