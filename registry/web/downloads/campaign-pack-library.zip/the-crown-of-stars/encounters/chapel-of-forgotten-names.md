---
id: chapel-of-forgotten-names
location: shattered-chapel
involves:
  - kaelen-ashborne
  - brother-aldric
  - lady-seraphine-duval
chapter: the-ally-appears
---

The chapel is quiet in the way that old, broken things are quiet: not silent, but *reduced*, as though the sound has been pressed out of it and only the shape of the sound remains. The party enters through the wide gap where the front wall used to be. The floor is uneven. The air is still. The plinth is there. The dish is there. The pattern is there. And the party is standing in the middle of a broken church in a forest, and the light is grey and flat, and Kaelen is standing at the plinth with his hand on the stone and his eyes closed and his breathing is slow and deep and he is not performing.

This is a moment of genuine, quiet beauty, and the DM should let it land. Let Kaelen stand there for a full minute. Let the party watch him. Let Brother Aldric, if present, stand slightly behind and to the side, his staff planted in the dirt, his face open and attentive and *sad*, as though he is listening to a prayer he already knows the answer to. Let Lady Seraphine, if present, watch Kaelen with an expression that is not quite admiration and not quite *assessment*, and then look away, quickly, as though she has caught herself.

The puzzle: the dish on the plinth is a lock. It has seven small indentations, evenly spaced, matching the seven stones at the Whispering Stones. The party needs to place seven small objects in the correct order to open the crack behind the plinth. The objects are not in the chapel. They are in the forest: seven small stones, each with a faint glyph, scattered in a rough circle around the chapel, each about a hand's width apart. The glyphs are not alphabetical. They are *sequential*, in the order of the constellation they form — and the constellation is not the one Kaelen described. Kaelen said the Crown's seal corresponds to the pattern of *seven stars in a line*. The actual glyphs, in order, form a *spiral*. Kaelen does not notice this. Or he notices and does not say. The party, if they are paying attention, will see the mismatch and file it. They may not do anything with it yet. That is fine. It is a seed.

What is behind the crack: a narrow passage, two feet wide, running into the earth. It is dark. It smells of cold water and old stone. It goes down. Kaelen will go first. He will say, "I've been down here before. I know the way." The party will follow. The passage is not dangerous, but it is *long*, and it is dark, and at the bottom there is a small chamber with a single object on a shelf: a fragment of seal, the size of a thumb, etched with a portion of the spiral pattern. This is what they came for. Kaelen takes it. He holds it up to the grey light. He says, "Yes. That's the one." And his voice is not triumphant. It is *relieved*, and that is the word that should stay with the party, because relief is not what you feel when you find a lost artifact. Relief is what you feel when you confirm that something you already knew is true, and the gap between those two things is where the first real doubt lives.