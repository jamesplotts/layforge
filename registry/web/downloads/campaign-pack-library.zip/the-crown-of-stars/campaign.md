---
id: crown-of-stars
title: "The Crown of Stars"
level_range: "3-8"
pvp_policy: pve_only
maturity_tier: standard
image_maturity_tier: family_friendly
shared_knowledge: strict
tone:
  - sympathetic
  - suspenseful
  - character-driven
  - tragic
  - atmospheric
author: AI-generated
chapters:
  - id: the-ally-appears
    title: "The Ally Appears"
    level_range: "3-4"
    summary: "The party meets Kaelen Ashborne, a warm and knowledgeable scholar seeking the Crown of Stars to honor his lost family. Together they survive a threat in Thornwood, explore the Shattered Chapel, and earn his trust. A small, easily-dismissed inconsistency seeds doubt."
  - id: the-cracks-appear
    title: "The Cracks Appear"
    level_range: "4-5"
    summary: "Kaelen's guidance grows subtly directed. The party stumbles on a hidden letter from his mentor, Archmage Morwenna, and notices he discourages certain inquiries. Confrontation yields a plausible but fragile explanation. Evidence suggests the Crown's true purpose is far more dangerous than 'restoring what was lost.'"
  - id: the-revelation
    title: "The Revelation"
    level_range: "5-7"
    summary: "Kaelen's true plan breaks open: he has been steering the party toward a ritual site where Morwenna intends to reshape reality using the Crown, sacrificing thousands to prevent a coming catastrophe. Morwenna's trauma is real. Kaelen is torn between loyalty and conscience. Morwenna arrives with forces, and the scope of the betrayal deepens."
  - id: the-confrontation
    title: "The Confrontation"
    level_range: "7-8"
    summary: "The final stand at the ritual site. The party must choose: stop the ritual (risking the very catastrophe Morwenna seeks to prevent), let it proceed, or find a third path. Kaelen makes his ultimate choice. Warden Garrick's hidden agenda surfaces. The world is changed, whatever the outcome."
---

## Overview

The Crown of Stars is a campaign about the terrible cost of good intentions, and the quiet violence of being loved by someone who believes the ends justify the means. At its heart stands Kaelen Ashborne: a warm, brilliant scholar who will share his last ration with a stranger and weep openly at a ruined monument. He is not a villain. He is a man who was raised by a grieving archmage, shown a vision of the world's end, and told that one ritual could avert it. He believed her. He believes her still. And he has been guiding a small band of adventurers toward a sacrifice that will consume a city, all while smiling, all while saying *this is for the best.*

The campaign is structured to let players build genuine affection for Kaelen over the first session or two, then slowly erode that trust through small, fair clues. The reveal is not a trick or a betrayal in the petty sense — it is the moment they realize the person they trusted was operating from a place of real, terrible love, and that his mentor's horror at a past magical catastrophe was not fantasy. Morwenna Vale is not a cackling schemer. She is a woman who watched her family die in a cascade of uncontrolled arcane energy and swore no one would ever watch their loved ones burn again. Her solution is monstrous. Her motivation is not.

The Warden Garrick complicates every scene he touches. He is Morwenna's blade, but his loyalty has a price tag he has not yet disclosed. Brother Aldric, the traveling monk, serves as the party's moral compass and the one character who *feels* the wrongness without being able to name it. His fate is in the players' hands — protect him and he becomes a powerful spiritual ally in the climax; neglect him and the party loses its only voice of conscience.

This is a campaign for tables that want their villains to have hearts. The final chapter offers no clean victory. Stopping the ritual means the catastrophe Morwenna saw may still come. Allowing it means thousands die. Modifying it means the party must understand magic they barely grasp and accept a partial cost. Every path is a compromise. That is the point.

## Hooks

**The Scholar at the Bar:** Kaelen is already waiting at the Amber Lantern when the party arrives, exactly where a local contact said he'd be. He has a map, a half-finished translation, and a request: he needs people with steady hands and steady nerves to walk a dangerous stretch of Thornwood and retrieve a fragment of an old seal. He pays well, shares freely, and asks no questions about their past. He just wants to get to the Shattered Chapel by week's end.

**The Monk's Warning:** Brother Aldric, passing through the same inn, catches Kaelen muttering to himself in a dialect no one in town speaks. He says nothing to the party — not yet. But he will be watching. If the party asks him why, he will say only: *"Some kindnesses are just hunger wearing a gentler face. I am not certain which this one is."*

**The Noblewoman's Letter:** A courier from Lady Seraphine Duval's household arrives at the Amber Lantern with a sealed invitation: she is also seeking the Crown of Stars and wishes to discuss a partnership. Her tone is warm, her questions precise, and her signature bears a tiny arcane seal the party has not seen before — the same symbol, if they look closely, that Kaelen traces absently on the table when he thinks no one is watching.

**The Figure at the Edge of the Road:** On the approach to Thornwood Crossing, the party sees a tall man in a grey cloak standing at the tree line. He is not hostile. He is simply *there*, watching the forest as though expecting something to come out of it. When Kaelen sees him, the man tips his head and walks away. Kaelen does not mention it again. If pressed, he says the Warden is "a friend of the road" and changes the subject with a slightly too-fast smile.