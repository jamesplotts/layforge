---
id: warden-garrick
location: thornwood-crossing
stat_block_ref: "SRD Veteran"
voice: "Sparse, low, unhurried. Speaks in short declarative sentences. Never asks a question. When he does, the silence afterward is longer than it should be."
chapter: the-ally-appears
---

Warden Garrick is not a name. It is a *function*, a title he has worn so long that the name underneath has gone soft and unclear, the way a stone in a river loses its edges. He is tall, grey-haired, and moves with the flat-footed, silent gait of a man who has been tracking things for a very long time. He does not carry a weapon that is visible. He does not need to show one.

In this chapter, he appears once. He is standing at the tree line on the approach to Thornwood Crossing, watching the forest, and when the party passes, he does not speak. He tips his head. He walks the other way. He is gone. Kaelen sees him and does not speak. The party will ask. Kaelen will say he is a friend, a road-walker, someone who knows the forest. This is true. It is not the whole truth. The whole truth is that Garrick is Morwenna's agent, and his loyalty is real, and his patience is not, and he is looking for the Crown of Stars because he wants it for himself, and he will cross Morwenna, and Kaelen, and the party, and anyone else standing between him and what he wants, and he will do it with a levelness that is almost kind.

He is not in the party's camp. He is not in the tavern. He is not in the chapel. He is at the edge of every scene, just outside the frame, and in this chapter, the party only sees him once, and the impression he leaves is *absence*: a shape that was there and is not, a sound that stopped before it finished, a feeling that something was watching and then, just as suddenly, was not.