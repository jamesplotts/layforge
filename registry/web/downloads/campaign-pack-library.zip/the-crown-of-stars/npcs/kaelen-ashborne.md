---
id: kaelen-ashborne
location: amber-lantern
stat_block_ref: "SRD Adept"
voice: "Warm, quick, self-deprecating; speaks in short, confident sentences that occasionally fracture into longer, more careful ones when the topic turns personal."
chapter: the-ally-appears
---

Kaelen Ashborne is twenty-nine, lean, and built like a long blade — narrow shoulders, long arms, a face that is handsome in a way that is slightly *too* symmetrical, as though he were a rough draft of someone more important. He moves with the easy confidence of a man who has been told he is useful enough times that he has started to believe it, and this belief is the first crack in him, because it is not quite true. He is not important. He is *useful*, and he knows the difference, and the gap between the two is where Morwenna lives.

His grief is real. His family — a sister, a mother, a father he barely knew — died in a magical cascade event in the city of Vaelthorn, six years ago. He was in the city. He was not close enough to die, but close enough to watch. He carries this the way a man carries a stone in his chest pocket: he knows it is there, he does not take it out, and it changes the weight of everything he carries. He tells the party this story on the first evening, in the amber light of the lantern, and his voice is steady, and he makes a small joke at the end, and the party feels, justifiably, that he has let them in, and that this is a man they can trust.

He is not lying. He is not, in the strict sense, lying. He is *omitting*. He is leaving out the name of the woman who told him the Crown would save the world. He is leaving out the fact that he has been to the Shattered Chapel before and knew, with a certainty he cannot fully explain, that the seal fragment would be under the birch tree. He is leaving out the letter in his coat, the one addressed to him in a hand that is careful and precise and slightly too formal, from a teacher who loved him more than she loved the world, and who is using that love as a lever.

In combat, Kaelen is a back-line support: he casts light, mends small wounds, and uses a short blade with the functional competence of someone who has trained enough to be dangerous but not enough to be a warrior. He will shield a party member with his body without thinking. He will check on the wounded first. He will say "I'm fine" when he is not fine, and the party will see the bruise on his forearm later, and he will say it was a branch, and it was probably a branch, and this is the kind of man he is.