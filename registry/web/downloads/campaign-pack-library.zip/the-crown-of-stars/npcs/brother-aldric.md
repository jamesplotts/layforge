---
id: brother-aldric
location: amber-lantern
stat_block_ref: "SRD Monk"
voice: "Slow, deliberate, occasionally funny in a dry and unintended way. Speaks in complete sentences. Pauses before answering as though weighing the cost of words."
chapter: the-ally-appears
---

Brother Aldric is fifty-three, broad-shouldered, and carries a walking staff that is slightly too long for his height, which is either a comfort or a small act of daily defiance against the world's proportions. His tonsure is neat. His robes are clean. He walks slowly, not from age but from a kind of persistent attention, as though he is listening to the ground beneath him and the ground is saying something he is trying to take notes on.

He is a traveling monk of no particular order — or so he says. He has been walking for eleven years. He does not say where he has been. He does not say where he is going. He says he is going where the road is, and this is true in a way that satisfies him and frustrates everyone else.

He senses the wrongness in Kaelen. Not as a fact, not as a conclusion, but as a *texture*, the way a person with good hands can feel a hairline fracture in a piece of glass before it becomes visible. He does not accuse. He does not confront. He watches. He asks the party small questions — *What did he say about the Chapel? Did he say who built it? Did he say when?* — and when the answers don't quite fit, he says nothing, and his face does something quiet and sad, and he goes back to walking.

Aldric is the party's moral anchor. He will not fight unless he must. He will pray if the party is in trouble, and his prayers are not performative; they are the same as the ones he says alone in the dark, which means they are long, and slightly rambling, and he occasionally loses his place and starts a sentence over, and this is the most human thing about him. If the party protects him, he becomes a powerful spiritual resource in the later chapters. If they do not, and he is killed in a skirmish or caught in a blast, the loss will be felt in every subsequent scene, and the party will not hear a single word of forgiveness or guidance to fill the silence he leaves behind.