---
id: lady-seraphine-duval
location: amber-lantern
stat_block_ref: "SRD Noble"
voice: "Measured, warm, slightly formal; uses precise language and never raises her voice. When she is uncomfortable, she smiles a little more than she means to."
chapter: the-ally-appears
---

Lady Seraphine Duval is forty-one, tall, and dresses in a way that is clearly expensive but clearly *trying not to be*, which is the mark of a woman who has been told, repeatedly, that her wealth is a problem she needs to manage. She has a small, well-trained cat in a leather case, and she speaks to the cat in a low, serious voice, and the cat is the only creature in the room who is not performing.

She is, in this chapter, a fellow traveler. She has a letter of introduction from a minor lord, she is collecting information about the Crown of Stars for what she calls "a private collection of historical artifacts," and she is polite, generous, and slightly too quick to agree with whatever Kaelen says. The party will notice this. The party will file it away. The party will not, in this chapter, be able to prove what it means.

What the party does not see: the letter in Seraphine's coat, which is not from a minor lord. It is from a woman whose name is Morwenna Vale, and it is a list of requirements. *You will travel with Kaelen. You will observe his contacts. You will report the location of any artifact fragment he identifies. You will not confront him. You will not leave his side. Failure will be noted.* Seraphine keeps this letter pressed flat against her ribs when she sleeps, and she does not sleep well, and the cat sleeps on her lap and the cat is warm and the cat does not know.