---
id: old-observatory
connections:
  - village-of-ashford
narrative_note: This location is referenced in the chapter but the party does not freely access it yet. It is the destination of a side-quest or a future chapter reveal.
chapter: the-quest-begins
---

The Old Observatory is a squat, half-buried stone structure on the shoulder of the hill above Ashford, its single dome open to the sky. For three hundred years it was the kingdom's center for astronomical record-keeping: eclipse tables, star charts, weather logs, the positions of passing comets. The last working astronomer died forty years ago. The building has been used since then as a storage shed for the village's grain reserves.

What the party does not yet know: the observatory's records include a two-hundred-year log of atmospheric events in the mountain region — ash falls, seismic tremors, unusual storms. These are the events that Thorne's prophecy attributes to Malakor's stirring. The log makes clear, in a dry clerk's hand, that each event was natural or the work of a known local creature. The records exist. They are boring. They are in a building the party has not been given a key to.

In this chapter, the observatory is a distant reference: Elder Senath mentions it, the village children point up at the dome, and a scribe at the Athenaeum notes that "the old mountain records were catalogued and filed in the Athenaeum's east wing" — a small, offhand detail that the party may or may not notice. The full contents of the observatory will become important in the second chapter, when the party has reason to ask for those records and Thorne has reason to refuse.
