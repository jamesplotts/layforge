---
id: grand-athenaeum
connections:
  - village-of-ashford
  - whispering-crossroads
  - old-observatory
chapter: the-quest-begins
---

The Grand Athenaeum rises from the capital's eastern hillside in seven terraced rings of pale limestone, each ring set with arched windows that catch the afternoon sun and throw long amber strips across the flagstones. From the street it looks like a library. From the courtyard it looks like a cathedral. From the inner sanctum, where Archmage Thorne receives his guests, it looks like a theater.

The inner sanctum is a domed chamber lined with shelves of bound scrolls, most of them decorative. A long obsidian table holds the "Prophecy of Ashes" — a single sheet of vellum with elegant calligraphy in a cipher that Thorne translates aloud, phrase by phrase, as though the party were unearthing it for the first time. The room smells of beeswax and cold incense. The acoustics are perfect. Whatever Thorne says in here sounds like a decree.

The Athenaeum's public wings are genuinely impressive: a reading hall open to scholars, a small herb garden, a workshop where scribes copy texts. The party is welcome to browse, ask questions, eat a meal in the refectory. The people here are not all liars. But the inner sanctum is a stage, and Thorne has been rehearsing his part for a long time. The doors to the east wing — where the old observatory's records were moved after the last renovation — are locked, and the key is kept on Thorne's person. They will not open this chapter.
