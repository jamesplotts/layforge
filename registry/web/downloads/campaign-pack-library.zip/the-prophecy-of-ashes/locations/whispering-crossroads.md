---
id: whispering-crossroads
connections:
  - grand-athenaeum
  - old-observatory
chapter: the-quest-begins
---

The Whispering Crossroads is where the capital's main road splits into the mountain pass route and the valley route to Ashford. The name is old and local: the wind through the basalt spires on either side of the junction creates a low, continuous moan that sounds, to the uninitiated, like a chorus of voices arguing. The sound is geological. The locals have built their inn around it — the walls are thick, the doors seal well, and the tavern's front room has a stage where traveling performers play through the noise.

The crossroads is a waypoint, a place where road-weary travelers rest for the night before choosing their direction. The inn, the Spine and the Moan, is run by a broad-shouldered woman named Dura who asks no questions about why a party of armed adventurers is heading into the mountains. The stables are clean. The rooms are decent. The food is honest.

It is also, on the night the party is meant to pass through here, where the "vision" of Oracle Morwen is scheduled. The timing is not coincidence. Thorne's script calls for the party to see the Oracle, hear the prophecy confirmed in her own mouth, and feel the weight of divine sanction settle over their shoulders before they reach Ashford. The vision will be flawless. It was rehearsed. The party will believe it. That is the point. The first crack in the story will come later, in a village, from someone who has no script to follow.
