---
id: village-of-ashford
connections:
  - grand-athenaeum
  - old-observatory
chapter: the-quest-begins
---

Ashford sits in a shallow valley where two rivers braid together before joining the main waterway. The village is small — perhaps sixty souls — and built around a square where the braid is bridged by a single timber crossing. The houses are half-timbered, the roofs are thatch, and the air smells of woodsmoke and wet wool. It is the kind of place that does not appear on the royal maps, which is precisely why Thorne's expedition is expected to pass through here.

The village is not hostile, but it is tired. Two hundred years of quiet have made Ashford a place where the worst thing to happen is a slow winter, and the people here remember a time before the kingdom's capital started sending armies through their valley. They do not know what Malakor is. They have never seen one. They do know that three militia companies passed through last month, billeting themselves in the inn and scaring the children.

The square's old well is dry — a drought this year, the villagers say. The bridge is a bit warped. The bakery on the corner sells bread that is, by small-village standards, excellent. This is a place of small, real things. It is the perfect counterweight to the grand narrative the party is carrying, and the perfect place for a one-line remark to land like a stone in still water.
