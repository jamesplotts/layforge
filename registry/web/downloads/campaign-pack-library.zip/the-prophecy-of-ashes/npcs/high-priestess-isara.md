---
id: high-priestess-isara
location: grand-athenaeum
stat_block_ref: "SRD Cleric (level 4)"
voice: "Liturgical and precise; she favors the passive voice, as though the words are being spoken through her rather than by her."
chapter: the-quest-begins
---

High Priestess Isara leads the Temple of the Eternal Flame, the kingdom's oldest religious institution. She is forty, severe in her bearing, and deeply committed to the idea that the Flame's mandate is to shepherd the kingdom through its darkest hours. She blessed the Prophecy of Ashes in a public ceremony six months ago, and she has defended it publicly ever since.

The question that will haunt the later chapters is whether she *knew*. In this chapter, the answer is deliberately ambiguous. She speaks of the prophecy as sacred text, as divine revelation. Her eyes are sincere. Her hands tremble slightly when she touches the vellum. She is either a woman who has been deceived by the most eloquent liar in the capital, or a woman who has decided that the ends justify the means and has talked herself into believing she is the means. Both versions are plausible. The party does not need to resolve this yet. They need to notice that she is *certain*, and that her certainty has a weight to it that does not quite match the flimsy vellum on the table.

If the party asks her to read the prophecy aloud, she will, and she will be moved. If they ask her where the original source text is kept, she will say it is in the temple archive and will not offer to retrieve it. If they press, she will look at Thorne. Thorne will smile. The conversation will move on. This is the first small, almost invisible thread of complicity, and the party may not pick it up until the third chapter.
