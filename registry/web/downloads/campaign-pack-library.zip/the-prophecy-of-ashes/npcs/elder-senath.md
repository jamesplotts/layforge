---
id: elder-senath
location: village-of-ashford
stat_block_ref: "SRD Commoner"
voice: "Flat, unhurried, and faintly amused; speaks as though the person she is talking to is a young person who has been told a story and is about to be told it's not true."
chapter: the-quest-begins
---

Senath is seventy-three and has been the informal elder of Ashford for the last twenty years, a role she holds by virtue of having the most stubborn memory in the valley and the least patience for nonsense. She sits in the bakery's front room most afternoons, shelling beans, and she has watched the militia go through, watched the road fill with banners, watched the capital's heralds ride through shouting about prophecies and dark lords and ancient evils. She has not moved. She has not believed a word of it. She has not argued, either. She has just kept shelling beans.

She is not a spy. She is not a secret ally. She is not going to hand the party a folder of evidence. She is a tired woman in a small village who has heard a lot of grand stories in her seventy-three years and recognized the shape of this one. If the party sits down with her — if they ask for bread, for water, for the simple thing of sitting on a bench and listening — she will talk. Not about the prophecy. About the village. About the drought. About the fact that the mountain has been quiet for two hundred years and the last time there was ash in the sky it was a volcanic vent opening in the northern range, which was in the old records, which were in the observatory, which is up the hill, which the capital's scribes locked forty years ago.

She will say this in a few sentences, flatly, over bread that is slightly too hard. She will not repeat herself. She will go back to her beans. The thread is there if the party wants to pull it. Most parties will not, not yet. That is fine. The campaign is not over.
