---
id: archmage-thorne
location: grand-athenaeum
stat_block_ref: "SRD Wizard (level 5)"
voice: "Measured, warm, and a half-step ahead of the conversation; speaks in finished sentences and never repeats himself."
chapter: the-quest-begins
---

Valerius Thorne is fifty-two, lean, and has the kind of face that makes people feel they are being understood. He dresses in the sober grey-and-amber of a senior scholar, not a combatant, and his hands are soft — the hands of a man who has not gripped a weapon in years. He speaks slowly, listens attentively, and has a habit of repeating a question back to the speaker before answering, so that every conversation in the inner sanctum feels like a dialogue rather than a briefing.

His motivation is not malice, exactly. Thorne believes, with the quiet certainty of a man who has thought a thought for two years, that the kingdom is about to fracture under the weight of a succession crisis, three regional wars, and a collapsed trade guild. He has calculated that a unifying external threat — a real one, a mythic one — will hold the factions together long enough for him to restructure the government from the inside. The party is the proof of concept. Their victory, or at least their *effort*, will be the story that justifies the restructuring. He does not see himself as a villain. He sees himself as a surgeon. The scalpel is just a little sharp.

In this chapter, Thorne is generous, patient, and open. He gives the party supplies, introductions, and a clear mission. He answers questions. He does not lie — he *omits*, which is legally and morally a different thing, and far harder to detect. If the party pushes a question, he redirects with warmth. "You will see the evidence yourself in the mountains. I would not ask you to trust me. I would ask you to trust the text." He means that. He has simply written the text.
