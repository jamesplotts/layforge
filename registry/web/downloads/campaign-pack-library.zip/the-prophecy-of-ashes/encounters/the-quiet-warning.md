---
id: the-quiet-warning
location: village-of-ashford
involves:
  - elder-senath
chapter: the-quest-begins
---

The party reaches Ashford in the early afternoon. The village is quiet. Two militia scouts are camped outside the inn, sharpening weapons and arguing about the price of horse feed. The square is empty except for a dog asleep in the sun and, in the bakery's front room, Elder Senath, shelling beans.

There is no combat here. There is no ambush. There is a woman who will offer the party a loaf of bread and a cup of water if they sit down, and a conversation that will go, in its entirety, something like this:

The party sits. Senath talks about the drought. The party asks about the mountain. Senath talks about the beans. The party asks about Malakor. Senath stops shelling, looks at them for a long moment, and says, "Two hundred years. The mountain has been quiet for two hundred years. The last time there was ash, it was a vent in the northern range, and the old astronomer wrote it down in the log at the observatory. Which is up the hill. Which the capital locked forty years ago. You want bread? It's a bit hard, I know. The oven was cold this morning."

She will not say more. She will not offer to go with them. She will not warn them explicitly. She will go back to her beans, and the conversation will end, and the party will walk out of the bakery with a slightly dry mouth and a sentence sitting in the back of their skull like a pebble in a shoe.

The encounter is designed to be small. The players should feel, afterward, that they might have missed something, but they can't quite name what. The DM should resist the urge to amplify. Senath is not dramatic. She is a tired woman with beans. The weight of the moment comes from what she *doesn't* say, from the fact that the party was expecting a riddle or a warning or a secret map and got, instead, a sentence about a locked observatory and a slightly hard loaf of bread. Let them sit with it. Let them argue about it on the road. Let them decide, by themselves, whether to go up the hill and look at the observatory, or to keep walking toward the mountain and the prophecy and the war that Thorne has already planned.

If the party does go to the observatory in this chapter, the door is locked. The grain inside is moldy. The records are not there — they were moved, years ago, to the Athenaeum's east wing, and the key is on Thorne's belt. The party can note this. They can come back. The thread is planted. The chapter does not end with a revelation. It ends with a question, small and quiet and easy to ignore, sitting in the middle of a room full of moldy grain, waiting for the party to decide whether to pick it up or walk past it.
