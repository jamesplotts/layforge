---
id: the-ash-omen
location: whispering-crossroads
involves:
  - oracle-morwen
chapter: the-quest-begins
---

The party arrives at the Spine and the Moan in the late afternoon. Dura the innkeeper gives them rooms, points them to the common hall, and disappears into the kitchen. The hall is half-full of travelers, merchants, and a troupe of traveling performers who are tuning their instruments. The wind through the basalt spires outside is louder tonight than usual; the walls vibrate faintly.

At roughly the second bell of the evening, the lights in the hall gutter. The performers stop. A figure appears in the center of the floor — a woman in a long coat of shifting, iridescent cloth, her face half-veiled, her eyes reflecting a light that is not coming from the lanterns. This is Morwen, though she does not introduce herself as such. She calls herself the Oracle. She speaks in a voice that seems to come from everywhere at once, and she speaks the Prophecy of Ashes aloud, word for word, with a cadence that makes the room go very quiet.

The vision lasts perhaps ninety seconds. Then the lights return, the figure is gone, and Dura is in the middle of the hall with a tray of bread and a look of mild irritation, as though a fly had flown in and she had swatted it. "Happens every few years," she says. "Wind in the spires, a bit of dust, a tall story. You all want another ale?"

The party will remember this moment. It will feel like confirmation, like the prophecy is real, like the divine sanction has landed. And it is — in the way that a rehearsed scene on a stage is real to the audience in the third row. The thread to pull later: the timing. The party was *expected* at the crossroads tonight. The vision was scheduled. Dura's casualness is either genuine ignorance or professional discretion, and neither of those is a lie, but both of them are a little too easy.

If the party asks Dura what happened, she will shrug. If they ask the performers, the performers will say they were mid-tune and saw a light and then it was gone. If they ask the other travelers, they will give the same account the party has already heard. No one is lying. No one is confirming. The thread is there, faint as a whisper in the spire-wind, and the party will almost certainly file it under "mystery to investigate later" and move on. That is the encounter working as designed.
