---
id: the-fabricated-ashes
title: "The Fabricated Ashes"
level_range: "3-8"
pvp_policy: pve_only
maturity_tier: standard
image_maturity_tier: family_friendly
shared_knowledge: strict
tone:
  - deceptive
  - political
  - revelatory
  - morally complex
author: AI-generated
chapters:
  - id: the-quest-begins
    title: "The Quest Begins"
    level_range: "3-4"
    summary: "The party is recruited by Archmage Thorne to fulfill the 'Prophecy of Ashes' and slay the Dark Lord Malakor. Early successes build confidence, but a village elder's quiet observation and a map that doesn't match the text plant the first seeds of doubt."
  - id: doubts-gather
    title: "Doubts Gather"
    level_range: "5-6"
    summary: "Clues accumulate: the 'evil acts' of Malakor are natural phenomena or other creatures' work. Rival scholars surface with evidence of inconsistencies. Thorne grows evasive. The party uncovers that Morwen, the Oracle, is an illusionist staging prophecies on demand."
  - id: the-truth-unveiled
    title: "The Truth Unveiled"
    level_range: "6-7"
    summary: "The full scope of Thorne's scheme is revealed: frame a peaceful ancient entity, justify a military invasion under the banner of divine mandate, and seize political power. Thorne offers the party a choice — serve him for wealth and title, or oppose him and become his enemies."
  - id: the-weight-of-truth
    title: "The Weight of Truth"
    level_range: "7-8"
    summary: "The party confronts Thorne, Isara, Ironside, and Morwen. They choose to expose the lies publicly, strike by force, or negotiate a fragile compromise. The aftermath reshapes the kingdom: a war averted or averted badly, a leader deposed or reformed, and the party's reputation forged in the fires of a truth no one wants to hold."
---

# The Fabricated Ashes

A grand quest built on a single, carefully constructed lie. Archmage Valerius Thorne has spent two years weaving the "Prophecy of Ashes" into the fabric of the kingdom's political and religious life. An ancient evil, Malakor the Dark Lord, is said to stir in the mountains — and only a chosen company of heroes, guided by prophecy, can end the threat. The party is that company. They are also his weapons.

What the player characters do not know: Malakor is a peaceful ancient entity — a great drake who has slept in the high peaks for two centuries, disturbing no one. The "prophecies" were written by an illusionist working for Thorne. The military mobilization is not a defense; it is a conquest dressed in holy cloth. The priestess who blessed the quest either did not know or chose not to look. And the whole architecture of righteous purpose that the party has been living inside was built so that, when Thorne finally needs to seize the crown, there will be no one left to call it a coup.

This campaign is paced as a slow unraveling. The first chapter gives the party everything a hero deserves — purpose, allies, a clear enemy — and then, with one quiet sentence from a tired village elder, cracks the foundation. By the final chapter, the party will know exactly who they were hired to be, and they will have to decide what to do with a truth that, once spoken, cannot be unspoken.

## Hooks

- **The Summoning Letter.** A wax-sealed letter from the Grand Athenaeum names the party as "the Chosen of Ashes" and calls them to the capital to receive their quest. The letter is beautiful, specific, and slightly too flattering. Acceptance is the hook; the wording is the first lie.
- **The Oracle's Vision.** A traveling bard claims to have witnessed Morwen the Oracle speak the prophecy aloud in a crowded market. The vision was flawless — because it was staged. The party can chase the tale to its source or simply take it at face value.
- **The General's Muster.** General Kael Ironside is mobilizing three companies of militia "to stand guard over the mountain passes." The recruitment camps are visible from the road. The party is being asked to lead the vanguard. The hook is military glory; the truth is that the army has no legitimate enemy to fight.
- **The Elder's Doubt.** A one-line remark from Elder Senath in the village of Ashford — "Malakor has not shown itself in two hundred years" — is the smallest possible hook. It costs nothing to ignore and everything to investigate. Let the party choose whether to pull that thread.
