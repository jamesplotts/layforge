---
id: the-unraveling
title: "The Unraveling"
level_range: "3-8"
pvp_policy: pve_only
maturity_tier: standard
image_maturity_tier: family_friendly
shared_knowledge: strict
tone:
  - mysterious
  - personal
  - dramatic
  - bittersweet
author: AI-generated
chapters:
  - id: the-quest
    title: "The Unraveling Begins"
    level_range: "3-4"
    summary: "The party is hired by Archmage Malachar to investigate disturbances in the coastal region of Vaelthos. What begins as a simple contract against a dark cult deepens when one PC begins reacting to ancient ruins in ways they cannot explain. A name in an old language. A symbol that warms under their touch. The first threads of a buried truth surface."
  - id: the-connection
    title: "Blood and Thread"
    level_range: "4-5"
    summary: "The PC's identity as the last heir of the Aethyn Line is confirmed. The party confronts what this means — support, fear, suspicion — while General Vane's agents learn of the discovery. A night attack at the party's camp shatters the calm, and the PC's latent power erupts in a burst of light the entire harbor can see. The world now knows a Weaver has returned."
  - id: the-confrontation
    title: "The Loom Breaks"
    level_range: "5-7"
    summary: "Vane's army marches on Vaelthos. The PC learns the full truth of their heritage: their ancestor was not a savior but a tyrant who wove the world into submission. Kael, the sibling raised among the Unwoven, arrives as both mirror and threat. The PC must decide whether to embrace the power, deny it, or forge something neither ancestor ever imagined."
  - id: the-resolution
    title: "A New Pattern"
    level_range: "7-8"
    summary: "The final confrontation is not merely a battle but a reckoning — with Vane, with Kael, with the Loom itself. The PC's choice reshapes the region and the party's bond. Power may be sealed, shared, or transformed into something the old stories never named. The thread continues, but in a pattern no one before them has woven."
---

# The Unraveling

*The Unraveling* is a personal, identity-driven campaign built around a single revelation: one member of the party is the last living heir of the Aethyn Line, a bloodline of reality-weavers scattered centuries ago during a schism that shattered an ancient civilization. The PC was an orphan, raised in a quiet coastal town, never knowing that the strange dreams they've had since childhood were fragments of a power they were never meant to inherit.

The campaign is structured in four movements, each roughly a level's worth of play. The first chapter establishes the world and the quest; the second detonates the secret; the third forces the party and the PC to reckon with what the heritage truly means; the fourth offers a resolution that is shaped by the choices the party and PC make together. The design philosophy is clear: the PC's connection is a revelation, not a railroad. The player retains full agency over how their character responds, what they tell the party, and which path they ultimately walk.

The supporting cast — Malachar the quest-giver, Morwen the Seer, Kael the lost sibling, and General Vane the purging warlord — each embodies a different answer to the question "what should be done with a power that was stolen?" Malachar believes the PC must fulfill their destiny regardless of suffering. Morwen has been quietly steering events for years and must now answer for it. Kael chose power over compassion and sees the PC as a reminder of everything they rejected. Vane simply wants the bloodline extinguished, and he has the army to make it happen.

## Hooks

- **The Commission.** Archmage Malachar, a respected scholar and former member of the Royal Cartography, personally requests the party's services. He has tracked disturbances in Vaelthos — a coastal town where a cult called the Unwoven has begun tearing the local magic from the land. He needs capable hands, and he has chosen them. His eyes, when they rest on the PC, hold a weight the others don't notice.

- **The Dreams.** Weeks before the party departs, the PC has begun waking with salt on their lips and a symbol burning behind their eyes — a loom with nine threads, eight intact and one pulled free. The dreams grow sharper as they approach Vaelthos. This is not a random omen; it is the Loom calling to its last Weaver.

- **The Name in the Stone.** Deep in the Loom Halls, an inscription in the Old Aethynic script reads a name. It is not the PC's chosen name. It is the name their parents whispered before the night the world took them. The party will see the PC read it and go still. The PC does not have to explain. But they will know, in the quiet, that this is theirs.

- **The Sibling's Shadow.** Kael does not appear in the first chapter, but their influence is felt: the Unwoven cult speaks of a "Second Thread" who will come to gather what the First has scattered. The PC, hearing this, feels a cold recognition they cannot name. A sister. A brother. Someone who was taken the same night the world ended.
