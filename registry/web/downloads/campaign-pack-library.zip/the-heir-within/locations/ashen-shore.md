---
id: ashen-shore
connections:
  - vaelthos-harbor
  - loom-halls
chapter: the-quest
---

The Ashen Shore is a stretch of black sand and shattered rock three leagues west of Vaelthos harbor, where the coastline drops into a shallow, mist-choked bay. The sand is not black from soot, as the local name suggests, but from *absence* — the magic that once animated the mineral deposits has been pulled out, leaving behind a grey, lifeless substrate that crumbles underfoot like burnt sugar. The bay water here is still and wrong: it does not lap the shore. It *holds*, like something breathing in and never quite exhaling.

The Unwoven cult operates from a series of crude shelters built among the rock formations at the shore's western edge — a dozen or so tents and lean-to structures anchored with iron stakes, their fabric the dull grey of ash. Their members number perhaps twenty, led by a figure the locals call the Shuttle, who is never seen from the tents. They are not evil in a grand, theatrical sense. They are desperate, frightened people who have been told that the Loom beneath Vaelthos is a wound in the world, and that they must *unweave* it to stop the bleeding. They are wrong. But their conviction is real, and their magic — crude, borrowed, painful — is not to be dismissed.

The Ashen Shore is where the party will first encounter the cult's work in the open. The Unwoven have set up a working platform in the shallows, a raised wooden deck where they perform their unweaving rituals. It is a place of tension: the cultists are wary, the magic is unstable, and the PC will feel, standing on that shore, a deep and wordless *grief*, as though they are standing in a room where something precious was taken from them a very long time ago.
