---
id: loom-halls
connections:
  - vaelthos-harbor
  - ashen-shore
chapter: the-quest
---

The Loom Halls are a vast underground complex carved into the basalt shelf beneath Vaelthos, accessible through a fissure in the cliff face that the fishermen call the Throat. The entrance is unremarkable — a gap perhaps ten feet wide, slick with spray, reeking of brine. Beyond it, a staircase descends in a long spiral, and the walls begin to *sing* — a low, subsonic hum that the PC will feel in their teeth before they hear it with their ears.

The halls themselves are ancient beyond reasonable dating. The stone is not carved; it is *woven*, as though the rock was grown in interlocking strands the way a weaver crosses thread over thread. The corridors branch into chambers of varying size, and the largest — the Loom Chamber at the complex's heart — is a circular room forty paces across with a raised platform in the center. The platform is empty, but the grooves in its surface form a pattern that the PC will recognize without being told. A loom. Their pattern. *Their* pattern, in a language they never learned, in a room they have never seen, in a town that is not their town.

The Loom Halls are not hostile. They are *waiting*. The magic embedded in the walls is dormant, not dead, and it responds to the PC's proximity in ways that are subtle at first — a warmth in the air, a faint glow along the carved threads, the singing dropping in pitch as the PC walks deeper. The Unwoven cult has not been here. They do not know this place exists. For now.
