---
id: vaelthos-harbor
connections:
  - malachars-tower
  - loom-halls
  - ashen-shore
chapter: the-quest
---

Vaelthos is a working coastal town of perhaps two thousand souls, built into the cliff face above a crescent of black-sand beach. The harbor is its heart: a knot of rope, tar, and salt air where fishing skiffs and merchant cogs bump against each other in the grey dawn light. The town grew around the harbor and has never outgrown it — the streets are narrow, the buildings are close together, and every family has a boat, a net, or a debt tied to the sea.

Since the Unwoven cult began its work, the harbor has gone quiet in ways the townspeople can feel but not explain. Fish that once swam thick in the shallows have thinned. The strange bioluminescent algae that used to paint the tide pools in pale blue now glows sickly amber. Children whisper that the water has started *breathing* — a slow, tidal pulse that isn't in the charts. The harbor master, Captain Rella, keeps her head down and her ledgers open, trying to act as though business is normal.

The architecture of Vaelthos is practical and weathered, but threaded through the older districts are carvings the townspeople have stopped asking about. A symbol above a doorway. A pattern in the cobblestones of the market square. They are Aethynic glyphs, worn smooth by three centuries of feet, and most residents assume they are merely decorative. They are not. The town was built *on* a Loom, even if no one living remembers why.
