---
id: malachars-tower
connections:
  - vaelthos-harbor
chapter: the-quest
---

Malachar's tower stands at the harbor's eastern edge, where the cliff face drops sharply into the churning sea below. It is not a grand structure — a cylinder of dark basalt, perhaps forty feet tall, with a single narrow window on each face and a door that opens only from the outside. Inside, the walls are lined with maps, star charts, and hundreds of small glass vials containing what appear to be frozen threads of light. The air smells of ink, dried herbs, and the particular ozone tang of working magic held in reserve.

Malachar himself is a tall, lean man of indeterminate age, with a scholar's stoop and a scholar's hands — ink-stained, precise, quick. He speaks carefully, as though every sentence is a sentence he has revised seventeen times. His office is cluttered but *organized*, which is worse than the mess it is not. He has three chairs in his reception room. He uses only two. The third is always empty, and he always pours a drink for it, though no one has ever asked what it is for.

The tower is also, functionally, a lighthouse. At night, a pale beam sweeps the harbor mouth from the apex, and the fishermen use it to navigate in. Malachar maintains it as a matter of civic duty, though the truth is that the beam is also a ward — a focused thread of woven light that keeps the Unwoven's influence from bleeding into the deeper waters. He has been maintaining it, alone, for eleven years.
