---
id: market-encounter
location: vaelthos-harbor
involves:
  - seer-morwen
  - captain-rella
chapter: the-quest
---

The party's first full day in Vaelthos should be a day of *small things*. They arrive at the harbor, they register with the local magistrates, they buy rope and lantern oil and a map of the coastline. They eat fish stew in a tavern that smells of tar. They notice the glyphs in the market square and feel, if they look too long, a faint hum in the air, like a tuning fork struck in another room.

It is in this day that Morwen makes contact. She will be at her stall — a folding table with a cloth spread over it, dried flowers in jars, a bowl of smooth stones. She will look up when the PC passes and say, *You're later than I expected. Sit down. I made tea.* The PC will sit, because they will feel, in the back of their throat, the particular grief of being *known*. Morwen will not reveal anything. She will ask questions that are not questions: *Do you dream of salt? Do you hum when you think you're alone? Did you ever look at a loom and feel it looking back?* The PC may answer. They may not. Morwen will not press. She will give them a small object — a smooth stone, worn to a particular shape by years of turning — and say, *Hold this when the water gets close. It will remember what you're about to forget.*

Captain Rella will be in the background throughout. She will watch. She will not speak to the PC directly, unless the PC speaks to her first. But if the PC lingers near the market glyphs, Rella will appear, brief and blunt: *That carving. My grandmother put it there. She said it was a promise. I didn't understand. I don't think I do yet.* And she will walk away, and the PC will be left standing in the market square, holding the stone, in a town that is not their town, feeling the weight of a name they do not yet know is theirs.
