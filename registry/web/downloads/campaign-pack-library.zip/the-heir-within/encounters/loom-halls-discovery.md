---
id: loom-halls-discovery
location: loom-halls
involves:
  - archmage-malachar
chapter: the-quest
---

The descent into the Loom Halls is slow and strange. The singing in the walls builds as the party moves deeper, and the PC's reactions grow harder to ignore: they stop at doorways they have never seen, run their fingers along carvings without explanation, and once, in a narrow corridor, they press their palm flat against the stone and whisper a word in a language none of the party recognizes. Malachar, if he is present, will go very still. He will not comment. He will look at the PC with an expression that is not surprise. It is *confirmation*.

The Loom Chamber at the complex's heart is where the chapter's central revelation lands. The platform is empty, the grooves in its surface form a loom-pattern, and the walls are covered in inscriptions. Most are in the Old Aethynic script, which the party cannot read. But one panel, near the chamber's entrance, is different. It is a name, rendered in a style that is less formal than the rest — personal, almost tender. It is the PC's true name. Not the name they were given on the beach eleven years ago. The name that was on the thread before it was cut.

The party will see the PC's reaction. The DM should let it land. The PC does not have to explain. The PC does not have to speak. But the party will watch a stranger in their own group stand in a room they have never been in and weep without understanding why, and they will not know what to do, and that not-knowing is the point. Malachar, if present, will step forward, place a hand on the PC's shoulder, and say, *You were always going to find this room. I just made sure the door was open.* And then he will step back, and the PC will have to sit on the cold stone floor, and the party will have to be in the room, and none of them will know yet what they are supposed to do with a person who has just discovered they are not who they thought they were.
