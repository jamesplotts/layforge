---
id: ashen-shore-confrontation
location: ashen-shore
involves:
  - captain-rella
chapter: the-quest
---

The party arrives at the Ashen Shore at low tide, when the Unwoven's working platform is fully exposed. A dozen cultists are gathered on the deck, arranged in a rough circle around a central point where the wood has been worn smooth. They are performing an unweaving ritual: pulling threads of local magic from the water and the sand and *unraveling* them, feeding the pulled threads into a central brazier that burns with a cold, grey flame. The effect is not immediately violent. It is a slow diminishment. The air tastes thinner. The PC may feel, if they are close to the platform, a faint *absence* behind their eyes, as though a memory has been sanded down.

Captain Rella is not present in person but her influence is: the party was sent here by her, or by Malachar through her, and she will be in the harbor, watching from a boat, ready to extract the party if the situation goes wrong. She will not intervene. She is a harbor master, not a soldier. But her presence in the background — a small figure on the horizon, arms folded — is a reminder that the world outside this shore is watching, waiting, and will not save them.

The confrontation can be resolved by force, by negotiation, or by a combination. The Unwoven are not heartless, but they are not reasonable. Their leader, the Shuttle, will not stop the ritual voluntarily. If the party attacks, the cultists will fight — not with martial skill, but with desperate, fumbling magic that is unstable and dangerous to everyone in the area. If the party talks, the Shuttle will listen, but will not believe them, because the Shuttle has been *shown* the Loom's memories and interprets them as evidence of a coming catastrophe. The PC, if they are present, will feel the ritual *pull* on them. Not painfully. Gently. Like a hand on the shoulder. The Loom is trying to speak. The party will see the PC freeze, their eyes going distant, and then a thread of pale light will rise from the PC's palm and *reweave* a section of the platform that the ritual had just torn. The cultists will drop their tools. The Shuttle will say, very quietly, *It's awake.* And then they will run.
