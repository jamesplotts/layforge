---
id: archmage-malachar
location: malachars-tower
stat_block_ref: SRD Veteran
voice: measured, precise, with the cadence of a man who has rehearsed his words and is now improvising over them
chapter: the-quest
---

Malachar is not a villain, but he is not innocent. Eleven years ago, a child was found on the Vaelthos beach with salt in their hair and a name they could not remember. Malachar was there when the child was found. He has known who that child is ever since — has known the bloodline, the heritage, the terrible weight of what the Aethyn Line carried. He did not claim the child. He did not reveal them. He built a tower, lit a ward, and waited, because he believed that a Weaver cannot be *made* to weave. They must be drawn to the Loom by the Loom itself, and the timing must be right, or the weaving will tear the world.

He is not a kind man, exactly. He is a *careful* man, which is different. He will tell the party what they need to do and why, in clear and measured sentences, and he will not lie to them. But he will *omit*. He will leave out the part where he has known the PC's identity for years. He will leave out the part where he chose, eleven years ago, to let a child be raised in obscurity because he was afraid of what would happen if the world learned a Weaver was still alive. When the time comes, he will say: *I am sorry. I had to protect you. I had to protect the pattern.* And it will be true, and it will not be enough.
