---
id: captain-rella
location: vaelthos-harbor
stat_block_ref: SRD Commoner
voice: blunt, practical, with the clipped diction of a woman who has hauled nets in every kind of weather and has no patience for poetry
chapter: the-quest
---

Captain Rella Doss runs the Vaelthos harbor out of a weathered office above the chandler's shop. She is forty-three, broad-shouldered, with a left ear missing half its cartilage from a line-snap accident that she will mention exactly once if pressed and then change the subject. She speaks in short declarative sentences. She does not use the word *perhaps*. She has three boats, a mortgage on two of them, and a standing arrangement with the local magistrates that she will report anything in the harbor that looks suspicious in exchange for not having to file the quarterly trade logs herself.

Rella is not a mystic, a scholar, or a hero. She is a harbor master who has watched the water go wrong over the past three months and has the good sense to be afraid. She will give the party practical information — where the Unwoven's tents are, how many boats have stopped coming in, where the fish used to school. She will also, if the PC lingers too long near the old glyphs in the market square, look at them with a expression that is not quite fear and not quite recognition, and say, *My grandmother put that carving there. She said it was a promise. I didn't understand. I don't think I do yet.*
