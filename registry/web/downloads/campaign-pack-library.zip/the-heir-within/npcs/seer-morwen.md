---
id: seer-morwen
location: vaelthos-harbor
stat_block_ref: SRD Commoner
voice: soft, unhurried, with a habit of answering a question the PC hasn't asked yet
chapter: the-quest
---

Morwen works the tidal market in Vaelthos as a herbalist and minor fortune-teller, a role that keeps her visible enough to be unremarkable and quiet enough to be overlooked. She is a small woman, sharp-featured, with close-cropped grey hair and hands that are always moving — threading beads, sorting dried flowers, turning a smooth stone over and over in her palm. She does not wear robes. She wears a practical coat and a belt with too many pouches.

What she is, in truth, is a thread-reader. The Aethynic tradition holds that the Loom does not merely weave the world's fabric; it also *remembers* what it has woven. Morwen can read those memories. She has been reading the PC's thread for years, from a distance, nudging events a fraction of a degree — a rumor here, a delayed shipment there, a conversation she started with a fishmonger that ended up putting the PC in the party's path. She is not omnipotent. She is not omniscient. She is a woman who saw a thread pull free in a pattern she has spent her life studying, and she chose to spend the next decade making sure that thread found its way back to the loom.

She will be in the market when the party arrives. She will know their faces before they find her. She will say, very gently, *You're later than I expected. Sit down. I made tea.* And the PC will feel, in the back of their throat, the particular grief of being *known* by a stranger.
