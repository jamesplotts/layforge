---
id: blackwater-timber-camp
connections:
  - stonefist-hold
  - crossroads-tavern
  - ironheart-grove
chapter: the-threat-appears
---

The Blackwater Timber Camp is a cluster of rough shelters, saw-pits, and a long barn where the dressed planks are stacked before being carted back to the Hold. It sits at the forest's edge, where the open grassland of the ridge meets the dense, old-growth canopy of the Blackwater. The camp is staffed by twelve miners and laborers, though three of those numbers have been subtracted since the attacks began, and the mood is close to panic.

The evidence here is what will first complicate the party's assumptions. The three dead were found in a line, roughly thirty paces apart, as if they had been struck by a single passing blow while walking in single file toward the tree line. Their gear is intact. Their tools are in their hands. And the claw marks in the ground near their bodies do not press deep into the earth the way a killing swipe would. They scrape the surface, as if the creature brushed past them rather than aiming to break them.

Near the camp, the tree line has been reinforced with new fence-posts and a trench filled with sharpened stakes — the work of a defensive force, not an attacking one. Captain Dorian Vale's tracks are everywhere: boot-prints in the mud, the smell of gunpowder and linseed oil, the snapped branches left by a man moving through undergrowth with military efficiency. He has been here for three days. He has killed nothing. He is not pleased about that.

Beyond the fence line, the forest closes in. The light shifts from gold to green to a deep, cathedral blue. The trees here are older than the Hold, their trunks wider than a dwarf's chest, their roots breaking the surface in long, knuckled fingers. The air is cooler, damper. Somewhere deeper in, water runs over stone. And if the party pushes past the fence line, into the tree line, into the dark, they will be walking into Torvin's territory. The grove is half a mile further in.
