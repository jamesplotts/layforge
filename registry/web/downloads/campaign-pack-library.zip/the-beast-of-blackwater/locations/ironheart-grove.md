---
id: ironheart-grove
connections:
  - blackwater-timber-camp
chapter: the-threat-appears
---

The grove is small — perhaps forty trees — and it should not exist. The silver-leafed trunks rise from a clearing in the forest where the soil is dark and rich and faintly warm to the touch, as if something below is breathing. The leaves are not truly silver but a pale, luminous green that catches light and holds it, so that the grove glows softly in the dark like a lantern left burning. The roots of the trees interlock at the base, forming a shallow bowl of soil in the center where a single stone stands, unworked, unmarked, ancient.

This is not a natural grove. The trees were planted here — the soil has been turned, the roots guided, the spacing deliberate. They are an anchor. A binding. The curse that holds Torvin in the shape of the werebear is tethered to this place, and as long as the grove stands, his mind is preserved. The curse feeds on the silver-leafed sap, drawing it through his bones and keeping the beast-body alive while his dwarf-self watches, helpless, from inside. If the grove is destroyed, the curse will not break. It will consume him. The beast will be all that is left, and Torvin will be gone.

The clearing is worn smooth in the center where the Beast has paced, turned, lain down. The grass is flattened in a broad ellipse. There are scratch-marks on the central stone — not deep, not aggressive, but repeated, as if the creature has pressed its palm against the rock and held it there, still, for long periods. A small pile of smooth river stones sits in a neat row at the base of the stone, placed with deliberate care. A dwarf's habit. A dwarf's prayer.

The grove is defensible. The undergrowth between the clearing and the tree line is thick and tangled. The silver-leafed trees themselves are not aggressive, but the Beast will not allow them to be cut. It will defend this place with every claw and tooth it has, and it will grieve, in the way a trapped mind can grieve, if a single leaf is torn. The party that comes here to kill a monster will find, instead, a man kneeling before a stone in a clearing of impossible trees, and they will have to decide what to do with what they see.
