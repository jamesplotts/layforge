---
id: stonefist-hold
connections:
  - crossroads-tavern
  - blackwater-timber-camp
chapter: the-threat-appears
---

Stonefist Hold clings to the eastern face of the Ironveil Ridge like a barnacle on a hull, a settlement of two hundred dwarves carved into and built upon the rock face. Three levels of workshops, dwelling-rooms, and communal halls are connected by iron stairways and wooden bridges that creak in the mountain wind. The air smells of hot metal and woodsmoke. Hammers ring from the forge district in long, rolling shifts that mark the hours for the entire community.

The settlement is proud and insular. The dwarves here have worked the iron veins of the ridge for nine generations, and they regard the Blackwater Forest to their north as a wild, uncultivated place — a place where things go wrong. The timber camps at the forest's edge are their only outward-facing economic activity, and the recent losses there have turned the Hold's mood from stubborn to fearful. Shields hang in the corridor outside the Elders' Hall. The forges have been retooled to make spears.

Elder Brynn Stonefist presides over the Hall from a chair of carved ironwood. She is tall by dwarf standards, broad-shouldered, with a scar that splits her left eyebrow in a permanent expression of irritation. She speaks plainly and does not repeat herself. To her, the Beast is a problem with a simple solution, and the party's presence is a confirmation that the solution can be carried out. She does not know — cannot conceive — that the creature she has ordered destroyed is the same man who hammered the shields now hanging in the corridor and who once fixed her husband's broken knee with a splint of rowan wood. She mourns Torvin Ironheart as a lost friend. She wants to avenge him.

The Hold is defensible but not fortified. If the party's investigation draws attention from beyond the forest, the dwarves will need to fall back on their terrain. The three levels of the Hold can be sealed with iron portcullises, and the mountain provides natural cover. But the timber camps to the north are exposed, and that is where the party will be sent first.
