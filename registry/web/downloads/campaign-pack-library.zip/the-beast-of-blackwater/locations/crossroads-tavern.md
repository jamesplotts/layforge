---
id: crossroads-tavern
connections:
  - stonefist-hold
  - blackwater-timber-camp
chapter: the-threat-appears
---

The Crossroads Tavern sits at the junction of the Hold's trade road and the older, overgrown path that winds into the Blackwater Forest. It is a low, broad building of rough-hewn timber and slate, with a thatched roof and a firepit in the central yard where travelers boil their kettles. The tavern is run by a quiet human woman named Pell, who has been here so long that the dwarves assume she is one of them. The regulars are miners heading to and from the timber camps, a handful of passing merchants, and the odd lost traveler who wandered too deep into the tree line.

Inside, the air is thick with pipe-smoke and the smell of rendered fat. A long counter holds jars of preserved fruit, bolts of cloth, and a shelf of tinctures and poultices maintained by Lyra Greenbloom, who works here three days a week. She is young, soft-spoken, with dirt under her fingernails and a habit of talking to the dried herbs hanging above her station as if they were children. The dwarves like her. She mends their cuts and keeps their coughs at bay. She has been here for two years, long enough to be accepted, not long enough to be trusted with secrets.

The tavern is where the party will first gather information about the Beast. Miners talk in low voices. They describe the creature's gait — not the shambling charge of a mindless thing, but the careful, deliberate movement of a large animal that has been burned before and is trying not to start a fire. A few mention that the Beast never came into the Hold itself. It stayed in the trees. It attacked only those who came to it with iron and flame. And once, a woman swears, it stopped mid-charge when a miner dropped his axe and put his hands up, and it looked at him — actually looked at him — before backing away into the dark.

The road through the tavern yard into the forest is the only approach to the timber camps. It is two days' walk if you know the trail, half a day if you are desperate and cut through the undergrowth. The path is well-trodden but beginning to look neglected, as if fewer miners are venturing out since the attacks began. Torches in the yard gutter in the evening. The forest beyond the tree line is a wall of black shapes in the dusk.
