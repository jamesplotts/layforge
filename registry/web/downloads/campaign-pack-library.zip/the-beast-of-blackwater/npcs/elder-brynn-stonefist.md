---
id: elder-brynn-stonefist
location: stonefist-hold
stat_block_ref: SRD Commoner
voice: Plain, direct, no wasted words. Speaks in short declarative sentences. Does not raise her voice; she does not need to.
chapter: the-threat-appears
---

Brynn Stonefist is not a cruel woman. She is a practical one, and she has buried too many dwarves in the last season to afford sentiment. She knew Torvin Ironheart. She sat at his table, drank his bitter ale, watched him argue with the forge-master about the temper of a blade. He was the kind of man who remembered everyone's name and every small favor owed, and she remembers that. She mourns him. She also needs the Beast dead, and in her mind, these two facts do not conflict. The creature in the forest is a threat to her people. The dwarf it used to be is gone. She will not pretend otherwise, and she will not let the party pretend otherwise.

She is not stupid. She is not careless. She has read the reports, looked at the claw marks, listened to the survivors. She has noticed that the pattern is odd — that the Beast does not roam, does not hunt beyond its territory, does not enter the Hold. She has noted it. She has filed it under "the creature is territorial, which is to be expected." She will not be convinced otherwise without extraordinary evidence, and even then, she will weigh it against the safety of her people. The party that walks into her hall with a story about a cursed dwarf and a sympathetic monster will find a door that does not close, but does not open either.

Her motivation is not malice. It is grief turned to purpose. She lost a friend. She lost three miners. She is not going to lose more. If the party can show her that the Beast is not the threat she believes — that it is, in fact, a man who can be helped, who has been wronged, who deserves something other than a spear through the heart — then she will listen. But she will need proof that the threat is contained, that her people are safe, and that the thing she has to grieve is not a monster but a loss. That is a harder ask than a kill order, and she knows it.
