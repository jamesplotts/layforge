---
id: lyra-greenbloom
location: crossroads-tavern
stat_block_ref: SRD Commoner
voice: Soft, quick, slightly breathless. Talks in half-sentences, finishing her own thoughts before they arrive. Laughs nervously when she is afraid. Uses "I think" and "it might be" as shields.
chapter: the-threat-appears
---

Lyra Greenbloom is twenty-three, the daughter of a human herbalist who settled at the Hold's edge six years ago. She is small, quick, and unremarkable in the way that makes her easy to overlook in a room full of dwarves. She tends the apothecary shelf at the Crossroads Tavern three days a week, and the rest of her time is spent in the forest, gathering, drying, pressing. She is not a fighter. She is not a leader. She is a girl who makes poultices and talks to plants and is terrified of what is happening in the dark of the Blackwater.

She knows. She knows what the Beast is. She knows who Torvin Ironheart was, what he built, who he sat with, what he smelled like — iron and woodsmoke and the faint, sweet tang of the honey he stirred into his ale. She knows because she was his friend, before the curse, before Malachai, before the world decided that a dwarf's stubbornness was worth more in a monster's body than in his own. She knows because she has been to the grove, in the deep of night, when the Beast sleeps, and she has seen the hands. Not the paws. The hands, briefly, in the flicker of a candle, pressing the stone, the small smooth river stones lined up in a row. A dwarf's hands. A dwarf's prayer.

She is afraid of Malachai. Not in the vague, generalized way that one fears a powerful enemy. She is afraid of him the way one fears a hand reaching into one's chest. She felt him once, years ago, when he was still kind, and he put his palm on her shoulder and she felt the cold of it, the wet, fungal cold of the thing growing in him, and she has been afraid of him ever since. She does not want the party to go after him. She does not want them to go near the grove. She wants them to understand that the thing they are hunting is a person, and she is going to say that, carefully, in a room with no doors, and then she is going to go back to her herbs and try not to shake.
