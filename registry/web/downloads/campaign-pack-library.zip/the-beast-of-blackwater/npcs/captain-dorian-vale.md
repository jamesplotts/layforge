---
id: captain-dorian-vale
location: blackwater-timber-camp
stat_block_ref: SRD Veteran
voice: Flat, clipped, professional. Speaks in the present tense. Uses "we" to mean "I am going to do this to you." Does not monologue.
chapter: the-threat-appears
---

Dorian Vale is not a villain in the way that Malachai is a villain. He is a tool. He was hired to kill a beast, and he is going to kill a beast, and the fact that the beast might have a name, a history, a daughter it can no longer see — that is not in his contract, and it is not his problem. He moves through the forest with the quiet efficiency of a man who has done this before, in other woods, against other creatures, and who does not carry the memory of any of them.

He is dangerous. He is better armed than the party, better trained in the specific task of tracking a large predator through dense undergrowth, and he has three days of head start. He has set wire snares along the likely paths, dug a kill-pit near the grove approach, and positioned two archers in the upper canopy with a clear line of sight into the clearing. If the party walks into the grove unannounced, he will assume they are the Beast's allies, or at least a complication, and he will neutralize them.

He is not irredeemable. He is not evil. He is a man doing a job, and the job is to kill a monster, and in his experience, the distinction between a monster and a man is not one that matters in the moment the arrow is loose. But if the party can show him — not argue, not plead, *show* him — that the creature in the grove is not what he has been tracking, that it is a person, that it is the same person who hammered the shields on his own belt — then something in his flat, professional certainty will crack. Whether he steps aside, or whether he draws his weapon and says "I still have a contract," is a question the party will have to answer with action, not words.
