---
id: the-beast-of-blackwater
title: The Beast of Blackwater
level_range: "3-8"
pvp_policy: pve_only
maturity_tier: standard
image_maturity_tier: family_friendly
shared_knowledge: strict
tone:
  - sympathetic
  - morally complex
  - atmospheric
  - tragic
author: AI-generated
chapters:
  - id: the-threat-appears
    title: The Threat Appears
    level_range: "3-4"
    summary: "The party is sent by Elder Brynn Stonefist to deal with the werebear terrorizing the dwarf mining community near Blackwater Forest. Their investigation reveals the 'attacks' are territorial defense, not mindless slaughter. They encounter the Beast at a sacred grove and witness its desperate protectiveness."
  - id: the-truth-becomes-clear
    title: The Truth Becomes Clear
    level_range: "4-5"
    summary: "The party uncovers Torvin Ironheart's history and the curse placed upon him by Druid Malachai. Lyra Greenbloom reveals the truth in secret, begging the party to help rather than kill. Malachai discovers the investigation and attacks, revealing his broader corruption plot and putting the party on his list."
  - id: the-escalation
    title: The Escalation
    level_range: "5-7"
    summary: "Malachai's corrupted druids and monstrous creatures descend on the region. Torvin fights alongside the party against their common enemy, demonstrating his retained intelligence and moral compass. Malachai captures Lyra and demands Torvin's surrender, forcing the party into a desperate rescue dilemma."
  - id: the-resolution
    title: The Resolution
    level_range: "7-8"
    summary: "The final confrontation with Malachai and the rescue of Lyra. Torvin faces his ultimate choice: embrace the curse fully, sacrifice something precious to break it, or accept that his former life is gone. The aftermath reshapes the dwarf community, the forest, and the party's understanding of what makes a monster."
---

## Overview

Deep in the mountains where the Blackwater Forest meets the iron-rich hills of Stonefist Hold, a dwarf blacksmith named Torvin Ironheart once hammered shields for his clan and brewed bitter ale with his neighbors. That was before Druid Malachai — a man once celebrated for his healing groves — was touched by something ancient and rotten in the deep roots of the world. Torvin, who had organized his neighbors to resist Malachai's creeping corruption of the water table, was punished: bound into the shape of a monstrous werebear, his mind intact, his body a cage of fur and claw.

Now the dwarf settlement of Stonefist Hold, led by Elder Brynn Stonefist, believes Torvin is dead. The creature they call the Beast of Blackwater has driven off armed parties, destroyed timber camps, and killed three miners who crossed into its territory with pickaxes and torches. Brynn sees a mindless terror and wants it put down. She is not wrong that the creature is dangerous. She is catastrophically wrong about what it is.

This campaign asks the party to stand in the space between a legitimate grievance and a monstrous form. Torvin Ironheart is not a villain. He is a man who remembers the smell of his forge, the sound of his daughter's laughter, the weight of a hammer he can no longer lift. He is defending the one place in the forest where the curse's hold is weakest — a grove of silver-leafed trees that Malachai planted as an anchor for the binding. He is not attacking. He is not hunting. He is a prisoner who happens to be the only thing standing between his small, dying sanctuary and the world that wants to burn it.

The true villain, Malachai, is patient and vast. He cursed Torvin not out of malice but as a harvest: the cursed essence of a proud, stubborn dwarf is a particularly rich fuel for the corruption spreading through the region's roots. The party's involvement in investigating the Beast will make them visible to him. They will not simply be solving a local problem. They will be stepping into a slow, fungal war for the soul of an entire watershed.

Every chapter escalates the moral weight. By the final session, the party will have killed creatures Malachai sent, saved a woman he imprisoned, and fought beside a monster who wept when it thought no one was watching. What they do next — whether Torvin walks free, whether the grove survives, whether the miners in Stonefist Hold ever learn their enemy was their neighbor — will be the story they carry for the rest of their lives.

## Hooks

- **The Commission.** Elder Brynn Stonefist offers a contract: gold, a deed to a workshop, and the gratitude of the clan for putting the Beast in the ground. The pay is generous. The terms are non-negotiable.
- **The Survivor's Testimony.** A terrified miner at the timber camp will tell the party what she saw: the Beast backing off, turning away, letting them run. No monster does that. Something is not adding up.
- **The Herbalist's Fear.** Lyra Greenbloom, who runs the apothecary shelf at the Crossroads Tavern, keeps glancing toward the forest. She knows something. She will tell you — if you ask the right question, in a room with no doors.
- **The Mercenary's Grudge.** Captain Dorian Vale has already set three traps and two fire-lines in the forest. He does not care about the clan's comfort. He cares about his kill count. If the party's findings conflict with his mission, he will make it clear that he is not a negotiator.
- **The Grove That Shouldn't Exist.** In the heart of the Blackwater Forest, a grove of silver-leafed trees glows faintly at night, as if lit from within. The local dwarves call it a curse-mark. The trees do not grow there naturally. Someone planted them. Someone is still tending them.
