---
id: survivor-testimony
location: blackwater-timber-camp
involves:
  - elder-brynn-stonefist
chapter: the-threat-appears
---

Sera Mosswhisker is one of the four miners who was in the timber camp when the Beast came through. She is not a soldier. She is a woman of thirty with a bad knee and a good eye for grain, and she has been shaking for two days. She will not sit down. She will not eat. She stands by the campfire and stares into the trees and speaks in fragments, as if she is still in the moment, still running, still trying to remember if the claw-mark on her shoulder is a cut or a scrape.

What she says, when the party asks, does not match the official report from the Hold. She says the Beast did not come for them. She says it came from the wrong direction — from the deep forest, moving fast, as if it was being chased or in a hurry. She says it passed them, not through them. She says the three who died were in front of her, walking single-file toward the tree line, and the Beast struck them as it passed, a single sweeping motion, not a series of kills. She says it did not stop. She says it did not look at her. She says the claw-mark on her shoulder is a scrape, not a cut, as if it brushed past her while it was running.

She says it was in a hurry. She says it was afraid. She says, very quietly, near the end, that it smelled like iron and woodsmoke. She says that is not what a bear smells like. She says she knows what a bear smells like, because she was a hunter before she was a miner, and this was not a bear.

Elder Brynn Stonefist is not present for this testimony. She is in the Hold. The party will have to carry what Sera says back to her, and they will have to decide how to frame it. "The Beast is acting strangely" is not the same as "The Beast is a man." The party has to choose, in front of Brynn, what kind of truth they offer. They can give her the scrape, not the cut. The in-a-hurry. The wrong direction. They can give her the smell. Or they can give her the whole thing, the dwarf in the dark, the man who remembers his daughter's name, and they can watch her face change, and they can pray it changes in the direction they hope.
