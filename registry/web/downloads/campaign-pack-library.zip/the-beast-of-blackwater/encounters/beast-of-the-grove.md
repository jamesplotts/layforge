---
id: beast-of-the-grove
location: ironheart-grove
involves:
  - captain-dorian-vale
chapter: the-threat-appears
---

The party enters the grove at the edge of the light, the silver-leafed trees catching the last of the sun and holding it in their leaves like embers. The air is warm and smells of wet earth and something faintly sweet, like overripe fruit. The Beast is there. It is large — easily the size of a small horse — with a coat the color of wet iron and eyes that are not the yellow of a wild animal but the dark, depthless brown of a dwarf who has been crying and will not say why.

It does not attack immediately. It stands in the center of the clearing, its back to the party, one massive hand pressed flat against the ancient stone. It is still. It has been still, the party will realize, for a long time. The scratch-marks on the stone are fresh.

When it turns, its jaw works. Something tries to form behind the teeth. It is not a growl. It is a word, broken, a consonant and a vowel that do not belong to any beast-language the party knows. It is the first syllable of a name. Its own name. It tries again, and the sound that comes out is a low, wet bark, and the eyes are wet, and the party will have to decide in the next few breaths whether to speak, to raise a weapon, to run, or to do the hardest thing of all: to put the weapon down and say "I see you."

If the party attacks, the fight is defensive and desperate. The Beast does not charge. It circles the clearing, keeping its body between the party and the central stone. It strikes with precision, not rage — a paw-swipe that stops an inch from a face, a head-butt that aims for the ground to scatter the party, not to kill. It is protecting something, and it will not let go of that protection until it is forced to. If the party is routed or retreats, the Beast does not pursue. It turns back to the stone. It presses its hand down again. It waits.

Captain Dorian Vale's archers are in the canopy. If the party engages the Beast directly, they will be fighting on two fronts. Vale does not care about the morality of the engagement. He cares about the kill. He will loose his arrows into the Beast's flank the moment it turns its back, and he will be angry if the party's hesitation gives it a chance to retreat into the undergrowth. The party must decide, in the heat of the moment, whether to fight the Beast, to fight Vale, to try to talk to the Beast while arrows whistle past, or to find a way to end the encounter without any of them winning. There is no clean solution. There is only a choice, and the weight of it.
