---
id: lyras-warning
location: crossroads-tavern
involves:
  - lyra-greenbloom
chapter: the-threat-appears
---

It happens after the party has been in the tavern for a day, after the miners have gone back to camp, after the fire has burned low and the room is quiet. Lyra is closing up the apothecary shelf, putting the dried herbs back in their jars, and she is talking to them. Not the party. The herbs. "You'll be fine, you'll be fine, I'll get you water tomorrow." She is shaking. Her hands are shaking.

The party will have to approach her. Not loudly. Not with a question. Just a presence, a hand on the back of the chair, a nod. She will look up. Her eyes will be wet. She will say, "You're going to the grove. You're going to the grove and you're going to kill it and I can't stop you, I can't stop you, I'm sorry, I'm sorry." And then she will say the rest. Not all of it. Not yet. Just enough. "It's Torvin. It's Torvin Ironheart. He's in there. He's in there and he knows you're coming and he's not going to stop you because he can't, because the grove is the only thing keeping him him, and if you destroy the grove to get to him, you kill him, and if you kill him, the beast stays, and I don't want that, I don't want that, I'm sorry, I'm so sorry, please, please, don't go in there with a weapon."

She will not say what Malachai did. She will not say how the curse works. She will not say the grove is an anchor. She is not ready. She is afraid. If the party pushes, she will shut down, go quiet, go back to her herbs, and not speak to them for the rest of the evening. The next morning, she will be back at the shelf, hands steady, voice normal, and she will say "you should get some rest" and mean it and not mean it and the party will have to find another way to get the rest of the truth, or not get it at all.

If the party is kind — if they sit with her, if they say "we'll figure it out," if they do not demand, do not threaten, do not turn the moment into an interrogation — she will say more. A name. A face. A memory of a dwarf with iron dust in his beard, arguing about the temper of a blade. She will say "he made me a set of tincture vials when I was sixteen and I still use them, they're in my bag, I carry them everywhere, and I don't know why, I don't know why I still carry them." And the party will understand that this is not a monster. This is a man. And the forest is full of men who are being made into monsters, and the one who is doing it is still out there, still patient, still growing in the dark roots of the world.
