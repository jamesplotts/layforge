---
id: temple-of-the-veiled
connections:
  - greyhollow-market-square
chapter: the-signs-appear
---

The Temple of the Veiled sits on the western edge of Greyhollow, on a low rise where the town's buildings thin and the trees thicken. It is a modest structure — white stone, a single bell tower, a courtyard where the faithful gather for the daily rite. It is not old, but it is well-kept, and the faithful who tend it treat the building with a reverence that goes beyond practical maintenance. The door is always open. The candles in the sanctuary always burn. This, Mirabel tells the party, is a sign of faith, not a maintenance schedule.

The interior is simple. A long nave, a raised altar draped in cloth the color of deep water, and a ring of benches where the congregation sits. There are no statues, no painted icons, no gilded ornament. The Veiled Faith does not venerate images. It venerates the act of seeing — the moment when a person looks at the world and acknowledges that it is larger than themselves, that the order they perceive is a gift, not a fact. Mirabel's theology is austere and, the party will notice, deeply uncomfortable in the face of the Shattering, because her faith requires that the world be meaningful, and a world that is literally breaking apart is a world for which meaning is a very hard word to keep holding.

Mirabel herself is a tall woman, perhaps fifty, with close-cropped grey hair and hands that are rough from working the temple garden. She speaks quietly. She does not raise her voice, does not gesticulate, does not need to. She has been preaching for eleven days, and she is not tired, and the party will sense that her calm is not the calm of ignorance but the calm of someone who has made a decision and is holding it with both hands.

She will welcome the party. She will offer them a room, food, and the use of the temple's small library of theological texts. She will ask them what they believe they are seeing in the sky. She will listen to their answer. And then she will say, very gently, *I understand. But I am not going to try to stop it. And I need you to understand why.*
