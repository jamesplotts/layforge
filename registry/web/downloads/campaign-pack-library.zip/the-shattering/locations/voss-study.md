---
id: voss-study
connections:
  - greyhollow-market-square
  - the-cracked-road
chapter: the-signs-appear
---

Aldric Voss's study is a squat, three-story tower at the edge of town, where the market cobbles give way to a dirt track that leads out toward the hills. The building was originally a grain silo, and the original purpose still shows in the thick walls and the narrow, spiral staircase that creaks underfoot. The ground floor has been converted into a workshop of a kind that would make a proper alchemist weep: jars of reagent solution labelled in Voss's cramped hand, a chalkboard covered in equations that have been erased and rewritten so many times the surface is scored like a palm, and a long table buried under manuscripts, star charts, and what appear to be three different kinds of dried herbs.

The upper floors are worse. The second floor is a library, but disorganized in the way that suggests the owner stopped organizing it approximately eleven days ago and has not stopped since. Books are stacked in precarious towers. Papers are pinned to every flat surface. A single lamp burns in each room, though it is daytime, and the light is steady in a way that suggests a small sustained enchantment.

The third floor is Voss's private study, and it is where the party will have their first real conversation. The windows here face east, toward the crack in the sky, and Voss has nailed a sheet of dark cloth over them. He does not look at it. He has not looked at it in four days, he admits, when the party finally gets him to speak. His eyes are red-rimmed. His hands shake. He is not a madman, the party will see, but he is a man who has been awake for a very long time and who has found the one thing he cannot fix and has run out of things to do about it.

On his desk, under a glass weight, is a single page of a ritual in a language the party does not recognize. The symbols seem to shift slightly when viewed from different angles, as though they are trying to be three different things at once. Voss calls it the Anchoring Rite. He believes it will stop the Shattering. He is not certain it will survive the casting. He does not say what the sacrifice will be. He is not sure it will be the caster's life. He is only sure it will be something that cannot be taken back.
