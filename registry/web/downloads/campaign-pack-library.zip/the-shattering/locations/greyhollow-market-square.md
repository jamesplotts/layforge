---
id: greyhollow-market-square
connections:
  - voss-study
  - the-fraying-field
  - temple-of-the-veiled
chapter: the-signs-appear
---

Greyhollow is a market town of perhaps three hundred souls, built along a bend in the River Lath where the water runs cold and the stone is pale as bone. It is not a grand city. It is a place where farmers sell grain, a tinker mends horseshoes, and the evening bells from the temple ring over a square wide enough for a market, a festival, or a funeral — and this week, it is all three at once.

The square is where the party first truly sees it. The crack in the sky is visible from the cobbles, a slow luminous seam running from the eastern horizon to somewhere above the hills to the west. It pulses faintly, like a vein under skin. The light it throws is not sunlight. It does not warm. People in the square have stopped arguing about prices and are simply standing, looking up. A woman is pressing a child's face into her shoulder. The blacksmith Oren is staring at his hammer as though he doesn't recognize it.

The Veiled Faith has set up a procession that moves in a slow circle around the square, chanting a hymn whose words the party cannot quite hear, as though the sound is arriving from slightly the wrong direction. Vendors have shuttered their stalls. The market has become a congregation of the uncertain.

This is the party's first true impression of the Shattering: not dramatic, not violent, but *wrong*. The air tastes of copper. Shadows fall at angles that don't match the light. And if the party looks carefully at the edges of the buildings, at the seams where the stone meets the mortar, they will see the faintest shimmer — the same light as the crack in the sky, just barely seeping through.

The town is still here. For now, it is still here. And that is somehow the worst part.
