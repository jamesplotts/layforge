---
id: the-fraying-field
connections:
  - greyhollow-market-square
  - the-cracked-road
chapter: the-signs-appear
---

Three miles east of Greyhollow, past the last of the farmsteads and the old stone bridge over a dry creek, the land opens into a broad field of late-season grain. It was a good field. The barley is heavy and golden, and the soil is rich, and for two hundred years the farmers here have buried their dead in the ground at the field's eastern edge.

That is no longer possible. The ground in the field is wrong. Patches of it have turned to a pale, chalky substance that crumbles when touched, and from these patches, things emerge. Not creatures exactly — not yet. They are shapes, half-formed, pressing up through the soil like blisters. They have limbs that are almost the right number, eyes that are almost the right shape, and a movement that is almost but not quite alive. When the party watches one, it watches back, and the attention it pays is cold and patient and not quite directed at them.

The air in the field is thick with a low vibration, a hum that the party can feel in their teeth. The birdsong that usually fills this stretch of country is gone, replaced by a silence that has texture. The grain stalks within a hundred yards of the worst patches have turned white and brittle, and they do not bend in the wind. They vibrate.

This is a wound in the world, small but growing. It is not the source of the Shattering — the party will learn this — but it is a symptom. A place where the membrane between planes has worn thin enough that what is on the other side can press through. The things emerging here are not attacking. They are not hostile. They are simply *here*, in a place they were never meant to be, and they do not know what to do with being in a world that is not their own.

The party will need to decide whether to engage, to observe, or to flee. The field does not care which they choose. It is simply leaking.
