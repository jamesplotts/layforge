---
id: the-cracked-road
connections:
  - voss-study
  - the-fraying-field
chapter: the-signs-appear
---

The road out of Greyhollow to the east is a dirt track, well-worn, flanked by scrub and the occasional dead tree. It was, a week ago, a perfectly unremarkable road. It is not that now.

The first mile is fine. The second mile is strange. The ground has a faint shimmer, and the scrub that lines the road grows in patterns that are almost but not quite natural — too regular, too symmetrical, as though it is trying to be something geometric and has lost the argument. The dead trees here do not decay. They are preserved, frozen mid-rot, their bark still wet to the touch. If the party presses their ear to one, they will hear a faint, rhythmic sound. It is not a heartbeat. It is closer to the sound of someone breathing, very slowly, in a language they do not speak.

The third mile is the crack. A seam in the ground, perhaps two feet wide, runs perpendicular to the road. It is not a natural fissure. The edges are clean, almost surgical, and from the seam, the same pale, wrong light that comes from the sky seeps upward. The air around it is still. The grass on either side of the seam is green and alive. The grass in the seam is white and gone. If the party looks down into it, they will see — or think they will see — a depth that does not match the width. The seam is wider than it looks. The seam is deeper than it should be.

This is a minor expression of the Shattering, a place where the rift has touched the surface of the world. It is not dangerous in the way a cliff is dangerous. It is dangerous in the way a door left open is dangerous — the threat is not in the room. The threat is in the hallway beyond.

The road continues past the crack, but the party will notice that the ground on the far side is slightly *different*. The color is almost right. The texture is almost right. The way the dust settles in the wind is almost right. It is not the same ground. The party does not need to cross it, but they will know, with a certainty they cannot explain, that it is not the same ground.
