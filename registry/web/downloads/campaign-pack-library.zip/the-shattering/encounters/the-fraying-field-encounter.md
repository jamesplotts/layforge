---
id: the-fraying-field-encounter
location: the-fraying-field
involves:
  - blacksmith-oren
chapter: the-signs-appear
---

The party arrives at the fraying field at midday, when the wrong light from the sky is at its strongest and the pale, half-formed shapes in the ground are most visible. The hum is loud enough to feel in the chest. The grain stalks vibrate. The silence where birdsong should be is so total that the party can hear the sound of their own footsteps, which is, in a field that should be rustling, deeply unsettling.

The encounter is not a combat encounter, though it can become one if the party is careless. The shapes in the ground are not hostile. They are not even fully present. They are *pressing through*, the way a thumb presses through a screen, and their attention is not on the party. It is on the field, on the grain, on the air, trying to understand a world that is not the one they came from. But they are not gentle. They are not careful. A shape that has almost fully emerged might brush against a party member as it stretches, and the contact will feel like being touched by something that is not warm and not cold and not alive, and the party member will need a save or will be shaken, confused, momentarily unable to distinguish left from right.

Oren, if the party brought him, will be the first to notice that the shapes are not attacking. He will crouch down, put his hand on the ground near one, and say, very quietly, *It's not mean. It's lost.* He will not be able to explain why he knows this. He will simply know it, the way a farmer knows that a crop is going to fail before the first frost hits. The party will have to decide what to do with that knowledge.

The field is a wound, and it is growing. The party will need to find a way to mark it, to monitor it, or to simply get out and report what they have seen. They do not need to fix it. They are not equipped to fix it. But they need to understand that this is a symptom, not a disease, and that the disease is somewhere else, somewhere deeper, somewhere they have not yet looked.

If the party tries to force a shape back into the ground, it will resist, not violently but with a kind of confused, panicked strength, and the hum in the field will spike, and for a moment the sky above the field will flicker, and the party will see, for a fraction of a second, the shape of the thing on the other side of the seam. It will be large. It will be patient. It will not be looking at them. It will be looking at the world, and it will be trying to figure out how to get in.
