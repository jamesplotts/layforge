---
id: voss-revelation
location: voss-study
involves:
  - scholar-aldric-voss
chapter: the-signs-appear
---

This is the conversation. The party is in Voss's third-floor study. The cloth over the window is dark. The lamp is steady. The symbols on the desk are shifting, just slightly, just enough that the party can see them move if they stare. Voss has been quiet for a long time. He has been holding a piece of chalk in his hand, and the chalk has broken, and he has not noticed.

He will tell them what he knows. The Architect. The experiment. The rift. The thirty days. He will tell them about the Anchoring Rite, and he will show them the page, and he will watch their faces to see if they are laughing. He will tell them about the sacrifice, and he will pause, and he will say, *I don't know what it is. I know it's real. I know it's not a coin you drop in a slot. I know it's something you give and you can't take back and you don't get to choose what it is.* He will not perform the ritual himself. He does not trust himself. He does not trust his hands. He does not trust the version of himself who has been awake for eleven days and who is starting to lose the thread.

The party will need to ask questions. What is the Architect? Why is he trapped? What was the experiment supposed to do? Voss will answer what he can. He will not know everything. He will not know who the Architect is, only what his work did. He will not know what the experiment was meant to achieve, only that it failed and that the failure is the Shattering. He will not know if there is another way, because he has looked for another way for eleven days and he has not found one, and the not finding is the thing that is keeping him awake.

At the end of the conversation, Voss will ask the party to do one of two things. Help him complete the ritual. Or help the town prepare to die. He will say both options in the same breath, without pause, without emphasis, because he is not asking them to choose. He is telling them that those are the two things he can think of, and he cannot think of a third, and he is out of things to think of. The silence after he says this will be the loudest sound in the room.

The party does not have to decide now. They do not have to decide tonight. But they will leave this room knowing that the clock is ticking, that the sky is cracking, that the field is leaking, and that the man who knows the most about what is happening is the one person in Greyhollow who is not in a position to stop it. And that the only thing they have is time, and they do not have much of it.
