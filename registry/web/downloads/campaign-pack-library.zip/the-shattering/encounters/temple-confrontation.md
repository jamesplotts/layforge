---
id: temple-confrontation
location: temple-of-the-veiled
involves:
  - high-priestess-mirabel
chapter: the-signs-appear
---

The party arrives at the temple in the late afternoon, when the wrong light from the sky has taken on a deeper, more amber quality and the shadows in the courtyard are longer than they should be. Mirabel is in the nave, kneeling, and she does not look up when the party enters. She finishes her prayer. She stands. She turns. She looks at the party, and she says, *Come in. Sit. Tell me what you are seeing in the sky, and I will tell you what I see.*

This is not a confrontation. It is not a debate. It is a conversation, and it will go the way Mirabel intends, which is that the party will make their case, and she will listen, and she will be kind, and she will not be persuaded. She will explain her theology in plain language, without jargon, without condescension. She will say that the Shattering is the world completing a cycle. She will say that the Architect's experiment did not cause the Shattering; it revealed it. She will say that the appropriate response is not to fight the tide but to build a shelter, to be with the people you love, to make the end a choice rather than a catastrophe.

The party will push back. They will say that thirty days is not enough time to prepare, that the people in the field are suffering, that the creatures bleeding through are not a divine sign, they are a wound. Mirabel will acknowledge each point. She will not argue. She will say, *You are right that it is not enough time. You are right that it is a wound. You are wrong that it is a problem that can be solved. And I need you to understand that I am not wrong, even if I am not right.*

She will offer the party a room. She will offer them food. She will offer them the use of the temple's library, which contains two hundred years of the Veiled Faith's theological texts, and if the party searches the right volume, they will find a passage from the early faith that speaks of a *world that was broken and remade, and the hands that broke it were the same hands that remade it.* It is not a reference to the Architect. It is not a reference to the Shattering. But it is close enough that the party will carry it with them, and it will not leave them alone, and it will keep them turning the question over in their minds for the rest of the chapter.

She will not stop them. She will not block the door. She will simply stand in the nave, in the amber light, and watch them go, and she will say, *I will be here. When the sky finishes breaking, I will be here. And I will not be alone. And that is not a threat. It is a promise. And I will keep it.*
