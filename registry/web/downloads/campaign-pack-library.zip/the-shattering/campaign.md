---
id: the-shattering
title: The Shattering
level_range: "3-8"
pvp_policy: pve_only
maturity_tier: standard
image_maturity_tier: family_friendly
shared_knowledge: strict
tone:
  - epic
  - desperate
  - morally complex
  - cosmic
  - bittersweet
author: AI-generated
chapters:
  - id: the-signs-appear
    title: The Signs Appear
    level_range: "3-4"
    summary: "The party arrives in Greyhollow as the sky begins to crack. They encounter strange omens, plane-creatures bleeding through the fraying world, and learn of two competing responses: Scholar Aldric Voss's desperate ritual or High Priestess Mirabel's call for repentance and acceptance. The chapter ends with the party choosing a path of investigation."
  - id: the-truth-emerges
    title: The Truth Emerges
    level_range: "4-6"
    summary: The party investigates the source of the Shattering and discovers the rift at the heart of the old ruin. There they find the Architect — an ancient mage trapped inside his own failed experiment, begging for help. His experiment was not an act of malice but a desperate attempt to seal a gateway to a primordial evil. The party learns the Shattering is both a catastrophe and a failed salvation.
  - id: the-escalation
    title: The Escalation
    level_range: "6-7"
    summary: "The Shattering accelerates. The sky tears wider, and the seal fails faster. The party discovers the true nature of the primordial threat and the full cost of Aldric's ritual. The Anchor, a sympathetic being from another plane, offers partial help but demands a price. The party must choose: perform the ritual, let the Shattering complete and face what bleeds through, or find a third way before time runs out."
  - id: the-resolution
    title: The Resolution
    level_range: "7-8"
    summary: The final confrontation at the heart of the rift. The party faces the Architect, the failing seal, and the primordial evil pressing through. Their choice reshapes the world — the ritual's cost, the seal's fate, and what the region becomes in the aftermath. The campaign closes with the weight of what was saved, what was lost, and what changes.
---

## Overview

The sky is cracking. Not metaphorically — visible, luminous tears split the firmament like porcelain struck with a hammer, and through them, wrongness leaks into the world. Creatures that have no business existing in this plane slither and stumble out of the seams in the air, and the air itself tastes of copper and static. In thirty days, or perhaps fewer, the Shattering will complete and this region will be unmade.

At the center of the crisis stands Scholar Aldric Voss, a half-mad genius who identified the cause: an ancient magical experiment, performed millennia ago by a mage called the Architect, has destabilized the fabric of reality. The Architect is still alive, trapped inside the rift he created, and his experiment was never meant to destroy the world. It was meant to save it. The only thing that can stop the Shattering is a ritual Aldric has reconstructed from fragmentary texts — a ritual that demands a terrible sacrifice, and whose full cost he may not yet understand.

Opposing him is High Priestess Mirabel of the Veiled Faith, who interprets the Shattering as divine judgment. The world has sinned, she argues, and the appropriate response is not to fight the apocalypse but to repent, to prepare the faithful, and to meet the end with dignity and prayer. She is not wrong that the people are suffering. She may not be wrong that resistance is futile. But she is, the party will discover, missing the most important fact of all.

And then there is the Architect himself — ancient, weary, terrified, and still fighting to hold the seal. He is not a villain. He is a man who looked at an unspeakable threat and did the only thing he could, and whose solution is now consuming the very world he tried to save. Helping him is not simple. Stopping him is not easy. Letting the Shattering proceed is not survivable.

The party must decide, under pressure, with incomplete information, and under the eyes of a fracturing sky, what they are willing to sacrifice for the world to continue.

## Hooks

- **The Cracked Sky:** The party witnesses the sky splitting for the first time — a slow, silent tear that pours pale, wrong light over the town of Greyhollow. Crows fall dead. A child sees something moving in the seam and won't stop screaming. This is the event that draws the party in.

- **Voss's Summons:** Aldric Voss has been sending letters to every adventurer, scholar, and mage in the region. His letters are frantic, half-finished, and end with the same line: *If you are reading this, you still have time. Please come to Greyhollow. Please. I don't know what else to do.*

- **The Bleeding Field:** Three miles east of town, a field has become a wound in the world. Every morning, new creatures emerge from the ground — things with too many joints, eyes that see in colors the local flora wasn't built for. The farmers have stopped going near it. The party can find the field by following the silence where birdsong used to be.

- **Mirabel's Sermon:** The Veiled Faith has declared the Season of Closing. Mirabel preaches daily, and her sermons are calm, beautiful, and utterly certain. *The sky is not breaking. The sky is closing. There is a difference. The sky is not breaking. It is finishing its work.* She will welcome the party. She will offer them a place to stay. She will not let them leave with the same questions they arrived with.

- **The Anchor's Whisper:** If the party is attuned to the arcane, or if they touch the seam in the sky at the right moment, they will hear a voice that does not belong to this plane. It is calm. It is tired. It says: *I have been holding this for a very long time. I am almost done. Please — find a way before I break.* The voice is the Anchor, and it is the first sign that the Shattering is not simply a disaster. It is a failing.
