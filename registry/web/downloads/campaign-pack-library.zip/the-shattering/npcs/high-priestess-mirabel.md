---
id: high-priestess-mirabel
location: temple-of-the-veiled
stat_block_ref: "SRD Commoner (social role: religious leader and community anchor)"
voice: Calm, quiet, absolutely certain — speaks in short declarative sentences, never raises her voice, and has a way of repeating a phrase back to the speaker that makes them reconsider what they said
chapter: the-signs-appear
---

Mirabel is not wrong that the world is suffering. She is not wrong that the people of Greyhollow are afraid. She is not wrong that the sky is cracking, that the fields are leaking, that the air tastes of copper and the birds have gone silent. She sees all of this. She has seen all of this for eleven days. And her response, which she will lay out to the party with the steady patience of someone who has rehearsed this conversation a hundred times in her head, is that the Shattering is not a problem to be solved. It is a truth to be met.

The Veiled Faith teaches that the world is a gift, and a gift can be returned. Mirabel has extended this principle to its logical conclusion: the Shattering is the world being returned. Not by a cruel god, not by a vengeful spirit, but by the natural order completing a cycle that was always going to end. The Architect's experiment, she believes, was not a failure. It was a symptom. The world was already fraying before he touched it. He simply made the fraying visible. And the appropriate response is not to fight the fraying but to prepare for what comes after.

She is not malicious. She is not deluded. She is a woman who has looked at an apocalypse and decided that the most honest thing a person can do is to stop pretending they can stop it, to sit with the grief, and to make the end as dignified as possible. The party will find her compelling. The party will find her wrong. But they should not be quick to dismiss her, because her grief is real, her community is real, and the people she is trying to protect are real and frightened and need someone to tell them what to do when the sky is falling.

She will not stop the party. She will not threaten them. She will simply, gently, insist that they understand what she believes before they leave her temple. And she will be right that they should.
