---
id: scholar-aldric-voss
location: voss-study
stat_block_ref: "SRD Commoner (social role: scholar and researcher)"
voice: Frantic, precise, self-deprecating — speaks in long, tangled sentences that keep circling back to the same terrifying fact
chapter: the-signs-appear
---

Aldric Voss is not a hero. He is not a warrior, not a priest, not a political figure. He is a scholar — a man who has spent thirty years reading the margins of other people's work and who, eleven days ago, found the one passage that mattered and understood, with a cold and absolute certainty, that the world he has lived in for fifty-two years is ending. He is not brave. He is terrified. He is sending letters to people he has never met because he does not know what else to do and because, in the small private arithmetic of his mind, sending a letter is the closest thing to acting that he is capable of.

His knowledge is real. His ritual is real. His fear is real. What is not real is his certainty. He believes the Anchoring Rite will work, but he is reading it from fragments, and the fragments are in a language he only half-understands, and the symbols shift when he looks at them too long. He knows the ritual requires a sacrifice. He does not know what the sacrifice is. He suspects it may be the caster's life, but he has seen enough of the Architect's original work to know that the man's magic does not operate on the logic of simple exchange. The cost may be something worse than a life. It may be a memory. A name. A connection. He does not know. He is not ready to find out.

He wants the party's help because he cannot do this alone. He wants their judgment because he does not trust his own. He wants them to believe him because the alternative — that he is the only sane person in a town full of people who are slowly losing the thread — is a thought he has been avoiding for six days. If the party is kind to him, if they do not laugh, if they sit in his study and look at the shifting symbols on the desk and say *yes, this looks like a catastrophe*, he will cry. He has not cried in eleven days. He will need them to be steady.
