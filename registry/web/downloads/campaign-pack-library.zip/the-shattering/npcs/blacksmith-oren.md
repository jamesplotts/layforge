---
id: blacksmith-oren
location: greyhollow-market-square
stat_block_ref: "SRD Commoner (social role: blacksmith and local information broker)"
voice: Blunt, practical, slightly superstitious — speaks in short, clipped phrases, uses a lot of hands to talk, and has a habit of saying things slightly too loudly before catching himself
chapter: the-signs-appear
---

Oren is the blacksmith. He has been the blacksmith for nineteen years, and in that time he has mended every horseshoe, plowshare, and gate hinge in Greyhollow and the surrounding farms. He is a broad-shouldered man with forearms like bridge cables and a habit of talking with his hands, which is a problem in his workshop, because his hands are usually covered in soot and he has a tendency to wave them at people's faces while he is making a point.

He is not a scholar. He is not a priest. He is a man who fixes things, and what he is seeing — the sky cracking, the ground shimmering, the grain going white and brittle — is not a thing he can fix, and that is the thing that is breaking him. He has been up for four days, not sleeping, going to the square every morning and standing in front of the crack in the sky and trying to decide whether it is a weather thing. It is not a weather thing. He knows it is not a weather thing. He does not say this to the party in the first conversation. He says it on the second one, after the party has helped him mend a gate hinge that the wind snapped in half, and he is tired, and he has stopped pretending.

He knows the field to the east is wrong. He knows the road to the hills is not the road it used to be. He knows that the things in the field are not animals. He does not have words for what he knows. He has a hammer, and he has a gate hinge, and he has a town full of people who are looking up at the sky, and he is going to keep fixing things, because it is the one thing he can do, and because if he stops, he has to look at what is actually happening, and he is not sure he can do that yet.

He will give the party directions to Voss's tower if they ask. He will give them a warning about the field if they are thinking of going there. He will not follow them. He is a blacksmith. He fixes things. The sky is not a thing he can fix. But he will make sure their gear is in good order before they go, and he will charge them half price, and he will say, very quietly, *Come back. I don't care if it's in three days or in three weeks. You come back and you bring me something I can fix. Something small. Something I can make right.* And he means it. He means it in a way that the party will not forget.
