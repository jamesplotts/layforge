---
id: private-gardens
connections:
  - grand-ballroom
  - wine-cellar
chapter: the-masks
---

The Ashford Palace gardens are a walled quadrangle just beyond the ballroom's western doors, open to the night sky and the low murmur of the harbour. Topiary in the shapes of heraldic lions lines the gravel paths. A fountain stands at the centre, its basin carved from pale stone, the water running thin and cold in the evening air. Lanterns hung from iron arches cast a warm amber glow over the beds of night-blooming jasmine, their sweetness cloying in the cool air.

The gardens are where the masquerade's more private conversations happen. Pairs of masked guests linger beneath the arches, their voices low. A solitary figure might sit on the fountain's edge, feet dangling over the water, adjusting the ribbon of their mask. The space is intimate enough to feel like a stage set for a secret, open enough that no one can be entirely certain they are not being watched.

From the gardens, a wide flight of steps leads back up to the Grand Ballroom's western doors. A narrow servants' path curves along the south wall and descends to the Wine Cellar through an iron-grated door set into the garden wall. The north gate, locked from the inside, opens onto the palace's outer courtyards — the only exit that does not pass through the main hall, and the one no guest is expected to use.
