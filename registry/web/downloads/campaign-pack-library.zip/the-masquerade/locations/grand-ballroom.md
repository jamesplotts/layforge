---
id: grand-ballroom
connections:
  - mirror-antechamber
  - private-gardens
  - wine-cellar
chapter: the-masks
---

The Grand Ballroom of Ashford Palace occupies the full width of the building's east wing. The ceiling is a painted dome — a storm over a coastline, the clouds rendered in gold leaf that catches the light of three hundred candlesticks. The floor is black marble, polished to a mirror sheen, inlaid with white veins that make every dance floor look like a river seen from a great height. Banners of deep violet and charcoal hang from the gallery railings, and the air is thick with the scent of beeswax, spiced wine, and the faint salt tang that never quite leaves Vaelmoor.

Every guest wears a mask. Some are elaborate — gilded, jewelled, sculpted in the shapes of birds or demons. Others are simple: a strip of black leather over the eyes, a smear of charcoal on the cheeks. Each guest has been given a false name and a card to pin to their breast. The rules, announced by Lady Seraphina at the entrance, are absolute: you speak only as your mask-name. You do not confirm, deny, or hint at who you truly are. Violation is expulsion. The rule is enforced politely, with a smile and a hand on the elbow, and no one has yet broken it.

The room is divided by function: a wide central floor for dancing, a long gallery along the north wall where guests sit in upholstered chairs and converse in low voices, and a raised dais at the far end where Lady Seraphina presides over the evening from a chair of black iron and velvet. Musicians play from a small stage tucked into the western alcove. The party, as named guests, have seats on the dais — close enough to Seraphina to hear her, close enough to the crowd to see every mask.
