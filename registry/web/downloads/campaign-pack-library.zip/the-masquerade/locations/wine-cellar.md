---
id: wine-cellar
connections:
  - grand-ballroom
  - mirror-antechamber
  - private-gardens
chapter: the-masks
---

The Wine Cellar is a vaulted room cut into the bedrock beneath the palace, its ceiling a smooth arch of dark stone studded with points of rusted iron. Racks of bottles stretch from floor to ceiling along three walls, their labels faded to illegibility. The fourth wall is bare, and a single oil lamp on a stand casts a weak, amber pool of light. The air is cool, dry, and tastes of old wood and the faint mineral tang of the rock.

The cellar is not meant for guests. It is where the palace's servants draw wine for the ballroom, where a few of the more adventurous guests venture in search of a stronger bottle or a private moment. The acoustics are strange here — a whisper carries further than it should, and a footstep on the stone floor sounds like a knock. The lamp flickers with a breeze that seems to come from nowhere, as if the cellar breathes.

Three paths lead out: a short stair ascending to the Mirror Antechamber, a wide service corridor running east toward the Grand Ballroom's kitchen wing, and a narrow passage along the south wall that climbs to the private gardens through the iron-grated door. The cellar is the one place in the palace where no one is expected to see you, which makes it the one place where someone would go to be seen by only one person.
