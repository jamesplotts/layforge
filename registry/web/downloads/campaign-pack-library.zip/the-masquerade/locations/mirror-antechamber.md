---
id: mirror-antechamber
connections:
  - grand-ballroom
  - wine-cellar
chapter: the-masks
---

The Mirror Antechamber is a narrow, octagonal room connecting the Grand Ballroom to the palace's lower levels. Its walls are lined floor-to-ceiling with tall beveled mirrors, each set in a frame of dark bronze. The effect is disorienting: step inside and you see yourself multiplied, reflected in reflections, a corridor of duplicated faces stretching into a depth that the room cannot physically hold. Candles are set on a low table in the centre, their light fracturing across the glass until the room glows with a soft, silvered flicker.

The antechamber is quiet in a way the ballroom is not. Conversations drop to whispers here, as if the mirrors are listening. A few guests retreat to this room to adjust their masks, to steady their breathing, to stare at their own reflections and wonder if the face looking back is the one they want to be seen as. The mirrors themselves are old — the glass is slightly green at the edges, and the reflections are a half-second slow, as though the images in the glass think a little before they move.

The room has two exits: a broad archway back to the Grand Ballroom on the east wall, and a narrow stair descending to the Wine Cellar on the west wall. A small service door on the north wall, barely wider than a person, leads to the private corridors that connect to the gardens. The antechamber is where masks are adjusted, where lies are rehearsed, and where, if the party looks closely, a reflection might not quite match the person standing in front of it.
