---
id: the-fountain-conversation
location: private-gardens
involves:
  - aldric-the-spy
  - nyx-the-changeling
chapter: the-masks
---

The party is drawn to the private gardens, either by a whispered invitation from a masked guest, by the scent of jasmine pulling them through the western doors, or by the simple need to step out of the ballroom's thick air. The fountain is running. The lanterns are low. And there, sitting on the fountain's edge with their feet barely touching the water, is a figure in a mask of pale green glass — the shape of a moth's wing folded over the eyes.

This is Nyx, though they do not say so. They are talking to the figure across from them, a man in a plain black mask, and the conversation is odd. Not because of what is said, but because of the *quality* of it. Nyx is asking questions that sound like small talk but are not. *What does it feel like to be known?* *Do you remember the day you became the name you have now?* *If I touched your face, would you let me?* The man — Aldric, though neither of them uses that name — answers with a patience that is not quite patience. It is the stillness of a mechanism waiting for its input. He is not talking to Nyx. He is cataloguing Nyx. Noting the way the mask sits slightly too loose on the jaw. Noting the half-second delay in the reflection from the fountain's dark water. Noting that the face beneath the mask is *almost* the face of a woman he was told to find, but not quite, and not in the way he was told to look for.

The party's arrival changes the dynamic. Nyx's posture shifts — a small tightening, a flicker of the skin at the temple where the borrowed face is not quite bonded. Aldric's eyes, visible above the black mask, move to the party and then back to Nyx with the flat assessment of a man measuring a door for a key. The conversation does not stop. It *adapts*. Seraphina's name comes up. The Duke's name comes up. The word *face* is used four times, in four different ways, and none of them means the same thing.

This is not a fight. It is a room with three people in it, and one of them is not the shape the other two think they are, and the party has walked in and now there are four, and the geometry of the room has changed, and no one has said yet what changed it. The DM should let the conversation unfold at the party's pace, let them ask questions, let them be deflected or engaged, and let the small wrongness of Nyx's presence — the half-second lag, the too-loose mask, the way the lantern light hits their skin and does not quite bounce back — be the thing that a careful player will notice, and a careless player will miss, and both outcomes are valid, and both will matter later.
