---
id: the-welcome-reception
location: grand-ballroom
involves:
  - lady-seraphina-du-lac
  - nyx-the-changeling
chapter: the-masks
---

The party enters the Grand Ballroom through the palace's main doors, and the first thing they notice is the silence. Not a true silence — the musicians are playing, the crowd is murmuring, wine is being poured — but a *held* silence, a collective breath-in, as if three hundred people have paused to look at the new arrivals. Lady Seraphina is waiting at the dais. She greets each member of the party by name — their *true* name, which should not matter under the masquerade's rules, and the small wrongness of that should register in every player's chest.

Each party member is handed a mask and a false name. The masks are beautiful and strange: one is carved from pale wood and shaped like a sleeping fox. One is a smear of black glass over the upper face. One is a net of silver wire that catches the light and scatters it. The false names are written on small cards in a hand that is almost, but not quite, Seraphina's. The party pins their cards to their breasts and takes their seats on the dais. The music resumes. The dancing begins.

In the first ten minutes, nothing is wrong. The wine is good. The food is good. Seraphina moves through the crowd, greeting guests, smiling, saying the names on their cards back to them with a warmth that feels like a hand on the shoulder. Then, as the party settles in, the small wrongnesses begin. A guest in the gallery refers to his companion as *Seraphina* — but Seraphina is sitting on the dais, watching the dance. A woman in a crimson mask asks the party's table if they have seen her *husband*, a man the party is fairly certain died three years ago. In the Mirror Antechamber, visible through the archway, a figure stands very still before a mirror, and their reflection is a half-second late, and for a moment the face in the glass is not the face of the person standing there.

This is the party's first thread to pull. The encounter is not a combat. It is an observation. The DM should let the party notice, question, and be gently deflected. Seraphina's smile does not waver. The guest with the dead husband's name does not notice the contradiction. The figure in the antechamber is gone when the party looks up. The masks are secure. The names are pinned. The night is young. And something in the room is wearing a face it was not born with, and no one has noticed yet, and that is the point.
