---
id: masquerade-of-shattered-faces
title: The Masquerade of Shattered Faces
level_range: "3-8"
pvp_policy: pve_only
maturity_tier: standard
image_maturity_tier: family_friendly
shared_knowledge: strict
tone:
  - deceptive
  - atmospheric
  - morally complex
  - tense
  - mysterious
author: AI-generated
chapters:
  - id: the-masks
    title: The Masks
    level_range: "3-4"
    summary: The party arrives at Lady Seraphina du Lac's grand masquerade. Everyone wears a mask; identities are fluid and unreliable. The party learns that at least one guest is wearing a stolen face — the fey creature Nyx is hunting for a new identity among the crowd.
  - id: the-deception-deepens
    title: The Deception Deepens
    level_range: "4-5"
    summary: "Every NPC at the masquerade is lying about something. The party must identify the one genuine soul among the schemers — a victim, a witness, or an ally. The gathering is exposed as a meeting of spies, assassins, and political players. Cliffhanger: someone is using the party's true identities against them."
  - id: the-reveal
    title: The Reveal
    level_range: "5-6"
    summary: The masquerade is a cover for a political assassination. Aldric moves to kill the Duke of Ashford — but the Duke is not who anyone believes. The real Duke of Ashford is dead; the man in the ballroom is the assassin. The party was invited to serve as witnesses or scapegoats.
  - id: the-resolution
    title: The Resolution
    level_range: "6-8"
    summary: The party confronts the full conspiracy. They must decide whom to trust, what to do with the truth — expose the scheme, take a political side, or let the masquerade's players destroy one another. The region's power structure shifts, and the party faces the cost of their choices.
---

# The Masquerade of Shattered Faces

In the coastal city of Vaelmoor, where salt fog rolls off the harbour and the old noble houses cling to a fading order, a single invitation changes everything. The party receives an ornate card sealed in black wax: they are guests of Lady Seraphina du Lac at the Festival of Masks, a grand masquerade in the Ashford Palace where every guest must wear a mask and claim a false name. The night will be one of music, dance, wine, and danger dressed in silk.

But the masquerade is not what it appears. Every guest is lying. Some wear the faces of the dead. Some are agents of rival houses. One is a fey creature from beyond the veil, pressing its fingers against strangers to steal their very identity. One is a killer who does not yet know whose throat he is meant to open. And the man everyone believes is the Duke of Ashford may not be the Duke at all — or may be far more than a Duke.

This is a campaign of layered deception, moral ambiguity, and the slow, vertiginous discovery that the ground beneath your feet is not solid. The party will not solve a puzzle; they will be *inside* the puzzle, their own identities questioned, their alliances tested, their choices carrying the weight of a city's future. The masks here are not merely costume. They are weapons, shields, and mirrors. Remove one, and you cannot put it back.

The tone is atmospheric and tense, with moments of dark humour and genuine warmth. There is no single "correct" path — the party may expose the conspiracy, protect a guilty person, walk away, or take a side. Each choice reshapes the aftermath. The DM should let the confusion breathe, let the party feel genuinely uncertain, and let every reveal land like a door slamming shut in a drafty room.

## Hooks

- **The Invitation.** An ornate card arrives by courier: the party is invited to the Festival of Masks as honoured guests of Lady Seraphina du Lac. The card bears a seal they recognise — perhaps their own guild mark, perhaps a face they thought was dead. Accepting means entering a room where no one is who they say they are.
- **The Missing Face.** A local innkeeper or minor noble approaches the party in desperation: one of their household members was invited to the masquerade and has not returned. The party is hired to find them — not knowing that the masquerade itself is the trap.
- **The Rival's Whisper.** A contact from a rival noble house slides the party a sealed note: the Ashford Palace is hosting a gathering of spies and killers. The note asks the party to attend, observe, and report. What they are not told is that the note itself is a lie, and the masquerade's true purpose is far darker than a spy meeting.
- **The Dead Man's Mask.** A mask crafted in the likeness of a recently deceased person is found in the party's quarters the morning before the festival. No one claims to have placed it there. The message is clear: the party is already part of the game, whether they chose to play or not.
