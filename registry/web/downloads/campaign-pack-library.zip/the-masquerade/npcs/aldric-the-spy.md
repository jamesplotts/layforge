---
id: aldric-the-spy
location: private-gardens
stat_block_ref: SRD Veteran (use SRD Veteran base statistics; add proficiency in Stealth, Deception, and Intimidation; replace one combat action per round with a non-lethal grapple or a whispered command as a bonus action)
voice: clipped, efficient, polite in the way a knife is polite — short sentences, no wasted syllables, a faint accent that belongs to no single region the party knows
chapter: the-masks
---

Aldric is not a spy in the way a storybook understands spies. He is a function. A mechanism. A man who has been trained to receive an order, to execute it, and to not understand the order's purpose any more deeply than the mechanism of a lock. He was given a name to use tonight, a mask to wear, and a target to find. The target's face was described to him in three words and a gesture. The target's name was never spoken aloud.

He does not know that the target may not be who his handlers believe. He does not know that the masquerade's host has her own design on the evening. He does not know that the man everyone in the ballroom is calling the Duke of Ashford may be the very person he was sent to kill, or may be the person doing the killing in place of his handlers. He knows only that he will find the face, that he will act, and that he will leave. The mask he wears is not a disguise. It is a job description.

At the masquerade, Aldric is patient. He moves through the gardens and the corridors, observing, cataloguing, testing the room the way a lock-picker tests a mechanism for the one pin that is slightly too tight. He is not looking for the party. He is looking for a face. The party may cross his path, may see him in the gardens by the fountain, and may not recognise the significance of a man who is watching the crowd with the focused stillness of a predator that has already decided it is not, in fact, a predator at all — only a very precise tool.
