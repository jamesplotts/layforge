---
id: nyx-the-changeling
location: mirror-antechamber
stat_block_ref: SRD Fey creature (use SRD Nymph base statistics; re-skin as a humanoid of indeterminate age with skin that faintly shifts in low light; add the ability to replicate one humanoid's physical appearance for 1 hour per long rest)
voice: soft, curious, slightly off — speaks as if testing words for the first time, occasionally using a name that does not belong to them
chapter: the-masks
---

Nyx does not have a body. Not in the way the party understands bodies. What they have is a shape that was borrowed, that fits imperfectly, that catches the light a half-beat wrong. In the Mirror Antechamber, where reflections lag and stutter, Nyx is at home. They move through the masquerade like a rumour, touching a stranger's hand as they pass, and for a moment the stranger's face is *theirs* — not copied, but *worn*, the way a glove is worn, with a faint pressure at the knuckles that is not quite the same as bone.

Nyx is not malicious. They are hungry, in a way that has no comfortable word. They have been shapeless for longer than they can remember, drifting between the veil and the waking world, and the act of taking a face is not theft — it is *home*. A face is a door. A face is a name that other people can say without spilling the vowels. Nyx wants a face the way a child wants a coat that is slightly too big: for the feeling of being *someone*, even if that someone was built for a different body.

At the masquerade, Nyx is attending because of the masks. A room full of people who have already hidden their faces is a room where one more hidden face will not be noticed. They are looking for the right face. Not the strongest, not the noblest. The right one. The one that, when they put it on, will make the world say *ah, yes, there you are* and leave them be. The party may find Nyx in the antechamber, staring into a mirror that does not reflect them back, their borrowed face flickering like a candle in a draft.
