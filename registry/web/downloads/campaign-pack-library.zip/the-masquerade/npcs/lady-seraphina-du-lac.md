---
id: lady-seraphina-du-lac
location: grand-ballroom
stat_block_ref: SRD Noble (use Commoner base with Noble social traits; add 1d4 hit points, proficiency in Persuasion and Insight)
voice: measured, warm, faintly amused — speaks as if delivering a well-crafted eulogy for a party that has not yet ended
chapter: the-masks
---

Lady Seraphina du Lac is the masquerade's host and its most visible mystery. She sits at the dais in a gown of deep silver, her own mask a simple white silk that covers the lower half of her face, so that only her eyes and the sharp line of her jaw are visible. She speaks to every guest with the same gentle, unhurried attention, as though each conversation is the only one happening in the room. She remembers names — the false ones — and uses them with a warmth that feels almost maternal, and almost rehearsed.

Her motivation is layered. She is genuinely charming, genuinely interested in the people around her, and genuinely dangerous in the way that a person can be when they have decided that a certain outcome is non-negotiable. She is not a villain in the traditional sense. She is a woman who has calculated, for a very long time, what must be done, and she is hosting a party to make it happen. Whether the party's purpose aligns with the party's guests, or works against them, is something the player characters will spend the evening discovering — if they survive to discover it at all.

She will help the party, and she will hinder the party, and she will do both with the same smile. The DM should resist the urge to make her either a clear ally or a clear antagonist. She is both, and neither, depending on what the party needs to hear.
