---
id: callowgate-square
connections:
  - mayors-hall
  - millstone-road
chapter: the-hire
---

Callowgate Square is the beating center of the town, a broad expanse of uneven flagstone ringed by two stories of timber-and-stone shopfronts. The air smells of tallow candles, damp wool, and the particular sweetness of overripe plums rotting in a barrel someone forgot to move. A fountain in the center has not run in months; its basin holds a skin of brown water and a dead heron.

The market here is modest but persistent. A fishmonger arranges his catch on a slab of blue stone. A weaver's apprentice winds thread on a frame set up outside the door. Children dart between the legs of cart-pullers. It is the face the town shows visitors: busy, slightly shabby, alive. But the shopkeepers' eyes track every stranger, and the conversations drop to whispers when a party of armed folk walks the central aisle. Two of the shopfronts on the east side are shuttered and locked, their signs unlit. No one talks about why.

A narrow lane leads north to the raised steps of Mayor's Hall, where a pair of crossbowmen lean against the doorframe with the particular boredom of paid soldiers. To the south, the flagstones give way to packed earth and then gravel—Millstone Road, where the trade carts come and go and, lately, where things go wrong.