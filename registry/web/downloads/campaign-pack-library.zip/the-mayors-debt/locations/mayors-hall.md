---
id: mayors-hall
connections:
  - callowgate-square
chapter: the-hire
---

Mayor's Hall sits on a low rise at the town's north end, a squat three-story building of grey stone with a flag above the door: a silver wheat sheaf on a green field, the town's emblem, slightly tarnished. The architecture is older than the town's current name, and the lower walls show the scars of a fire long put out. Inside, the corridors are wide, the floors oiled to a dark shine, and the windows look out over the rooftops in a way that makes the people below look small.

The Mayor's reception room is furnished for an impression of warmth rather than comfort: a long oak table, a pair of settees with faded velvet, a fireplace with a modest fire burning. Maps of the trade routes are pinned to one wall, their edges curling. A crystal decanter of something amber sits at the table's center, accompanied by small glasses. The room smells of beeswax and pipe smoke. On the desk, beneath the maps, a half-empty bottle of wine and a stack of unpaid bills are visible to anyone who looks where they shouldn't. The crossbowmen outside are pleasant if you are invited and less pleasant if you are not.

A locked door at the back of the corridor leads to the Mayor's private quarters, where the sound of a mechanical click—like a counting device, or a lockbox being cycled—can be heard faintly through the wood.