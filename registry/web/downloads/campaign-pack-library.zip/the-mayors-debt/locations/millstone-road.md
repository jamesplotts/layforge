---
id: millstone-road
connections:
  - callowgate-square
  - harrow-camp
chapter: the-hire
---

Millstone Road is the town's arterial trade route, a wide gravel path that curves south from the square's edge and then bends east along the river's outer bank. It is called Millstone because the first settlement here was a grinding mill, and the road has been worn to a smooth, hard surface by two hundred years of cart traffic. Both sides are lined with standing stones, lichen-covered, some carved with old merchant marks that no one in the current generation can read.

The road is quiet in a way that is not peaceful. Carts are missing. The tracks in the gravel show recent passage but no dust settles on the wheel-prints, meaning the traffic stopped days ago. A merchant's broken axle pokes out of a ditch half a mile south. At the bend where the road doubles back, the trees are thick and the sightlines short—a place where three people with bows could hold a column of six wagons. The grass here is trodden down in a small clearing, as though people have been sleeping in it for a night or two. There are no tracks leading further in. No tracks leading back out. Just the clearing, and the faint smell of woodsmoke, and a rusted lantern hanging from a low branch.

Further east, the road narrows between two banks and disappears into a stand of alders. Nothing moves in the trees. The river murmurs past, grey and fast.