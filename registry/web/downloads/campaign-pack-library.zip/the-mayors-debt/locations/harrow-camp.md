---
id: harrow-camp
connections:
  - millstone-road
chapter: the-hire
---

The camp sits in a natural bowl where the alders thicken and the riverbank drops to a muddy shore. It is not a camp in the military sense. There are no fortifications, no watchtower, no weapons racks. There are six or seven canvas tents, patched and stained, and a long low lean-to with a roof of salvaged boards. A single fire pit has been used repeatedly—the ash is black and deep. A hand-scraped plank nailed to a post reads, in uneven letters: NO MORE. We will not be starved for a man's pocket.

Inside the lean-to, a wooden table holds a sheaf of papers: tax notices, a ledger page torn from a book, a child's drawing of a house with a sun. A bowl of cold porridge sits on a crate beside a pair of boots. The tents, when opened, contain families. A woman mends a net. A boy of maybe nine watches the door with a fishing rod over his shoulder. An older man, clean-shaven and quiet, sits by the fire with a sheaf of documents spread across his knees, reading and re-reading the same paragraph.

There is no banditry here. There is no stolen goods, no weapon cache, no plan to burn the town. There is a group of people who stopped paying a tax they can no longer afford and set up a camp on the road because the road is the only thing the merchants still use, and they are not violent, and they are terrified, and they have been sleeping here for eleven days because there is nowhere else to go. The old man by the fire looks up when the party approaches. He does not reach for a weapon. He reaches for the papers.