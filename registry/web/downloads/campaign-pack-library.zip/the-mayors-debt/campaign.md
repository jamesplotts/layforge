---
id: iron-and-ash
title: "Iron and Ash: The Debt of Callowgate"
level_range: "3-8"
pvp_policy: pve_only
maturity_tier: standard
image_maturity_tier: family_friendly
shared_knowledge: strict
tone:
  - political
  - consequential
  - atmospheric
  - morally-complex
author: AI-generated
chapters:
  - id: the-hire
    title: The Hire
    level_range: "3-4"
    summary: "The party is recruited by Mayor Grimwood to drive 'bandits' off Callowgate's trade routes. The work seems straightforward—until the people they protect grow more frightened, and the 'bandits' they defeat look less like thieves and more like desperate neighbors."
  - id: the-real-problem
    title: The Real Problem
    level_range: "4-6"
    summary: "Beneath the banditry lies a deeper wound: the town's crushing debt to the Iron Consortium, siphoned by the Mayor into private coffers. As evidence mounts and the Consortium's agent Silas Reed arrives on the road with legal papers in hand, the party's employer becomes their antagonist."
  - id: the-confrontation
    title: The Confrontation
    level_range: "6-7"
    summary: "Grimwood's true plan is laid bare: the party was hired as a blade, and he intends to sever it. With Reed demanding the town's assets—people included—the party must negotiate, fight, or scheme across a room full of people who all want something different from them."
  - id: the-resolution
    title: The Resolution
    level_range: "7-8"
    summary: "The final choice reshapes Callowgate. Topple both the Mayor and the Consortium and watch the economy hemorrhage, expose the truth and let the townsfolk rebuild from rubble, or take Reed's cut and walk away rich. The town's fate bends to the party's values."
---

# Iron and Ash: The Debt of Callowgate

Callowgate is a trade town pressed between two rivers, its cobblestones worn smooth by centuries of cart wheels and its granaries stacked high with other people's grain. It is the kind of place that looks prosperous from the road and hollow from the inside. The party is drawn here by coin and a mayor's desperate tone, sent to solve a problem that should be simple: bandits on the trade roads, frightened merchants, a town that needs protecting.

What the party finds, session by session, is that their competence is the wound. Every cart they guard, every "bandit" they drive off the road, tightens a knot that was never theirs to pull. The townsfolk they rescue do not smile at them. The people they call criminals are the same people who bake bread in the market square the next morning. And the man who hired them is smiling the whole time, counting their success like a man tallying corpses.

The campaign's engine is guilt and correction. The party does not fight a dungeon; they fight a lie they helped tell. Each chapter raises the stakes of complicity—first a few bruised protesters, then a legal threat that can enslave the entire population, then a political knife-fight in a room where everyone has a dagger and everyone is pretending they don't. The Iron Consortium is not a villain army; it is a contract. Silas Reed does not cackle. He presents itemized invoices.

The tone is political thriller filtered through fantasy. There are no true villains with monologues. There are people who made bad choices and are now trying to survive the arithmetic. The party's power is real, but so is the debt, and so is the law, and the people in the market square who are too scared to thank them or to curse them.

## Hooks

- **The Contract:** A courier's rider gallops into Callowgate at dawn, bearing a sealed letter of introduction and a purse of silver that is far too heavy for a small-town job. The Mayor is waiting. He already has a map of the trade routes unrolled on his desk. He does not ask if the party is willing. He asks when they can start.

- **The Wrong Smile:** The party wins their first skirmish on Millstone Road and returns to the square expecting gratitude. Instead, a woman with a flour-dusted apron watches them pass, says nothing, and slams her shop shutter early. Old Man Hemlock, sitting on a crate of turnips, calls after them: "You're doing a fine job, lads. Now do tell me—what did you do to my neighbors?"

- **The Ledger:** Councilor Vance, cornered behind the grain exchange, presses a water-stained page into the party's hand. It is a debt schedule. The numbers do not add up. The shortfall is enormous. She looks up. "You were hired to protect this town, weren't you? Then look at what it actually owes. And look at who stopped paying."

- **The Collector's Caravan:** Smoke on the southern road. Not a single wagon—a column of them, iron-banded, painted with the Consortium's mark: a closed fist around a coin. The lead rider is not a soldier. He wears a long coat, carries a leather folio of legal instruments, and has already sent word to the town square. He is polite. He has forty-eight hours. He does not look as though he intends to wait forty-eight.