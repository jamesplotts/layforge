---
id: market-tension
location: callowgate-square
involves:
  - thaddeus-grimwood
  - elara-vance
chapter: the-hire
---

This is not a combat encounter. It is a scene that plays in the square the morning after the road-intercept, and it is where the party first feels the weight of what they did. The market is quieter than usual. Three of the stalls that were open yesterday are closed. The fishmonger is working, but he is not arranging his catch. He is standing behind his counter, arms crossed, watching the party with an expression that is not anger. It is recognition. He knows their faces now. They were in the tree line.

Mayor Grimwood is in the square, which is unusual. He has made a point of being visible, holding court on the fountain's edge, speaking to shopkeepers in a voice that is warm and low and slightly tired. He praises the party. He does not use their names. He says, "our friends from out of town," and his tone implies that the word "friends" is a gift. He mentions the road is safe. He mentions the merchant convoy. He does not mention the camp. He does not mention the boy in the mud. Councilor Vance is there too, standing at the edge of the crowd with her arms at her sides, not speaking, just watching. When Grimwood's hand comes to rest on the party leader's shoulder and he leans in to say something that is probably gracious and probably not, Vance steps forward. Her voice is quiet. It carries. "Your Honor, if I may. The tax notices for the south quarter are due Thursday. The granary is empty. I have the ledger." The square goes still. Grimwood's hand comes off the shoulder. He smiles. "Councilor, always so thorough. Perhaps after the merchants have arrived, we can discuss logistics over tea." The smile does not reach his eyes. Vance does not move. The party is standing between them, and the weight of the moment is a physical thing, a pressure behind the sternum, and the fishmonger finally breaks the silence by saying, to no one, to everyone, "The porridge was cold. The boy's porridge was cold and he didn't eat it."

This scene can go many ways. The party can back the Mayor, back Vance, or stand in the middle and say nothing, and the square will remember whichever they choose.