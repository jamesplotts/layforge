---
id: road-intercept
location: millstone-road
involves: []
chapter: the-hire
---

The party is sent to Millstone Road with a specific objective: clear the "bandits" from the tree line at the bend and secure the route for the next merchant convoy, scheduled to arrive in two days. The Mayor has given them a small map, a purse of coin for expenses, and a warning that the bandits are "hardened, well-armed, and likely desperate." He has not told them the number. He has not told them the names. He has told them to "handle it cleanly."

The encounter itself is straightforward by combat standards: a group of five to seven figures in the tree line, a short exchange of shouted words, and then the fight, which is quick and ugly and over before the birds in the alders stop screaming. But the aftermath is where the encounter becomes a problem. The "bandits" are not wearing masks. Their weapons, when dropped, are a pitchfork, a farming knife, and two crude bows with only three arrows between them. One of them is a woman the party will recognize from the market square. Another is the boy with the fishing rod. They do not fight hard. They fight to keep the party from burning the camp. When they are disarmed, the woman does not curse them. She asks, quietly, who told them to come. And the boy, when the dust settles, walks back toward the river and sits down in the mud and does not move.

The party has done what they were asked. The road is clear. The merchant convoy will arrive in two days. And the square will be quieter, and the two shuttered shopfronts on the east side will be one less, because the family who ran them just set up a camp in the alders, and now they are the bandits, and the party's hands are clean, and the town is smaller, and no one in the square meets their eyes when they walk back up the gravel.