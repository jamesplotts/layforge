---
id: camp-discovery
location: harrow-camp
involves:
  - old-hemlock
chapter: the-hire
---

The party finds the camp on their own, or they are sent back to check it, or they go because the boy in the mud told them the name of the river bend and they followed the water. The camp is as it looks from the road: tents, a lean-to, a fire pit, the hand-scraped plank that reads NO MORE. But up close, the details change the shape of the thing. The child's drawing. The cold porridge. The documents spread across the wooden table, which, when the party picks them up and reads them, are not bandit plans. They are tax notices. They are a letter from the town clerk acknowledging a payment that was never made. They are a list of names—families, households, the people whose shopfronts are shuttered, whose fields are fallow, whose children are not eating. And the list is long. And the names are the names of people the party saw in the square the day before, shaking their hands, buying their bread, thanking them for protecting the market.

Hemlock is there. He arrived sometime in the night and has been sitting by the fire for two hours, reading the same paragraph of the tax notice over and over. He does not introduce himself. He does not need to. The people in the camp know him. He sets down the paper. He looks at the party. He says, "You were hired to kill them. You should know that. He didn't say the word. He said 'handle it.' But that's what it was. And you did. And now there are fewer of them. And the road is clear. And the merchant convoy is coming. And the town is smaller. And I have watched all of it for eleven days and said nothing, and I am done saying nothing." He does not ask for forgiveness. He does not ask for help. He asks them to read the documents. All of them. He asks them to read the names. He asks them to go back to the square and remember the faces.

This encounter ends with the party holding a stack of papers that are, in the legal sense of the town, evidence of a crime they are not yet sure they understand. Hemlock does not leave. He stays by the fire. He does not fight. He does not need to. He is a witness, and a witness is harder to put down than a bandit, and the party knows it, and the knowledge changes the shape of the next time they walk into Mayor's Hall.