---
id: thaddeus-grimwood
location: mayors-hall
stat_block_ref: SRD Commoner
voice: "measured, paternal, with a thread of performative worry and a precision that betrays calculation"
chapter: the-hire
---

Thaddeus Grimwood is fifty-three, broad-shouldered, with close-cropped silver hair and a face that has been trained to look tired on behalf of other people. He dresses well for the town but not ostentatiously—good wool, a plain signet ring, boots that cost more than a laborer's monthly wage but are broken in and unadorned. He speaks in the cadence of a man who has rehearsed his concern until it sounds genuine, and he has been doing this for eleven years.

His motivation is not malice in the way a dungeon master's villain is. It is arithmetic. The Iron Consortium's debt is a number that, if paid, leaves Callowgate with nothing: no granaries, no mill, no market. He has been siphoning the tax revenue into a private reserve—not a treasury, a lifeboat. If the Consortium collects, he intends to be in the south with that reserve and the town's charter documents, and the town will be the problem the next mayor inherits. The party is a tool. The protesters are a threat to his ability to control the narrative. When the party's success threatens to outpace his plan, he does not rage. He simply adjusts the terms, lowers the tone, and watches their faces to see how much they have already invested.

He is not easy to fight. He is harder to argue with, because he is not wrong about the debt. He is only wrong about what he is allowed to do with other people's survival to solve it.