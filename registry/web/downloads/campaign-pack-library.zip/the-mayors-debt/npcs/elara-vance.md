---
id: elara-vance
location: callowgate-square
stat_block_ref: SRD Commoner
voice: "sharp, precise, quietly furious—she speaks in complete sentences and lets the silence do the work"
chapter: the-hire
---

Elara Vance is the youngest member of the town council, forty-one, with ink-stained fingers and a habit of standing very still when she is thinking, which makes her look like she is listening to something no one else can hear. She wears practical clothes, keeps her hair tied back with a strip of leather, and has a small scar on her left thumb from a paper cut she never let fully heal. She is in the square most mornings, not to sell anything, but to be near the people, to hear what they are saying before it reaches the council chamber.

Her frustration is a living thing. She has spent four years trying to pass reform, to open the books, to force a vote on the Consortium's terms. Each attempt has been blocked, delayed, or dissolved into committee. She does not have the votes. She does not have the money. What she has is a memory of what the town was before the debt, and a conviction that the current arrangement is not a crisis but a theft conducted at the speed of bureaucracy. She will help the party if it serves the truth. She will not help them if it serves the Mayor. The distinction is, in her experience, the only one that matters, and it is never as clear as it looks from the outside.

She is not brave in a dramatic sense. She is steady. She has made her peace with the possibility that she will lose, and that has made her harder to shake than a person who still expects to win.