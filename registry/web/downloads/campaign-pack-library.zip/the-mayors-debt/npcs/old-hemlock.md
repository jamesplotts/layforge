---
id: old-hemlock
location: callowgate-square
stat_block_ref: SRD Veteran
voice: "slow, deliberate, with the weight of old memories and a dry, unexpected humor"
chapter: the-hire
---

Hemlock does not use a surname. He is sixty-eight, thin, with a face like a knot in wood and hands that still move with the economy of a man who spent thirty years keeping his weight off his feet. He sits in the square most of the day, on a crate of turnips or a bench by the fountain, watching the market with the patient attention of a man who has seen the same scene repeat in four different towns and is no longer surprised by any of them. He was an adventurer once. The stories he tells about it are specific and small: the way the rain smelled in a particular valley, the sound a certain bridge made when it was about to let go. He does not talk about the big things. He does not need to. The people in the square know which of the stories are true because he tells them the same way he tells the false ones: flatly, without emphasis, as though the difference is not worth making.

He knows about the debt. He knew before the party arrived. He has known for two years, since the first tax notices stopped matching the granary counts, and he has said nothing because saying nothing was the only protection the square had, and because the people who would listen to him are the same people who would need him to be wrong. Now the party is here, and the bandits are their neighbors, and the Mayor is counting their kills like a man tallying a debt, and Hemlock finds that he has run out of reasons to sit on the crate and watch.

He will not fight for them. He is too old and his knees are bad in rain. But he will tell them where to look, what to read, and which doors in the town are locked for a reason and which are locked by a man who is afraid of what is behind them. He speaks in a low voice. He does not raise it. He does not need to. The people in the square have learned to listen.