---
id: undercroft
connections:
  - gilded-rat
  - nightshade-manor
chapter: the-plan
---

# The Undercroft

Three levels below a nondescript tannery in the Dye Market district, the Undercroft is Rafe's working safehouse. It doesn't look like much from the outside—a damp cellar with a single window above the waterline, smelling of lye and tanned leather. But the stairs descend further than the tannery owner knows, and below the first sub-basement is a proper workspace: a long planning table scarred with knife marks and chemical stains, a wall of pegs holding rope, wire, and small tools, a cot in one corner, and a locked strongbox in the other.

This is where the party will spend the evening before the heist. Rafe has laid out the vault schematics on the planning table—hand-drawn, detailed, showing three floors of Lady Nightshade's manor, guard rotations marked in colored ink, lock types annotated in a cramped shorthand. The plans are *good*. Better than the party would expect from a thief. They're also, as the night will reveal, incomplete. Several walls are marked as solid stone where they are actually hollow. A guard rotation is listed twice. The vault door mechanism is shown as a simple deadbolt lock. It is not.

The Undercroft is defensible but not heavily armed. There are two exits: the stairs up to the tannery, and a narrow drainage passage at the far end of the lowest level that opens onto a canal behind the Dye Market. Rafe has a lock on the drainage door. The key is on his person. He is not at the safehouse during the planning session. He sent the party here, gave them the materials, and left a note pinned to the table: *Sleep. You'll need the rest. I'll be where I need to be.*

The strongbox contains: a set of lock picks (fine, but not masterwork), a vial of alchemical ink that dries invisible for an hour, a small mirror on a flexible arm, a coil of silk cord, and a single folded note addressed to *"Whoever reads this: the vault is not what the plans show. Trust the walls. —M."* The note is in Mordecai's handwriting. Rafe put it there. Or Mordecai put it in the box and Rafe didn't know. The ambiguity is the point.