---
id: nightshade-manor
connections:
  - undercroft
chapter: the-plan
---

# Nightshade Manor

A sprawling estate on the hill above the city's western canal, built of pale grey stone that weathers to a soft blue in the evening light. The manor presents itself as a private residence of moderate wealth: three main floors, a garden, a small chapel wing, and a walled courtyard. The windows are tall and narrow, the shutters iron-banded, and the front gate is a six-foot iron arch that does not creak.

What the plans show: a two-story vault in the basement level, accessed through the chapel wing. Three guards on rotation. A deadbolt on the vault door. One alarm trigger on the outer wall. Straightforward.

What is actually there: the basement is five levels deep, not two. The vault is not a room but a *chamber*—circular, walled in black stone, with a door that has no visible lock because the lock is the wall itself, a mechanism of interlocking iron teeth that responds to a spoken word and a blood touch. The guards are nine, not three, and they rotate in a pattern that repeats only every six hours. The alarm system is not a single trigger but a web of thin silver wire strung through the manor's stonework, sensitive enough to detect a mouse's heartbeat from three rooms away. And the chapel wing is not a chapel. It is a *threshold*. The walls there are warm to the touch, and the air smells faintly of ozone, as if a storm is perpetually about to break.

Captain Moss is in the manor. She is not in the vault. She is in the east wing, in a study she has made into a command center, watching the wire network on a brass plate that lights and dims with every vibration. She knows someone is coming. She does not know *who*. She is patient, prepared, and—if the party makes a mistake—dangerous.

The manor's grounds are walled, but the wall is not solid stone. It is a living hedge, eight feet high, trimmed monthly, and rooted in soil that Moss has treated with a mild sleep-inducing compound. Climbing over it means falling into a drowsy, confused state for a minute or two. The front gate is locked but not trapped. The servants' entrance, through the kitchen, is unlocked. Moss left it that way on purpose. She wants them to come in. She wants to see what they do.