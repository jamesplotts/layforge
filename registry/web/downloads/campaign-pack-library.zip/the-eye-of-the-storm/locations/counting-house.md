---
id: counting-house
connections:
  - gilded-rat
  - undercroft
chapter: the-plan
---

# The Broker's Counting House

A room above a closed bookshop on Threadneedle Lane. The shop has been closed for three years, but the room above is lit, warm, and smells of old paper, cinnamon, and something faintly metallic, like the air after a lightning strike. The door has no lock. You knock three times, pause, and knock twice more. If you get it wrong, the door opens and Mordecai is already in the room, sitting at a desk covered in ledgers, looking at you with an expression of mild professional interest, as if you are a line item he is deciding whether to include.

Mordecai is not a thief. He is a *market*. He knows which locks use which pin configurations, which guards take which shifts, which noble has which secret, which vault holds which object, and which object is *not* what it appears to be. His ledgers are extensive, meticulous, and written in a cipher that shifts alphabet every six months. He does not sell goods. He sells *knowledge*, and his prices are denominated in whatever currency the buyer can afford. Gold is the smallest currency he accepts. Favors, secrets, and promises are the large ones.

He knows about the Eye of the Storm. He has a page on it. The page is short, and it does not use the word *gemstone*. He will tell the party what they ask, but he will frame every answer as a *transaction*. "You want the guard rotation? Fine. And in exchange, you'll tell me who else Rafe has recruited for the second phase. You'll see him do it. You'll report back." The party can refuse. The door is still there. But the information they lack will make the heist harder, and Mordecai will not apologize for that.

He is not evil. He is not good. He is a broker, and brokers serve the market, and the market right now is very, very interested in what is inside Nightshade Manor.