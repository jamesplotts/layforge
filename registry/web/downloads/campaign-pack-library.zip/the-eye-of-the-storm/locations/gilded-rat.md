---
id: gilded-rat
connections:
  - undercroft
  - counting-house
chapter: the-plan
---

# The Gilded Rat

A mid-tier tavern wedged between a chandler's shop and a retired duelist's apothecary in the city's Merchants' Row. The name is painted in tarnished leaf above the door; the interior is warmer than the name suggests, with low oak tables, a wall of hanging cured meats that doubles as a privacy screen, and a barkeep who asks no questions as long as you pay in coin.

The back room—separated from the main hall by a curtain of oiled canvas—is where Rafe does his recruiting. He arrives twenty minutes before the appointed hour, occupies the corner table nearest the second exit, and orders a drink he won't touch. When the party enters, he's already arranged a small stack of papers, a brass measuring tape, and a sealed envelope with a wax stamp they won't be allowed to open until after the job. The room smells of pipe smoke and the faintest trace of alchemical adhesive. He's been here longer than the others.

The tavern is a neutral space. Nobody here is bound to Rafe's crew, and the back room's acoustic insulation means a whispered conversation can be overheard from the main floor but not vice versa. If the party lingers too long or draws attention, the barkeep will politely remind them that the back room is reserved until the second bell. Outside, the street noise of Merchants' Row provides a constant murmur that makes eavesdropping from the sidewalk nearly impossible.

A useful detail: the tavern's cellar doubles as a wine storage, and the stairs down are visible from the back room. Rafe knows they're there. He hasn't mentioned them. Whether that's a warning, a test, or simply him being Rafe is up to the party to decide.