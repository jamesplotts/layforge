---
id: manor-approach
location: nightshade-manor
involves:
  - captain-moss
chapter: the-plan
---

# The Manor Approach

The party arrives at Nightshade Manor at dusk, when the grey stone turns blue and the shadows in the garden are long and still. The front gate is locked. The hedges are eight feet high and smell faintly of lavender and something sweeter, almost narcotic. The servants' entrance, through the kitchen, is unlocked. Moss left it that way. The front gate is the trap. The kitchen is the *invitation*.

If the party goes through the front gate, they trigger the first wire in the network. It is not an alarm. It is a *lock*. The gate seals, the hedges thicken, and the manor is now a closed system. If they go through the kitchen, they enter the east wing, where the first two guards are on duty. The guards are not hostile. They are *tired*. They are looking at the party with the expression of people who have been expecting a visitor and are slightly annoyed by the delay. One of them says, *"You'll want to go through the service corridor to the west. The captain is in the east. Don't make it harder than it has to be."* This is not a riddle. It is not a test. It is a guard who has been on rotation for eleven hours and wants the party to get out of his sight.

The first complication: the vault is not on the second basement floor. It is on the fifth. The plans show two levels. There are five. The party must descend, and the descent is where the manor starts to feel *wrong*. The walls are warm. The air smells of ozone. The stairs are older than the manor. The stone is older than the city. And on the third floor, in a room that is not on any plan, the party will find a door with no handle, no lock, and no keyhole. Behind the door, something is breathing. Slowly. Patiently. Waiting.

Moss is watching all of this on the brass plate. She sees the wires light. She sees the party descend. She does not intervene. She is watching. She is *learning*. And if the party reaches the fourth floor, she will be waiting at the top of the stairs, not with a weapon, but with a question: *"How far have you come?"* It is not a threat. It is a measurement. She is calculating how far the party has gotten and how much of the manor they have seen. And she is deciding, in real time, whether to let them reach the vault or to stop them now. The answer depends on how competent they have been. If they have been careful, she lets them go. If they have been loud, she stops them. Either way, she is *impressed*.