---
id: planning-session
location: undercroft
involves:
  - rafer-silvertongue
chapter: the-plan
---

# The Planning Session

The evening before the heist, the party is at the Undercroft. Rafe is not there. He left a note: *Sleep. You'll need the rest. I'll be where I need to be.* The plans are on the table. The tools are on the pegboard. The strongbox is in the corner. The party can spend the evening as they see fit: reviewing the plans, testing the tools, arguing about strategy, visiting the Gilded Rat for supplies, or going to Mordecai's Counting House for information.

If the party examines the plans carefully, several details are slightly off. The guard rotation is listed twice—once for the east corridor and once for the west, but the times overlap by forty minutes, which means either the guards are doubling up (impossible with three guards) or there are more guards than listed. The vault door is shown as a deadbolt, but the annotation in the margin, in a different ink, reads *"Simple. One key. R. verified."* The handwriting is Rafe's. The *verified* is in different letters, and it's underlined. If the party cross-references the manor layout with the wire alarm system Rafe mentioned, they will notice that the alarm coverage on the plans doesn't match the physical layout of the basement—the wire lines on the plan pass through *load-bearing walls* that, according to the structural annotations, should be solid stone. They are not solid stone. There are rooms there that are not on the plan.

If the party opens the strongbox, they find the tools and the note from Mordecai. The note is short: *"The vault is not what the plans show. Trust the walls. —M."* It is in a hand that is precise, small, and slightly slanted. If the party has met Mordecai, they will recognize it. If they haven't, they have a name to look up.

If the party goes to the Counting House during this session, Mordecai will sell them the true vault layout for a price. The price is: a promise to report back to him within a week of the heist, with details on what they found in the basement. He does not ask what they found in the *vault*. He asks about the *basement*. He wants to know if the extra rooms are still there. He wants to know if the walls are still warm. He wants to know if the Eye is still *growing*.

The session ends at midnight. The party is tired. The plans are in their minds. The tools are in their packs. Tomorrow, they go to the manor. And the manor is not what the plans say it is.