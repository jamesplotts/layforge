---
id: recruitment-pitch
location: gilded-rat
involves:
  - rafer-silvertongue
chapter: the-plan
---

# The Recruitment Pitch

The party arrives at the Gilded Rat at the appointed hour. The back room is set: a table, chairs, the plans laid out, a sealed envelope with a wax stamp, and Rafe himself, already seated, already smiling, already pouring a second glass of wine that he will not drink. He does not stand. He does not shake hands. He gestures to the chairs and says, *"Sit. You've done good work. I've heard. And I have a job that I think you'll find... honest."* He says the word *honest* the way a cat says *fish*.

The pitch is clean. Lady Vespera Nightshade has a vault in her manor. In the vault is an object called the Eye of the Storm. Rafe needs it recovered. The payment is 500 gold per member, paid on delivery. The plans on the table show three floors, three guards, a deadbolt vault door, and two exits. Rafe walks through the logistics with the confidence of a man who has done this before—and he has, he's just never done *this* one, the one where the vault is a cell and the gem is a god and the plan is a *lie*.

The party can ask questions. Rafe answers them all, and his answers are all *correct*. He knows the guard rotations. He knows the lock types. He knows the manor layout. What he doesn't know—what he *can't* know because he hasn't been inside the basement in four years—is that the layout has changed, that the guards are nine not three, that the vault door is not a deadbolt. His plans are accurate *for what the manor used to be*. The manor has changed. The Eye has been growing.

If the party accepts, the scene ends with Rafe sliding the sealed envelope across the table. *"Your share. Don't open it until you've delivered the Eye. And one more thing."* He leans forward, and his voice drops, and for a moment the charm thins and something colder is underneath. *"When you get to the vault, and the door is open, and you see the Eye—take it. Don't touch it. Don't look at it for longer than you need to. Just take it and walk. Do you understand?"* Then the charm is back, and he's smiling, and he's already standing to leave, and the party is alone with the plans and the wine and the faint smell of alchemical adhesive, and the sealed envelope is warm in their hands, and they don't yet know why.