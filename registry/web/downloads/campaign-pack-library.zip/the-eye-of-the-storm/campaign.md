---
id: the-storms-eye
title: The Storm's Eye
level_range: "3-8"
pvp_policy: pve_only
maturity_tier: standard
image_maturity_tier: family_friendly
shared_knowledge: strict
tone: [heist, clever, escalating-tension, betrayal, supernatural-danger]
author: AI-generated
chapters:
  - id: the-plan
    title: The Plan
    level_range: "3-4"
    summary: Silvertongue Rafe hires the party to steal the Eye of the Storm from Lady Vespera Nightshade's vault. They gather intel, prepare, and begin the infiltration—only to discover the vault's security is far more elaborate than Rafe's plans suggested.
  - id: the-complications
    title: The Complications
    level_range: "4-6"
    summary: The vault is a prison, not a treasury. Shadow Jax is already inside. Captain Moss locks everyone in. Rafe's true goal—releasing a bound entity—comes to light. The Eye speaks, and the heist becomes a question of survival.
  - id: truth-and-escape
    title: The Truth and the Escape
    level_range: "6-7"
    summary: With Rafe's agents closing in, the party must confront him, choose an ally or an enemy in Shadow Jax, and escape the manor with the sealed Eye before his next phase begins.
  - id: the-aftermath
    title: The Aftermath
    level_range: "7-8"
    summary: "Rafe's ritual accelerates across the region. The party faces the final choice: destroy the Eye, destroy Rafe, or face the demon he has set loose upon the world."
---

# The Storm's Eye

A charismatic thief offers a simple job: break into a noble's vault, take one gemstone, walk away rich. The plans are detailed, the payment is generous, and the target—Lady Vespera Nightshade—seems to be exactly the kind of corrupt magnate who deserves to be cleaned out. The heist begins cleanly. Then the walls start talking, the locks remember every hand that has touched them, and a rival with a knife in his smile is already three rooms ahead of you.

The Storm's Eye is not a treasure. It is a cage. And the man who hired you to steal it didn't want it sold in a market. He wanted it *opened*.

This is a four-chapter heist campaign built on escalating revelations. Each layer the party peels back makes the situation more dangerous and more morally complicated. The DM's job is to give them real tools, real information, and real consequences when things go sideways. The best sessions in this pack are the ones where the party's plan works *almost* perfectly—and that near-miss is what makes the catastrophe land.

## Hooks

- **The easy job.** Rafe's pitch is flawless. The payment is three times the rate for comparable work. The plans show every guard rotation, every lock type, every exit. For a party hungry for a clean score, this is the heist they've been waiting for.
- **The Broker's ledger.** Mordecai knows every vault, every lock, every secret in the region. He'll sell the party information they need—but his prices are never in gold alone. A favor. A secret. A name. What does *your* price look like?
- **The rival in the walls.** Shadow Jax doesn't announce himself. You notice his work: a lock picked so cleanly the pins are still cold, a guard who was supposed to be on the east corridor found unconscious on the west balcony. He's been here longer than you. And he's not here to sell the gem.
- **The vault that breathes.** Lady Nightshade didn't build a treasury. She built a *cell*. And whatever is inside it has been listening.
- **The employer's absence.** Rafe isn't at the manor during the heist. He says it's to keep his face out of the local constabulary's memory. He's somewhere else. Doing something you can't see. And when he reappears, he's *smiling*.