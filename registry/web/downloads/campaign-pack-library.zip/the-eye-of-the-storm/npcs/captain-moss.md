---
id: captain-moss
location: nightshade-manor
stat_block_ref: SRD Veteran
voice: Direct, economical, warm in a guarded way; speaks in present tense, short sentences, no filler
chapter: the-plan
---

Moss spent eleven years as a frontline adventurer before she came to work for Lady Nightshade. She has bled for causes that turned out to be lies, and she has killed for people who turned out to be worse than the monsters she fought. She does not trust. She *prepares*. The wire network in the manor's walls is her work. The guard rotations are her design. The sleep compound in the hedges is her idea. Every exit has a counter-exit. Every lock has a backup. Every assumption about what an intruder will do has a corresponding trap, and every trap has a backup.

In Chapter 1, Moss is not a villain. She is a professional doing her job. Lady Nightshade paid her to keep the vault secure, and Moss has taken that assignment more seriously than any employer has a right to expect. She does not know why the Eye is in the vault, or what it is. She knows Lady Nightshade has been sleeping poorly, that the vault temperature has been fluctuating, that three guards in six months have asked for transfer and all of them described the basement as *"wrong."* Moss does not sleep in the east wing. She sleeps in the command center, with a knife under her pillow and the brass plate on her lap.

If the party is caught, Moss does not gloat. She does not monologue. She says, *"I'm going to put you in the holding room. You're going to be comfortable. And in the morning, I'm going to ask you questions, and you're going to answer them, because I've already arranged for you to be very, very tired."* And she means it. She is not cruel. She is *efficient*. And that is, in a way, worse.