---
id: mordecai-broker
location: counting-house
stat_block_ref: SRD Expert
voice: Measured, precise, slightly tired; speaks in short declarative sentences and never uses exclamations
chapter: the-plan
---

Mordecai has been a broker for twenty-three years. He has never been caught, never been robbed, and never lost a transaction. His ledgers are the most complete record of illicit knowledge in the region, and he guards them with the same quiet ferocity a miser guards his gold—not because the information is valuable to him, but because *control* is the only currency that has never been devalued.

He does not hate Rafe. He does not like Rafe. He finds him *unprofitable*. A thief who plays long games, who builds networks, who trades in influence rather than coin—this is a market distortion, and Mordecai corrects distortions. He will help the party if the price is right, but his help is always *conditional*. He will give them the true vault layout in exchange for a name. He will give them the wire alarm frequency in exchange for a promise to report back. Every concession is a leverage point, and Mordecai remembers leverage points the way a spider remembers silk.

He knows what the Eye is. He has known for years. He has never gone to the manor himself. He watches, records, and waits. In Chapter 1, he is a resource: the party can visit him before or after the heist to buy information they need. The information is real, it is accurate, and it is always more expensive than they think they can afford.