---
id: rafer-silvertongue
location: gilded-rat
stat_block_ref: SRD Veteran
voice: Charming, warm, slightly too smooth; speaks in confident present tense as if outcomes are already settled
chapter: the-plan
---

Rafe presents himself as a career thief with a clean record and a taste for high-profile work. He is charming in the way that makes people forgive his flaws in advance: he remembers names, he tips generously, he laughs at his own jokes with genuine pleasure, and he makes the party feel like the smartest people in the room. He is also, in every consequential decision in this campaign, *wrong*. Or more precisely, he is right about what he wants and wrong about what anyone else needs, and he has structured the situation so that his want and their need point in the same direction—until they don't.

In Chapter 1, Rafe is genuinely excited. The heist is a job to him, a *good* job, the kind that makes him feel like the best version of himself. He has prepared obsessively. The plans are detailed, the payment is real, the logistics are solid. What he does not tell the party is that the plans are *designed* to be incomplete. He needs them to improvise, to get deep enough into the manor to reach the vault, to *open it*. He will not say this. He will not hint at it. He will stand in the Gilded Rat back room, spread his papers across the table, and say, with a grin that is almost sincere, *"It's simple. You break in, you take the Eye, you walk out. I handle the rest."* And he means it. He really does think it's simple. He just hasn't told them what *the rest* is.