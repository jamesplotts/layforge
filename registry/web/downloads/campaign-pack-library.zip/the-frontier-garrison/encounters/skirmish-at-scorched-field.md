---
id: skirmish-at-scorched-field
location: scorched-field
involves:
  - sergeant-kael
  - scout-yara
chapter: the-watchers-toll
---

The party is on a patrol—either escorting a supply cart to the bridge or running Yara's route forward when they come into the open at the eastern edge of Scorched Field. The field is empty. The dead oaks stand black against a grey sky. The boulder fields catch the light at an angle that makes the stones look like the backs of sleeping animals. Then the column comes out of the west: twenty to thirty Covenant skirmishers, moving in files of five, weapons low, shields up, moving at a pace that is not a run and not a walk but something in between, something rehearsed.

They are not attacking the fort. They are not attacking the party. They are moving. The question the party must answer, in the seconds before the column passes the boulder fields, is whether they are visible, whether they are noticed, and whether the skirmishers' purpose is to pass or to stop. Sergeant Kael is on the field, either ahead of the party or at its flank, and he will make the call to engage or to hide based on what he sees. If the party engages, the fight is short, loud, and ugly in the open, with the boulder fields as the only cover and the dead oaks as a kill zone the skirmishers know as well as the garrison does. If the party holds, the column passes, and the party has to decide what they have learned: how many, how fast, which direction, and whether the skirmishers carried anything that was not a weapon.

The skirmishers are not mindless. They are trained. They will not stand and fight a party they can outmaneuver. They will break contact, scatter into the boulder fields, and be gone before the garrison's horn is blown. The real cost is not the casualties. The cost is the time: every minute the party spends in the field is a minute the garrison's intelligence is wrong, and the garrison's intelligence is the only thing between the walls and the open ground.