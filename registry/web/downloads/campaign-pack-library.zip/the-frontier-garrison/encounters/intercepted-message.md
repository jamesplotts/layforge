---
id: intercepted-message
location: blackwater-creek
involves:
  - scout-yara
  - sergeant-kael
chapter: the-watchers-toll
---

The message is found in the creek, pinned under a flat stone at the edge of the ford, in a oilskin pouch that has been wet for two days. It is not a letter. It is a sequence of knots tied into a length of cord, in a cipher the garrison does not use but the Covenant does—a system of short and long knots that encodes numbers, and the numbers encode positions, dates, and quantities. The garrison's quartermaster can read the knots but not the cipher. The party can try to decode them, or they can bring the cord to Captain Dunne, who has seen this system before because she used to use it, because it was the garrison's own field cipher, the one she designed, the one that was supposed to have been retired when she was stripped of her eastern post.

The decoded message, if the party or the garrison cracks it, reads: *Three. South. Bridge. Full. Seven. West. Tower. Empty. Nine. Field. Clear. Ten. North. Pass. Held.* It is a status report. The Covenant is not marching. It is counting. It is counting the garrison's positions, its strengths, its gaps, and the gaps are exactly where Yara's sketches say they are. The message is three days old. The garrison is six days from the deadline. The party is standing in the creek, holding a cord that tells them the war is not coming. The war is already here. It is just counting the room to make sure it fits.