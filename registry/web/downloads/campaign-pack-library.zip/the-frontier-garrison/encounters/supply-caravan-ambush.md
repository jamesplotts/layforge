---
id: supply-caravan-ambush
location: blackwater-creek
involves:
  - captain-sera-dunne
  - sergeant-kael
chapter: the-watchers-toll
---

The grain caravan is four carts, two guard wagons, and eleven soldiers, moving from the river crossing to Fort Aldric along the south bank of Blackwater Creek. The route is the garrison's only reliable supply line, and it crosses the open stretch of creek bank where the trees thin and the boulders start. The convoy has made the run eleven times. On the twelfth, it does not make the run.

The ambush is not a battle. It is a sequence. A smoke signal from the tree line. A volley of arrows from the boulders upstream. A gap in the guard line that is not an accident but a gap that was planned, because the Covenant knows which soldier is on which wagon and which wagon is carrying the grain and which is carrying the arrows. The garrison's response is to send the party, if they are available, or to send a relief column that is smaller than the loss. The fight at the crossing is brief, confused, and wet. The creek is running high. The boulders are slick. The arrows are in the mud.

What the party finds after the smoke clears is not a pile of dead. It is a wagon with the grain gone, the arrows gone, the guard wagons empty but undamaged, and a note pinned to the driver's seat: *We do not want the grain. We want the road. Come to the south bank in three days and we will talk. Captain Voss.* The message is not a threat. It is an invitation. The garrison is being offered a choice, and the choice is framed so that refusal costs more than acceptance, and the party is standing in the creek with the mud up to their knees and three days on the clock and a note that says, in effect, *I have counted your room and it is not enough.*