---
id: sergeant-kael
location: fort-aldric
stat_block_ref: SRD Soldier
voice: blunt, practical, refers to everything as a logistics problem even when it is not
chapter: the-watchers-toll
---

Sergeant Kael has been in the garrison for six years, long enough to know where every wall has a weak joint, long enough to know which men are brave and which are only undisciplined, and long enough to have stopped expecting the quartermaster to have anything he asks for. He is broad, quiet, and carries a short sword he has owned for so long the pommel is worn to a smooth oval. He does not give speeches. He does not inspire. He makes sure the latrines are cleared before morning watch, the arrows are counted before the gate opens, and the men who are too drunk to stand are assigned to stable duty because the mule will not let a drunk near the feed.

He is not a villain. He is not a hero. He is the reason the garrison functions at all, and he is running out of reasons. The desertions started small—a man here, a man there, always to the north, always in the direction of the Covenant's camp. Kael knows the names. He does not punish them. He records the absence, adjusts the watch roster, and says nothing to Captain Dunne because he knows what the arithmetic will tell her and she does not need him to say it. He is the garrison's spine, and he is tired, and he is watching the door.