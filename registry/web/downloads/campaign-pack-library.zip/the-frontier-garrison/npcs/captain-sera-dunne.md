---
id: captain-sera-dunne
location: fort-aldric
stat_block_ref: SRD Veteran
voice: measured, clipped, speaks in sentences that end like orders even when they are questions
chapter: the-watchers-toll
---

Captain Sera Dunne has held Fort Aldric for nineteen months. Before that, she held a smaller post on the eastern river for two years, and before that, she was a lieutenant who wrote a tactical report on cavalry screening that was filed, acknowledged, and never read. She is not a hero. She is a professional who has been left with a problem she cannot solve with the tools she has been given, and she has learned, in the way that all professionals do, to stop pretending the problem will solve itself.

She is tall, lean, and moves through the courtyard like a woman checking a fence line: quick, economical, and looking for the gap. She speaks rarely and precisely, and when she does speak, she is not trying to be liked. She is trying to be understood, because understanding is the only thing that has ever kept her soldiers alive. She has a private doubt she does not say aloud: that the Covenant's plan is sound, that her defense is not, and that the arithmetic of the next three weeks will resolve the question in a way that will cost people she knows by name. She drinks the thin wine. She redraws the map. She gives the orders. She does not sleep well.