---
id: scout-yara
location: watchtower-nine
stat_block_ref: SRD Scout
voice: fast, detailed, tends to list three observations before the listener has finished asking one question
chapter: the-watchers-toll
---

Scout Yara is young, quick, and allergic to stillness. She has been on the forward watch for four months, longer than most, and she has mapped the western blind spot, the boulder fields in Scorched Field, the depth of the creek at the ford, and the exact number of dead oaks on the field's western edge (forty-three, she will tell you, and she will correct you if you say forty-two). She moves like water over stone: quiet, inevitable, and impossible to track once she has started.

Her last patrol was three days ago. She went forward to the tree line to check a signal fire she had seen burning on the ridge and she did not come back. Her pack was found at the base of the dead oaks, her boots gone, a single sketch pinned to a branch with a knife. The sketch shows a supply route from Blackwater Creek to a position the garrison has never identified. The knife is still in the branch. Yara is not in the pack. She is not in the field. She is, according to the only thing she left behind, somewhere the garrison has not looked yet, and the route she drew leads there.