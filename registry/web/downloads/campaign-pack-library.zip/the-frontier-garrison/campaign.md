---
id: iron-covenant-campaign
title: The Iron Covenant
tone:
  - military
  - gritty
  - tense
  - strategic
  - defensive
  - consequential
level_range: 2-6
pvp_policy: pve_only
maturity_tier: standard
image_maturity_tier: family_friendly
shared_knowledge: strict
author: AI-generated
chapters:
  - id: the-watchers-toll
    title: The Watcher's Toll
    level_range: 2-3
    summary: The PCs arrive at Fort Aldric, a crumbling frontier garrison short on men and supplies. They learn the Iron Covenant—a rebel force led by a former garrison commander—marches to take the Redridge Pass. A scouting mission, a skirmish in the open fields, and an intercepted message set the stage for the coming siege.
  - id: the-broken-line
    title: The Broken Line
    level_range: 3-4
    summary: The party infiltrates the Iron Covenant's forward camp beyond Blackwater Creek. They navigate the command tent, barracks, supply trains, and a hidden signal forge. Intel gathered here reveals the Covenant's true plan is not merely to take the pass but to split the garrison's remaining loyalties from within.
  - id: the-iron-march
    title: The Iron March
    level_range: 4-5
    summary: The Covenant's main force begins its advance. The party must hold a collapsing supply line, deal with a deserter-spy inside the fort, and choose between reinforcing the weakest wall or striking the enemy's flanking column before it reaches Redridge Pass.
  - id: the-commanders-gambit
    title: The Commander's Gambit
    level_range: 5-6
    summary: The final confrontation. The enemy commander, Voss, offers terms that are almost generous—because he believes surrender saves more lives than battle. The party must decide whether to fight, negotiate, or find a third path that neither side has considered.
---

# The Iron Covenant

The Redridge Pass has been a chokepoint for three centuries. Whoever holds it controls the trade between the river kingdoms to the south and the grain fields to the north. For the last two years, the garrison at Fort Aldric has held that pass with fewer than half the men it needs, patched-together supplies, and a morale so low that soldiers trade their rations for a night off watch. Then the Iron Covenant appeared—a disciplined, banner-bearing rebel army of former garrison defectors, dispossessed farmers, and mercenary companies—marching on the pass with the stated intent of "opening the road for the people."

Fort Aldric is not a fortress. It is a square of weathered stone walls around a command courtyard, a dozen barracks, an armory with more broken pikes than whole ones, a stable that smells of sawdust and old straw, and a granary that holds perhaps three weeks of grain. The command officer, Captain Sera Dunne, has held the post for nineteen months. She is competent, exhausted, and quietly terrified that the next census of her soldiers will yield a number she cannot bring herself to read aloud. The garrison's problems are not dramatic: they are arithmetic. Not enough men. Not enough arrows. Not enough time before the Covenant's vanguard reaches the tree line.

The Iron Covenant is not a ragged horde. It is organized, provisioned, and led by a former garrison captain—Voss—who was stripped of command eighteen months ago for refusing an order he considered a massacre. He did not go mad. He did not join a cult. He went to the farmers his garrison had taxed into starvation, offered them weapons and a cause, and built an army in four months. His plan is methodical, his intelligence sharp, and his offer of surrender genuinely believes it is the kindest outcome. That makes him, in many ways, the most dangerous adversary the party will face: you cannot outfight someone who is not trying to outfight you.

The campaign is structured as a military operation. The party does not wander a dungeon. They are assets in a campaign: on reconnaissance, on escort duty, on sabotage, on the line. Every mission has a tactical purpose, a timeline, and a cost. Failure does not mean "the party dies"; it means the wall is weaker when the real assault comes, the supply train is lost, the garrison's last reserve is spent. The world keeps moving whether or not the party is ready.

## Hooks

- **Draft notice.** The party has been conscripted or contracted to garrison duty at Fort Aldric for a minimum of two months. They arrive to find the post is understaffed, under-supplied, and being watched.
- **The deserter's letter.** A captured desertion letter from a Covenant sympathizer inside the fort reveals that the enemy knows the garrison's grain count. Someone is feeding the enemy information.
- **The scout's last report.** Scout Yara went forward to map the Covenant's camp and did not return. Her partially-finished sketch, found pinned to a dead tree at the edge of Scorched Field, shows a supply route the garrison's intelligence had never identified.
- **The quartermaster's plea.** Old Brenn has run out of arrow shafts. The nearest forge is behind enemy lines at Blackwater Creek. The party is sent to either retrieve a stockpile or escort a repair crew to a field forge before the next moon.