---
id: watchtower-nine
chapter: the-watchers-toll
connections:
  - redridge-pass
---

Watchtower Nine is the northernmost garrison position on the pass. It is a four-story stone tower with a watchhouse on the roof, a small armory on the second floor, a pantry and a cot on the third, and a latrine chute that empties into the scree below and has been the subject of at least one formal complaint from the garrison's quartermaster. The tower is garrisoned by two soldiers and a sergeant, though at the moment the sergeant is at Fort Aldric and the two soldiers are, in the parlance of the garrison, "on the tower," meaning they are up there, they are awake, and they are pretending the wind is not making the parapet stones rattle.

The view from the roof is excellent in every direction except the west, where a thicket of dead oaks and a shallow ravine block the line of sight to the Blackwater Creek ford. This is the blind spot. Scout Yara has sketched the blind spot on three separate maps and pinned each sketch to the tower's interior wall, each one slightly more detailed than the last, each one ending with a note in her cramped handwriting: *They will come through here. We cannot see them coming. We need a second post or we lose the pass before the horns are even blown.*

The tower is not defensible for long. It has no well, no granary, and a ladder that can be unclimbable within minutes if the base is taken. It is a lookout, not a fort. Its value is in the eyes it has, not the stone it stands on.