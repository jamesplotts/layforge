---
id: blackwater-creek
chapter: the-watchers-toll
connections:
  - fort-aldric
  - scorched-field
---

Blackwater Creek runs from the granite ridge to the south, cuts a narrow channel through Scorched Field's eastern edge, and empties into a sluggish river three miles beyond the garrison's walls. The water is dark, tannin-stained, and cold even in midsummer. The creek bed is wide, perhaps forty paces at the low-water mark, and the bottom is a tangle of flat stones and silt that slows a walking man to a shamble. The only practical crossing is a wooden footbridge near the garrison's eastern gate and a ford upstream where the water is perhaps knee-deep in summer and waist-deep in autumn.

The creek is the garrison's lifeline and its vulnerability in the same stroke. The grain comes down the river and is transferred to cart at the bridge. The water comes from a cistern that fills from the creek. The dead are buried on the south bank because the north bank is owned by the garrison and the south bank is not, and there is a thin line between a military necessity and a moral one that no one in the garrison has the stomach to articulate. Upstream, the creek narrows between boulders and runs fast and cold enough to stop a man's heartbeat, and on the far side of those boulders, if the sketches are to be believed, the Iron Covenant has established a signal forge and a supply staging area that no garrison patrol has ever reached.

The creek does not care about the campaign. It floods, it freezes, it carries silt that silts up the cistern and water that kills the horses that drink too much of it. It is the one thing in this campaign that is not trying to win. That makes it, in its way, the most dangerous element of all, because it will not pause for the party's convenience.