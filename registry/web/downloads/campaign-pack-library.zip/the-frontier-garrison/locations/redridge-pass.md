---
id: redridge-pass
chapter: the-watchers-toll
connections:
  - fort-aldric
  - watchtower-nine
  - scorched-field
---

Redridge Pass is a narrow corridor between two granite ridges, perhaps two hundred paces wide at its widest and barely sixty at the throat where the old toll gate stands. The gate is a ruin now—two stone pillars with a crossbar that has not been lowered in a year, rusted through to nothing. The road through the pass is packed gravel, rutted and washed out in three places, good for a cart in fair weather and little else.

The strategic value is obvious from either ridge: the pass is the only route over the granite that a wheeled convoy can manage in under a day. Everything that moves between the river kingdoms and the grain fields goes through here. If the Iron Covenant takes the pass, they do not merely hold a piece of rock. They hold the throat of every trade route in the region, and every farmer, merchant, and minor lord within a week's march becomes dependent on their goodwill.

The garrison has a single forward position on the pass: Watchtower Nine, a stone watchhouse with a crenellated roof and a ladder to the parapet. From the parapet, a sentry can see the tree line to the north and the open field to the south, but the western approach is blind—a blind spot that Captain Dunne has flagged on her map with a thick red circle that she has drawn, erased, and redrawn so many times the ink has soaked through to the back of the parchment.