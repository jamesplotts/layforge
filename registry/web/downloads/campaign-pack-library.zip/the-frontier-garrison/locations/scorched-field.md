---
id: scorched-field
chapter: the-watchers-toll
connections:
  - fort-aldric
  - redridge-pass
  - blackwater-creek
---

Scorched Field is a broad, shallow valley between Fort Aldric and Redridge Pass, roughly a mile long and half a mile wide. It is called Scorched Field because three years ago a garrison cook set fire to a dry brush pile to make a fire pit and the fire ran downhill into the wheat stubble and did not stop until it hit the creek bed. The field has not recovered. The soil is black and thin, and what grows there is a wiry, tasteless grass that the horses will eat and the men will not.

The field is open ground. There is no cover beyond the dead oaks on the western edge, a low stone wall that once marked a property line, and the occasional boulder field where the granite ridge has slumped into the valley floor. Any force that enters Scorched Field is visible for perhaps a quarter mile. Any force that enters Scorched Field is also, by the same token, exposed to archery from the garrison's walls and from Watchtower Nine if the approach is from the south.

It is, in the garrison's tactical assessment, a killing ground. That is the theory. In practice, the garrison does not have enough archers to make the theory true, and the last time a force entered the field—Covenant skirmishers, perhaps thirty strong, moving at dusk—they moved in columns of five, kept to the boulder fields, and were gone before the garrison's horn had finished its first note. The field is open ground. It is also the only place between the fort and the pass where the two sides can meet without one of them surrendering the advantage of stone.