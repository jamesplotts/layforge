---
id: fort-aldric
chapter: the-watchers-toll
connections:
  - redridge-pass
  - scorched-field
  - blackwater-creek
---

Fort Aldric sits on a low limestone shelf above the confluence of two dry creek beds. The walls are four feet thick and perhaps twenty feet high at the outer curtain, though the eastern face has settled unevenly after a winter frost and now leans enough that the sentries up top have been told to keep their shields ready in case a section gives way in a high wind. There is no moat. There is a ditch, and the ditch is dry, and the ditch is where the latrines are, so the whole eastern approach smells in a way that no amount of drilling discipline can explain away.

Inside the curtain, the courtyard is packed tight. The command building is a two-story stone structure with a raised portico where Captain Dunne holds morning reports and, in the evenings, drinks too much of the garrison's thin wine and stares at a map she has redrawn so many times the parchment is soft as cloth. The barracks are long, low rooms that sleep twelve to a man, bunks stacked in tiers. The armory is a locked stone shed where the quartermaster's assistant counts bolts three times before they leave for the wall. The stables hold nine horses, three of which are old, and a mule that the garrison calls Sergeant Kael's "logistics officer" and that has never once been useful.

The fort is not beautiful. It is functional. Every surface is marked: a tally of days held, a scorch from a cooking fire that went wrong, a chisel mark where someone carved a name into the stone because the name is all that person has left. The garrison's entire identity is this square of rock and the men and women who stand on it. When the Covenant comes, there is nowhere to go. That is the point. That is the problem.