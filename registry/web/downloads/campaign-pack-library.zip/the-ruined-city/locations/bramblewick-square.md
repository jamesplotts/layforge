---
id: bramblewick-square
connections:
  - bramblewick-hall
  - the-ashen-road
chapter: the-fallen-gate
---

Bramblewick is a modest frontier settlement of perhaps two hundred souls, huddled in a river valley where the fertile lowlands end and the Ashen Marches begin. The town's heart is a broad square paved with river-stones, around which cluster a handful of timber-and-stone buildings: a chandler's shop, a blacksmith's forge perpetually wreathed in woodsmoke, a modest tavern called the Creaking Bell, and the broad stone facade of the Town Hall.

The square is always busy. Scavengers hawk salvaged iron and tanned hides. Children dart between the legs of mules laden with timber. The Guild of Salvagers maintains a posting board where contracts are nailed and renegotiated in loud, overlapping voices. The air smells of roasting fat, wet wool, and the faint metallic tang of the river.

It is a safe place, a warm place — which makes the shadows that stretch east toward the Ashen Marches feel all the longer, all the more tempting. Every resident of Bramblewick knows the ruins are there. Every resident who has looked too long at the broken skyline of Calandris on a clear evening has felt the pull of it, the sense of a song half-remembered. The square is where the party begins: where commissions are accepted, rumors traded, and the road east first laid out on a scratched-up map.