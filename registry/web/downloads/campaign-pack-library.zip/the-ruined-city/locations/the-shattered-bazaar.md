---
id: the-shattered-bazaar
connections:
  - the-fallen-gate
chapter: the-fallen-gate
---
The Shattered Bazaar occupies the first full district within Calandris's walls: a broad, semi-circular market hall that once housed hundreds of vendors selling everything from woven silk to enchanted steel. The great arched roof that covered the market has collapsed in three great sections, leaving the interior a chaotic landscape of broken columns, shattered display cases, and floors of crushed marble and iron shelving. Shafts of light pierce the gaps in the roof, illuminating drifting dust in slow, golden columns.

The bazaar is a scavenger's paradise and a hazard field. Broken weapons of unusual make lie scattered under rubble: swords with blades that still hum faintly, maces whose heads are fused to their hafts in patterns that suggest deliberate enchantment. Display cases — shattered, of course — hold reagent vials, half-finished golems' parts, and sealed scrolls in languages the party may not recognize. Beneath the floor, accessible through a collapsed section of the central aisle, lies a narrow undercroft where the Guild of Salvagers has already made a camp: canvas, lanterns, a small forge, and the smell of cold stew. They are here. They are watching.

The deeper bazaar — the far end, where the columns are thicker and the Dissonance hum is strongest — is where the first true dangers reside. Skeletons in the rusted armor of Calandris's city guard still stand in their posts, their empty sockets tracking movement with a patience that feels almost *curious*. They are not aggressive. They are waiting. The party must decide: take what is visible and leave, or go deeper, into the hum, into the dark, where the treasure is better and the teeth are sharper.