---
id: bramblewick-hall
connections:
  - bramblewick-square
chapter: the-fallen-gate
---

The Town Hall of Bramblewick is a squat two-story building of river-stone and rough-hewn pine, its gabled roof patched so many times it resembles a quilt of mismatched shingles. Inside, a single long room serves as council chamber, meeting hall, and — on slow evenings — a place for the town to gather and drink. A long oak table dominates the space, surrounded by mismatched chairs. Maps of the Ashen Marches are pinned to the walls, their edges curling.

Elder Marisa presides from the head of the table, her posture straight despite her age. She is the town's elected leader and its most pragmatic voice: she will not order the party into the ruins, but she will make certain they know what the other factions want, what the old maps say, and which roads are safe. Behind her, on a shelf of dried herbs and sealed letters, sit the town's records — thin, mostly agricultural, but including one heavily annotated journal left behind by a scholar who entered Calandris forty years ago and never returned.

The Order of the Silent Bell maintains a small alcove at the rear of the hall, where Priest Cadran keeps a private study of texts and prayer beads. It is here that political intrigue is conducted in low voices, where contracts are quietly brokered, and where the party might learn that the town's safety depends, in small ways, on keeping the ruins from being *fully* plundered. The Hall is neutral ground. No faction fights within its walls. For now.