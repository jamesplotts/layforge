---
id: the-ashen-road
connections:
  - bramblewick-square
  - the-fallen-gate
chapter: the-fallen-gate
---
The Ashen Road is a two-day footpath from Bramblewick to the outer wall of Calandris, though in practice the first day is easy and the second is not. The road begins as a packed-gravel track running through a broad meadow dotted with grazing goats and low stone farmsteads. By the halfway mark, the meadow gives way to the Ashen Marches: a stretch of scrubland where the soil is grey and thin, where the grass grows in sparse, brittle tufts, and where the wind carries a faint, persistent hum that none of the locals can explain.

The last mile is the worst. The road narrows to a single-track path between two rows of dead oaks, their branches twisted as if frozen mid-reach. The hum grows louder. Shadows between the trees do not quite match the light. Salvagers' camps are visible from the ridge above — tin tents, cooking fires, the clink of metal on metal as they strip whatever they can from the surface ruins. A few armed men watch the road. They are not friendly, but they are not yet hostile. They are watching.

The road ends at a shallow depression where the earth drops away and the grey stones of Calandris's outer wall rise, broken and jagged, catching the last of the afternoon sun. The Fallen Gate stands at the depression's lip, half-collapsed, its iron portcullis rusted to a lattice of orange threads. Beyond it, the city waits.