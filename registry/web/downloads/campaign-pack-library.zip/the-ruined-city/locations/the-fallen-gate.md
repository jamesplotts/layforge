---
id: the-fallen-gate
connections:
  - the-ashen-road
  - the-shattered-bazaar
chapter: the-fallen-gate
---
The Fallen Gate is what remains of Calandris's primary entrance: a triple-arched portal of pale limestone, each arch originally thirty feet tall, now broken at the top and leaning inward at precarious angles. The central arch is the only one still passable, and even it is narrowed by a collapsed section of the upper wall that spilled inward like spilled grain. The iron portcullis hangs in a broken web across the arch, its links rusted through but still heavy enough to impede a large creature or a fast-moving party.

The gate is flanked by two watch-towers, their upper stories gone, their lower levels converted into crude shelters by the scavenger packs that camp here. A dozen goblins — small, sharp-eyed, speaking a clipped pidgin — run the day-to-day: collecting a "gate-fee" from anyone who passes, trading stolen trinkets, and warning each other when the shadows move wrong. They are not a military threat. They are a nuisance, a tax, and a first test of how the party handles a small, petty, *living* danger before the real ones begin.

Beyond the gate, a wide boulevard — once lined with merchant stalls and triumphal statues — stretches into the city's first district. The stones are cracked and heaved by two centuries of root-growth and the slow pulse of the Dissonance. In the distance, the broken silhouettes of larger structures rise against the sky. The hum is constant here. It is in the bones.