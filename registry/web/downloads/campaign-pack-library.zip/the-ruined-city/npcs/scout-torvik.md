---
id: scout-torvik
location: bramblewick-square
stat_block_ref: SRD Veteran
voice: Terse, colloquial, speaks in fragments; finishes other people's sentences
chapter: the-fallen-gate
---

Torvik has walked the Ashen Road forty-one times. She can tell you which goat herds will spook at the third mile, which section of the dead-oak stretch has soft ground after rain, and which of the goblin scavengers at the gate are selling genuine reagents and which are selling powdered chalk in a glass vial. She is lean, quick, and smells of linseed oil and old sweat. Her gear is practical: a short sword, a sling, a pouch of flint, a half-eaten apple she has carried for three days and is not yet ready to discard.

She is not a soldier. She is a *reader* of the road. She will guide the party through the Ashen Marches if they ask, and she will warn them — bluntly, without romance — about what they will find at the gate and in the bazaar. She has seen the skeletons. She has seen the goblins. She has not seen what is deeper, and she does not intend to. Her one rule: she will not follow a party past the Fallen Gate. She will wait at the treeline, count their heads, and if a head is missing, she will come looking. She is not brave. She is *useful*, and she knows the difference.