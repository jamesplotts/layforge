---
id: elder-marisa
location: bramblewick-hall
stat_block_ref: SRD Commoner (roleplayer; no combat statistics)
voice: Measured, dry, with a faint legalist's habit of qualifying every statement
chapter: the-fallen-gate
---

Elder Marisa is sixty-three years old and has held the Bramblewick council seat for eleven of those years. She is small, grey-haired, and wears her authority the way other people wear heavy coats: a little reluctantly, and always aware of the weight. She speaks carefully, choosing words the way a surgeon chooses a blade — not with flair, but with the understanding that a slip can bleed someone.

Her motivation is pragmatic. Bramblewick's safety depends on the ruins remaining a *managed* danger. If the Salvagers strip the outer districts clean, the wraiths move outward. If the Cartel seizes the gate, the town loses its buffer and its market. She will fund a party's expedition, provide maps and a measure of political cover, and expect a report in return. She is not a hero. She is a steward. She will remind the party, gently but firmly, that the town cannot replace them if they do not come back. She keeps the old scholar's journal in a locked drawer. She has not told anyone what it says, because she is not certain she wants to.