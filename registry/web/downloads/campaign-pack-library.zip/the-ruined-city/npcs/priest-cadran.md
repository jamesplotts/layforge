---
id: priest-cadran
location: bramblewick-hall
stat_block_ref: SRD Priest (1st-level Cleric equivalent)
voice: Soft-spoken, deliberate, uses archaic phrasing; pauses to consider before answering
chapter: the-fallen-gate
---

Priest Cadran is a member of the Order of the Silent Bell, a small scholarly-religious congregation dedicated to the study and containment of uncontrolled magical phenomena. He is young — perhaps twenty-eight — with a scholar's stoop, a monk's patience, and the particular stillness of someone who has spent more time listening to the hum of the Dissonance than speaking to other people. He wears the Order's plain grey robes without insignia, as if the insignia would make the belief feel smaller.

He is in Bramblewick because the Order's archives indicate that the upper districts of Calandris contain a text — the Codex of Harmonic Law — that may describe a method to *reverse* the Dissonance, to heal the wound at the city's core. He cannot go himself; his order is small, and he is the only one with the theological grounding to recognize the Codex if he found it. He needs the party to go deeper than Ysara, deeper than the Cartel, deeper than the goblins and the skeletons, into the Echoing Halls where the wraiths walk. He will offer knowledge, not coin: a ward-stone that protects against a single wraith attack, a fragment of a map of the upper districts, and a warning that the wraiths are not evil — they are *grieving*, and grief, he believes, can be addressed differently than malice. He is not a warrior. He is a question wearing a robe, and he will ask the party the right questions at the wrong moments.