---
id: merchant-ysara
location: bramblewick-square
stat_block_ref: SRD Commoner (roleplayer; minor combat stats if pressed)
voice: Warm, rapid, persuasive; uses diminutives and touches your arm when making a point
chapter: the-fallen-gate
---

Ysara runs the largest salvage operation in Bramblewick. Her stall in the square is a riot of tagged trinkets, polished bone, and small weapons displayed on a rotating rack that she winds every morning. She is perhaps forty, broad-shouldered, with ink-stained fingers and a smile that never quite reaches her eyes. She speaks quickly, laughs easily, and will absolutely, categorically, under no circumstances overcharge you. She will also absolutely, categorically, under no circumstances tell you what she actually needs from inside the ruins, what the Guild's real contract says, or why she is so *conveniently* hiring a party for a retrieval that she could have sent her own people to do.

Her motivation is layered. On the surface: profit, pride, the thrill of the hunt. Beneath that: a debt. The Guild of Salvagers owes a considerable sum to the Crimson Cartel, and the Cartel's patience is running out. Ysara needs a specific reagent — a vial of crystallized Dissonance, harvested from the bazaar's deeper levels — to settle the account. She does not know that the vial, if brought to the Cartel, will be used as a key to the Fallen Gate's failsafe mechanism. She is a good person doing a bad thing because the alternative is worse. She will try to recruit the party with warmth and coin. If they accept, she will be their patron, their guide, and — if they ask the wrong questions — a very awkward silence.