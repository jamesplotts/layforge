---
id: ruins-of-calandris
title: The Ruins of Calandris
level_range: "2-8"
pvp_policy: pve_only
maturity_tier: standard
image_maturity_tier: family_friendly
shared_knowledge: strict
tone:
  - dark
  - mysterious
  - exploratory
  - political
  - melancholic
author: AI-generated
chapters:
  - id: the-fallen-gate
    title: The Fallen Gate
    level_range: "2-3"
    summary: The party travels from the frontier town of Bramblewick to the outer walls of Calandris, facing road ambushes, environmental hazards, and rival faction agents before breaching the shattered bazaar district and claiming their first spoils.
  - id: the-echoing-halls
    title: The Echoing Halls
    level_range: "4-5"
    summary: Deeper into the upper districts, the party explores palaces and temples haunted by hollow wraiths, solving puzzles tied to Calandris's golden age while navigating the competing claims of three factions vying for the ruins.
  - id: the-drowned-quarters
    title: The Drowned Quarters
    level_range: "6-7"
    summary: In the flooded slums and underground cisterns, the party uncovers the true history of Calandris's fall and confronts a wight lord who has made the dark places his frozen kingdom.
  - id: the-resonance-throne
    title: The Resonance Throne
    level_range: "8"
    summary: At the city's heart, the party faces the High Archon — a lich who has been slowly devouring the Resonance Engine — and must decide whether to destroy, claim, or free the power that once made Calandris the jewel of the realm.
---

## Overview

Two centuries ago, the city of Calandris was the most powerful arcane civilization on the continent. Built around the Resonance Engine — a vast crystalline mechanism that drew raw magical energy from the ley-lines beneath the earth — Calandris hummed with perpetual enchantment. Its towers sang in harmony with the sky, its markets glowed with self-forged light, and its people lived in a golden age that other nations could only envy.

Then the High Archon, Vaelthryn Sol, attempted a ritual to sever the Engine's connection to the natural world and claim its power solely for the ruling council. The backlash was catastrophic. A wave of anti-magic — the Dissonance — rippled outward from the Engine's core, shattering every ward, dissolving every spell, and twisting the city's noble class into hollow, echoing wraiths bound to their estates. The common people fled downward into the cisterns and cellars. Those who could not escape perished. The city fell in a single night of grinding, singing collapse.

Now, two hundred years later, the ruins of Calandris stand as a half-buried labyrinth of broken marble, twisted iron, and slow-creeping silence. The Dissonance still radiates from the heart of the city, a zone where magic sputters and dies. Beyond that zone, the ruins are a treasure trove: broken weapons of unmatched craftsmanship, hidden caches of reagents and rare metals, and lore that could reshape the magical understanding of the age. Three factions compete for control — the Guild of Salvagers, the Order of the Silent Bell, and the Crimson Cartel — and the path into the city is treacherous, guarded by scavenger packs, collapsing architecture, and the wandering echoes of the dead.

## Hooks

**The Salvager's Commission.** The Guild of Salvagers in Bramblewick will pay handsomely for a party willing to enter Calandris's outer walls, retrieve a specific cache of reagents, and return before the next full moon. The payment is generous. The contract does not mention the wraiths.

**The Scholar's Petition.** A priest of the Order of the Silent Bell has spent a decade studying the Dissonance and believes the upper districts contain a text that could neutralize its spread. They need a party strong enough to walk the Echoing Halls and retrieve the Codex of Harmonic Law.

**The Cartel's Challenge.** A Crimson Cartel captain has posted a bounty on the ruins' gate key — not to claim the gate, but to ensure no rival can. The party is offered the sum in exchange for either retrieving or destroying the key. They do not yet know the key also serves as a failsafe for the Resonance Engine.

**The Wandering Echo.** A half-mad survivor from Calandris's lower quarters has appeared at Bramblewick's gates, babbling in a dead language. She speaks of "the one who sits in the singing dark" and begs the party to put the city to rest. No one in town believes her. The party may.