---
id: the-ambush-on-the-ashen-road
location: the-ashen-road
involves:
  - scout-torvik
chapter: the-fallen-gate
---

On the second day of travel, in the stretch of dead oaks where the road narrows and the hum grows audible, the party is ambushed by a band of six goblins (SRD Goblin) and two half-orc scavengers (SRD Half-Orc) operating out of a hollowed trunk. They are not soldiers. They are *thieves* with a grudge: a Salvagers' supply mule was driven through their stretch of road last week, and they are taking it out on anyone who passes.

The ambush is crude: a tripwire of braided vine snaps under the lead traveler's boot, goblins pour from the tree line with crude bows and rusted short-swords, and the half-orcs try to cut off retreat by rolling a boulder across the road behind the party. The combat is short and ugly — the goblins fight with a frenzy born of hunger and smallness, and the half-orcs are strong but undisciplined.

If Scout Torvik is present and the party accepted her guidance, she will have called the ambush before the first arrow flies, giving the party a free action to take cover. If the party is traveling without her, the first round is a surprise round, and the lead traveler takes a goblin bow-shot to the shoulder before drawing steel.

Aftermath: the goblins' hideout is a single hollow tree, stripped of anything of value except a pouch of 12 gold pieces, a broken compass that still faintly points toward Calandris rather than north, and a crude map scratched into bark showing the Fallen Gate and the bazaar beyond. The half-orcs, if spared, will mutter that the goblins are "gate-rats" and that the real trouble is in the bazaar. One of them knows that the Salvagers' people are already inside. This is the first thread the party can pull.