---
id: the-gate-of-ashes
location: the-fallen-gate
involves:
  - merchant-ysara
chapter: the-fallen-gate
---

The Fallen Gate is held by a loose collective of goblins — twenty in total, spread across the two watch-towers and the archway itself — who have established a crude toll system: five silver pieces per person, or a useful item, or a "favors" in which the goblins will open a side-tunnel behind the gate that leads around the main arch (a shortcut that saves a day of travel but drops the party directly into the Shattered Bazaar without the option to scout). The goblins' leader, a large creature called Rust-Tooth, speaks a broken pidgin and is more interested in collecting shiny things than in actual security.

The complication: Merchant Ysara is already at the gate. She arrived two days ago with a Salvagers' party of four armed guards, and she has been *negotiating*. The goblins are suspicious of her, she is irritated by them, and the atmosphere is a low hum of tension. Ysara will approach the party with a smile and an offer: join her Salvagers' group in passing through the gate in exchange for a share of the bazaar's treasure. The goblins will be less cooperative if the party is perceived as a threat to Ysara's negotiation, and Rust-Tooth will grow testy if too many people pass without payment.

The environmental hazard: the central arch's upper section is unstable. A DC 13 Perception check reveals hairline fractures in the lintel. A loud noise (a spell, a shouted command, a goblin's panicked shriek) or a DC 12 Strength (Athletics) check to force the broken portcullis will trigger a partial collapse: a 10-foot section of the arch crumbles, dealing 4d6 bludgeoning damage to anyone in a 10-foot radius and burying the central passage under rubble that takes 30 minutes to clear. The side-tunnel remains passable. The goblins, if the arch collapses on them, will scatter — and the party will have the gate, the bazaar, and Ysara's irritated Salvagers all in the same confined space.

Treasure at the gate: beneath the watch-tower foundations, a sealed iron chest contains 85 gold pieces, a broken longsword of fine make (the blade is shattered at the middle, but the crossguard is intact and worth 25 gp as a relic), and a small vial of blue luminescent liquid labeled in a hand the party may not recognize. The vial is a sample of crystallized Dissonance. Ysara will recognize it. She will not explain what it is. Not yet.