---
id: scholar-aldous-voss
location: the-scholars-annex
stat_block_ref: "SRD Commoner"
voice: "Fast, self-correcting, slightly breathless; talks over himself; when he is certain, he goes quiet and his hands stop moving, and that silence is more frightening than the talking"
chapter: ch-1-waters-rising
---

Aldous Voss has spent four years in the annex mapping the underground river, cross-referencing the gatehouse glyphs, and reading the ritual text in the old dialect that the gatehouse carvings were written in. He is not a mystic. He is a philologist who stumbled into the wrong basement and found a spell that works. He has verified it twice. He has not performed it. The reason is in the margin note, the one he added three days ago and cannot stop rereading: the ritual requires a living component, and the text is ambiguous about whether that component must be the caster or the subject, and Voss has decided, in the quiet hours when the town is asleep, that the ambiguity does not matter because he will be the one to step forward and no one else will have to.

He is afraid. Not of the ritual. Of being the reason it is attempted, because if it fails, he is the one who proposed it, and the party will look at him, and the town will look at him, and the children will still be in the mine, and the village will still be in the water, and he will have been the one who said *there is a third way* and the third way will have cost everything. He will offer the party the choice. He will not make them choose him. He will simply say, *The cabinet is unlocked. The text is on the desk. I am here if you need me, and I will not stop you, and I will not take it back when you ask, because I know what it costs and I have already decided what it costs me.* That is the most honest thing anyone in Thornfield has said in weeks, and it is also the most dangerous, because it is true, and truth in a crisis is a blade that cuts the hand that holds it.