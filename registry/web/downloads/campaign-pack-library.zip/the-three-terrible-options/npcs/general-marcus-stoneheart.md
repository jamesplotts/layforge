---
id: general-marcus-stoneheart
location: oakhaven-bridge
stat_block_ref: "SRD Veteran"
voice: "Brisk, clipped, declarative; speaks in military cadence even in conversation; uses the word 'operation' for things that are not operations; his humor is dry and appears as a half-sentence he does not finish"
chapter: ch-1-waters-rising
---

Marcus Stoneheart is a career soldier who has commanded campaigns in three provinces and who has never, in his own accounting, lost a civilian he was supposed to protect. The villagers of Oakhaven are, in his mind, a calculation: their loss is a variable, their grief is a consequence to be managed, and the glory of a successful flood-redirect is a legacy that will outlast any single village. He is not wrong that the water must go somewhere. He is not wrong that a controlled redirect is the most predictable, most survivable option. He is wrong, or at least incomplete, about what he is willing to spend, and the thing he is not willing to spend is the story. He wants the campaign to be remembered as a victory. He wants his name in the regional chronicle. He wants the soldiers to come home with medals and the village to be a footnote. The party should see this. The party should be able to name it. And the party should understand that his option is not evil, only incomplete, and that incompleteness is where the civilians get buried.

He will offer the party a position in the operation. He will brief them as equals, because he respects competence and he does not respect sentiment. If the party chooses his option, he will execute it cleanly and efficiently and the village will be gone in a night, and he will stand on the bridge and watch the water take it, and his face will be steady, and that steadiness is the part that will haunt the party longest.