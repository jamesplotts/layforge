---
id: high-priestess-mirabel
location: the-rusted-gatehouse
stat_block_ref: "SRD Commoner"
voice: "Measured, resonant, warm; she speaks as if each word is a small act of devotion; when pressed, her warmth hardens without any change in volume, and her sentences become shorter and more absolute"
chapter: ch-1-waters-rising
---

Mirabel is not a fanatic. That is the thing about her that makes her dangerous. She has read the texts, she has walked the tunnels, she has held the hands of the dying and sung the last rites and felt the particular, quiet certainty of a woman who has done this work for thirty years and who believes, with the full weight of her experience, that the gods sometimes ask for small payments to prevent large ones. The children in the mine are not, in her theology, collateral. They are chosen. The seal will hold because their lives are the key, and the key was always meant to be used, and to refuse to turn it is to refuse the gods and to doom everyone else. She will not raise her voice. She will not threaten. She will look at the party with steady, tired eyes and say, *I will do it myself if no one else will, and I will not ask you to watch, and I will not ask you to forgive me afterward, because there is no one to ask.*

Her manipulation is not loud. It is structural. She has positioned herself as the one who will bear the act, which makes her the one who controls the framing of it. She has her choir singing the rite in the gatehouse alcove every evening, so the sound is in the town's ears before the party has finished their deliberation. She has left the trapdoor in the altar floor unlocked, so the path to the mine is always open, always visible, always an option. She is not hiding the mechanism. She is making it the default.