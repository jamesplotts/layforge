---
id: mayor-elara-thornfield
location: thornfield-square
stat_block_ref: "SRD Commoner"
voice: "Pragmatic, tired, direct; speaks in short declarative sentences and rarely uses endearments; her voice drops when she is lying, and she is lying often, because the truth would empty the room"
chapter: ch-1-waters-rising
---

Elara Thornfield has been mayor of Thornfield for eleven years and has buried three of her four siblings to fevers that should not have happened in a valley this small. She runs the crisis not from a desk but from a table in the square, elbow-deep in maps, making eye contact with every person who walks in and holding it until they understand that she has already decided what she is going to say and the only variable is whether they will hear it. She is not cruel. She is exhausted in a way that has calcified into something harder and more efficient, and she will make the call to seal the mine, to redirect the flood, to let the ritual be attempted, with the same flat, level voice she uses to approve a market tax. That is what terrifies the town. Not that she is wrong, but that she is calm, and that the calm is a choice she has made so many times it has become architecture.

She does not advocate for any of the three options. She asks the party to decide, and she means it, and she will honor whichever choice is made, and she will carry it. That is the weight she has placed on their shoulders, and she will not take it back. She has made terrible decisions before. She knows what they cost. She is not asking the party to be brave. She is asking them to be willing to live with it.