---
id: oakhaven-bridge
connections:
  - thornfield-square
chapter: ch-1-waters-rising
---

The bridge over the Thornwater is a single arch of pale stone, old enough that the local name for it — the Oakhaven Bridge — comes from a time when the village on the far side was called something else entirely. From the midpoint, the party can see the full length of the downstream valley: the river, wider now, braided with silt channels; the fields; and beyond them, the clustered roofs of Oakhaven, smoke rising from a dozen chimneys, a schoolhouse with a blue door. It looks peaceful. It looks like a postcard. It is, in Marcus Stoneheart's plan, the destination of every drop of water that cannot be stopped upstream.

A military encampment has been set up on the near side of the bridge: canvas tents, a cook fire, a row of pikes staked in the grass. Marcus's scouts are on the far side, walking the village's perimeter, talking to the elders, measuring the river's flow. The villagers are cooperative but watchful. They know what is being discussed. They can hear the water. They do not know what they are being asked to accept, and they can see the soldiers counting their houses.

The bridge itself is structurally sound but the road approaches on the far side have begun to soften where the water table has risen. If the party crosses, the ground under their feet will be less firm than it looks, and the sound of water moving under the gravel will be louder than it should be. Oakhaven is not a threat. It is a destination in someone's plan, and that distinction is the whole weight of the choice.