---
id: the-scholars-annex
connections:
  - thornfield-square
chapter: ch-1-waters-rising
---

The annex is a two-story building at the east end of the market row, its front windows stacked with rolled parchments and its back door propped open to let the smell of ink and boiling tea escape. The inside is a chaos of shelves, desks, and papers pinned to every available surface. Diagrams of the underground river network cover the walls, annotated in at least three different inks over what looks like months of work. A half-built model of the region sits on the central table, its river channels made from bent wire and its water levels marked with colored thread.

Aldous Voss works at the back desk, surrounded by a fortress of books, his sleeves rolled, his spectacles perpetually sliding down his nose. He has not slept in two days. The tea in his cup has a skin on it. He talks fast when he is anxious, which is now, always, and he corrects himself mid-sentence so often that his sentences become a kind of private language. He is not a combatant. He is not a politician. He is a man who has found a solution in a text he has read twice and who is terrified of what the solution costs, because the cost is written in the same text, in the same cramped hand, in a margin note he added three days ago and has not been able to stop rereading.

The ritual materials are in a locked cabinet under his desk. He has the key on a cord around his neck. He has not opened the cabinet. He is waiting for someone to ask, or to wait no longer. The party's presence in the annex, and what they say, will determine whether that cabinet opens.