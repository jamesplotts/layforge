---
id: the-collapsed-mine-shaft
connections:
  - thornfield-square
  - the-rusted-gatehouse
chapter: ch-1-waters-rising
---

The mine entrance is a ragged mouth in the hillside south of the square, its timber supports splintered and buckled by the tremor that brought the roof in. A barricade of planks and rope has been thrown across the opening, and beyond it, the sound of children — breathing, murmuring, one small voice singing a half-remembered lullaby — carries up through the gap in the timber with a clarity that makes the party's stomach drop. The air coming out of the shaft is warm and smells of wet clay and candle smoke.

The collapse is not total. A partial gallery remains open, just wide enough for a person to crawl through, but the far section — where the children are — is buried under perhaps forty feet of rock and water. Rescue teams have tried. Two miners are dead under the debris, pulled out cold. The water level in the lower gallery is rising, and at the current rate, it will reach the children's refuge within six days. That is the number the families are holding onto. Six days. The clock in the gatehouse says forty-eight hours. The arithmetic does not comfort anyone.

The families are camped at the base of the shaft in a long, silent row of blankets and tin cups. They do not cry anymore. That is worse. They sit in a kind of wakened, glassy quiet, watching the water drip from the timber and counting the children's voices by counting the small, indistinct sounds that come up through the rock. If the party speaks to them, they will talk for hours, and they will say the same thing over and over, and it will not stop.