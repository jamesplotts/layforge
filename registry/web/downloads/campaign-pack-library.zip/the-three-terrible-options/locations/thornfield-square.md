---
id: thornfield-square
connections:
  - the-rusted-gatehouse
  - the-collapsed-mine-shaft
  - oakhaven-bridge
  - the-scholars-annex
chapter: ch-1-waters-rising
---

Thornfield Square is a broad, flagstone courtyard ringed by timber-framed houses, a market row with its stalls half-packed in haste, and a stone well whose water table has risen three feet in the past two days. The smell is wet chalk and overturned turnip crates. Lanterns are lit early because the overcast sky has the flat, waterlogged grey of a bruise. Every bench is occupied. Every doorway has someone standing in it, watching the river gauge at the north end of the square with the particular stillness of people who have stopped panicking and started waiting.

The crisis council is held under the old elm at the square's center, its branches heavy with mud from the last tremor. Elara Thornfield stands at a rough-hewn table where she has spread maps, clay tablets, and a half-empty flask of something strong. Mirabel's choir robes are visible at the edge of the crowd, deep indigo, standing apart. Marcus's soldiers form a loose ring around the perimeter, pikes angled outward, not toward the townsfolk but toward the treeline. Voss is not here yet; he is in his annex, and his absence is felt like a held breath.

The square is the nerve center of the crisis. Every faction converges here. Every decision is announced here. The water gauge at the north end ticks upward by the hour, and when the party arrives, the number on its face will be different from what it was an hour ago. That single, silent increment is the clock the whole town is trying to ignore.