---
id: the-rusted-gatehouse
connections:
  - thornfield-square
  - the-collapsed-mine-shaft
chapter: ch-1-waters-rising
---

The Rusted Gatehouse is a squat, iron-banded structure built into the hillside above the square, its walls furred with orange mineral deposits that have stained the limestone the color of dried blood. It is older than Thornfield, older than the region's current borders, and the locals call it the Gate because, in a time no one remembers, it was said to have held something shut. A wide staircase of worn steps leads up to a double door of blackened metal, and the air around it is thin and cold in a way that has nothing to do with the weather.

Inside, the gatehouse is a single vast chamber with a low ceiling studded with carved glyphs that pulse faintly amber when the water table shifts. Mirabel's altar sits in the center: a simple stone dais, a brazier, a shelf of prayer books with water-stained spines. The choir practice space is a narrow alcove to the left. Mirabel's private quarters are behind a curtain at the back, and the party will notice the curtain is drawn even when she is not in them, as if she has sealed the room against herself.

Beneath the gatehouse, accessible through a trapdoor in the altar floor, a stair descends into the mine network. The path from here to the collapsed shaft is roughly two hundred feet of rough-hewn tunnel, the walls weeping, the air growing thick and sweet with the smell of turned earth. Mirabel knows this path by heart. She walks it every morning. She does not say what she is looking for when she walks it, and she does not need to, because the party will see the particular set of her jaw and understand.