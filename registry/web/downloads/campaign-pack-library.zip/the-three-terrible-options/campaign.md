---
id: the-weight-of-water
title: "The Weight of Water"
level_range: "3-8"
pvp_policy: pve_only
maturity_tier: standard
image_maturity_tier: family_friendly
shared_knowledge: strict
tone:
  - moral
  - tense
  - consequential
  - tragic
  - dramatic
author: AI-generated
chapters:
  - id: ch-1-waters-rising
    title: "The Setup: Waters Rising"
    level_range: "3-4"
    summary: "The party arrives in Thornfield to find a town on the brink. A magical cataclysm has unmoored the underground river, and three factions present three terrible solutions. The mayor gives them forty-eight hours to choose."
  - id: ch-2-three-roads
    title: "The Options Explored: Three Roads"
    level_range: "4-5"
    summary: "The party investigates each option in depth, speaking with trapped families, downstream villagers, and the scholars mapping the magical mechanics. Every solution hides a consequence no one expected, and pressure from all sides intensifies."
  - id: ch-3-the-hour-narrows
    title: "The Tension Build: The Hour Narrows"
    level_range: "5-6"
    summary: "Time collapses. Mirabel's true theological motive surfaces, a cave-in traps more people, and a magical surge pushes the flood to the town's edge. The deadline drops to twenty-four hours."
  - id: ch-4-what-remains
    title: "The Choice: What Remains"
    level_range: "7-8"
    summary: "The party makes its decision and bears the consequences. Whether children are sealed in the dark, a village is drowned, or the ritual is attempted and may fail, the region is forever changed and the party carries the weight of what they chose."
---

A cataclysm beneath the earth has turned the ancient underground river loose, and the town of Thornfield has forty-eight hours before the water swallows the valley. Three solutions exist, and every single one demands a sacrifice the party is not sure they can live with. This is a short, four-chapter campaign built around a single, unresolvable moral knot: there is no clean answer, no hidden fourth option, and no way to walk away.

The party is not here to slay a villain. The antagonist is arithmetic — the cold mathematics of who lives and who dies when the water must go somewhere. Mayor Elara Thornfield has tried to hold the town together through sheer will and has failed. High Priestess Mirabel stands in the gatehouse with her hands already steady, convinced that a handful of chosen lives is the price the gods demand. General Marcus Stoneheart patrols the bridge to Oakhaven with a war plan and a hunger for glory that he calls duty. Scholar Aldous Voss hunches over his notes in the annex, whispering that there is a ritual, a third way, but the cost will be measured in something the party cannot easily replace.

Each NPC is right about something. Each is wrong about what matters most. The campaign's design goal is to make the players sit in the discomfort of their choice long after the session ends. Every option has real, lasting consequences that ripple into whatever comes next. There is no undo. There is no save point. The water keeps rising either way.

## Hooks

- **The Summons.** A rider arrives at the party's door with a sealed letter: the mayor of Thornfield is calling upon every blade and wit in the valley to attend a crisis council within the hour. The water is already at the lower fields.
- **The Children's Song.** Word travels fast in a small town. The party may already have heard about the mine collapse and the fifty-odd children trapped below. A mother at the market corner will grip their arm and beg them to do *something*, anything, before the water makes the decision for them.
- **A General's Challenge.** Marcus Stoneheart has posted a proclamation on the square: any party that can present a viable alternative to his flood-redirect plan within forty-eight hours will be given command of the response. It is a dare, and it is an invitation, and he means both.
- **A Letter in the Margins.** Tucked into a scholarly journal in the local bookshop, a note in Aldous Voss's cramped hand reads: *The ritual works. I have read it twice. The cost is not what I hoped. Come to the annex before you hear it from Mirabel's choir. — A.* It is not a recruitment pitch. It is an apology in advance.
- **The Tide Clock.** In the gatehouse, a mechanical water-locked clock ticks down the hours. The town can see it. The party can see it. Everyone can hear it, and no one can stop it.