---
id: the-council-meeting
location: thornfield-square
involves:
  - mayor-elara-thornfield
  - high-priestess-mirabel
  - general-marcus-stoneheart
  - scholar-aldous-voss
chapter: ch-1-waters-rising
---

The party is summoned to the square before they have finished unpacking their gear. Elara calls the council in a voice that carries across the courtyard, and the town fills in from every alley and doorway, and the four factions take their positions: Mirabel at the gatehouse stairs, pips of amber light in the glyphs above her; Marcus at the square's north edge, his soldiers a thin line behind him; Voss arriving late, ink-stained, breathing hard, as if he has been running; and Elara at the center, her hands flat on the table, her eyes moving from one party member to the next with the steady, assessing gaze of a woman who has already decided she cannot make this choice alone.

The presentation is not a debate. Elara lays out the situation: the cataclysm, the unmoored river, the forty-eight hours. Then she gives each of the three advocates four minutes to state their case, and the party should be in the room for all of it. Mirabel speaks of the seal and the chosen and the small, necessary payment. Marcus speaks of the redirect, the operation, the controlled flood, the village as a managed consequence. Voss speaks of the ritual, the third way, the text, the cost, and then he goes quiet, and his silence is the loudest thing in the square, and Elara looks at the party and says, *You have forty-eight hours. I will not make the decision. I will not pretend I can. You decide, and I will carry it, and I will not forgive myself, and I will not ask you to.* The clock in the gatehouse ticks. The water gauge at the north end of the square reads higher than it did an hour ago. The party has their first full picture of the impossible, and the square is very quiet, and the children are still singing, faintly, up through the stone.