---
id: the-floodline-surge
location: oakhaven-bridge
involves:
  - general-marcus-stoneheart
chapter: ch-1-waters-rising
---

The party crosses the bridge to Oakhaven to speak with the villagers, and Marcus is there, as he always is, paces measured, voice level, counting houses as he walks the perimeter. The conversation with the villagers is going well. They are frightened, they are asking questions, they are trying to understand what a controlled redirect would actually look like, what the water would do to the foundations, to the schoolhouse, to the blue door, and Marcus is answering every question with the precise, careful language of a man who has done this before and does not want to do it again.

Then the surge hits. Not a flood. A pulse. The underground river, responding to some shift in the cataclysm the scholars have not yet modeled, sends a wave through the stone channels, and the water in the Thornwater rises three feet in the space of thirty seconds, and the river changes color, goes from brown to a deep, luminous amber, and the air tastes of copper and old stone. The villagers step back. Marcus does not. He stands on the bridge, water to his knees, his face unchanged, and he says, *This is what I am protecting you from. This is what happens if we don't redirect it.* The amber light fades. The water settles. But the gauge at the far side of the bridge, the one the party can see from the midpoint, has moved. Two notches. Twenty-four hours, maybe less. Marcus's option is no longer a plan. It is a deadline. And the party can see, in the amber residue on the bridge stones, that the water is not just water anymore, and that changes what the ritual costs, and what the seal holds, and what the village's name is worth.