---
id: the-childrens-cry
location: the-collapsed-mine-shaft
involves:
  - mayor-elara-thornfield
chapter: ch-1-waters-rising
---

The party reaches the mine shaft either on their own initiative or because Elara asks them to go, because she cannot, because the sound of the children has been in her ears for two days and she is not certain she can hear it again and still function. The walk from the square is short. The sound gets louder. The timber supports are black with old water and new water, and the barricade is held by a single thick rope and the particular, desperate grip of a miner who has not slept.

When the party looks into the gap, they can see the lower gallery, perhaps thirty feet down, where the candlelight flickers and the small shapes move. The children are not screaming. They are organized, in the way children organize themselves when they are scared and the adults are not there: a ring, a count, a small shared story told in whispers to keep the dark from getting in. The water is at the base of the gallery wall, maybe two inches from the floor, rising slowly, visibly, and the party can calculate, in real time, how long it will take to reach the children's heads if no one does anything.

Elara is not here. She sent the party. That is the point. She cannot be in this room. If she is in this room, she will make the decision for them, and she will seal the mine, and the children will die, and she will carry it, and the party will never know if she would have chosen differently if she hadn't been the one holding the weight. So she is not here. The party is. And the children are looking up, and one of them, the smallest, is watching the party with an expression that is not fear and not hope and something the party will spend the rest of the campaign trying to name.