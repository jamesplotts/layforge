---
id: salt-road-race
location: salt-road
involves:
  - seraphina-dusk
  - nyx-guide
chapter: competition-begins
---

The party is three days into the Salt Road, pushing hard through the salt flats, when they find the first evidence: a broken camp, still warm. A cup with lip prints. A half-eaten ration. The trail of boot prints going north, faster than theirs, heading toward Thornhaven. This is not a coincidence. This is a race.

The party reaches the midpoint of the Salt Road — the Ashwell — and finds Seraphina already there. She is drinking from the spring despite the locals' warning, and she is alone, and she is smiling. Her party is an hour ahead, at the Narrows, blocking the road. She is here because she wants to be seen. She wants the party to know she is real, that she is ahead, that the gap is real and not a rumor.

The scene is a conversation, not a combat. Seraphina's terms: she will share the location of the Ashen Gate's outer approach. In exchange, the party will not interfere with her party's passage through the Narrows. She will not share the inner mechanism. She will not explain why. She will, if pressed, say only that the Crown is not what either of them thinks it is, and that she will tell them more if they are still alive when they reach the gate.

The party can accept, refuse, or counter. If they accept, they save half a day and gain the outer approach's location. If they refuse, Seraphina leaves, and the gap widens. If they counter, she laughs, says "I like you," and offers the same terms with a single adjustment: her party will not attack the party's, but the party's will not attack hers. A ceasefire. A race with rules. The Narrows are still blocked. The gate is still ahead. And Seraphina is already walking back toward her party, and her shadow in the salt light is very long, and she does not look back.

If the party chooses to engage her directly — to challenge her, to threaten, to try to take her map — this is the moment. The Salt Road offers no cover. Her party is an hour away. Nyx, if she is with the party, will quietly step back and make herself very small and very quiet and very far from the conversation. This is not her fight. She sold the map. The rest is between them.
