---
id: thornhaven-standoff
location: thornhaven
involves:
  - seraphina-dusk
  - lord-harrington
  - nyx-guide
chapter: competition-begins
---

The party arrives in Thornhaven to find the Gilded Anvil full. The Crimson Blades are in the private room above the kitchen, and their food is on the table, and their drinks are in the glasses, and Seraphina is at the head of the table looking at the party with an expression that is not hostile, not friendly, and very clearly evaluating. Lord Harrington is in the main floor, in a corner booth, drinking black wine and speaking to the innkeeper in a low, warm voice. He sees the party. He smiles. He waves them over.

The scene is three conversations happening at once, and the party can choose which one to enter first:

**With Seraphina**: She has heard they are in town. She has a proposal. A formal one. A shared objective: open the Ashen Gate. Division of labor: her party handles the inner wards, the party's party handles the outer ones. The Crown, when it is found, belongs to the party that claimed it first. She will not say what she will do with it. She will say the words "you don't need to know yet" and mean them and not mean them at the same time. The party can accept, refuse, or negotiate. If they negotiate, she will listen. She is not used to being listened to. It will change the terms slightly in their favor.

**With Lord Harrington**: He is charming. He is warm. He is the man who shook both parties' hands and paid both parties' fees and is now sitting in a tavern in a fortress-town drinking black wine and watching two groups of adventurers argue about a dead crown. He will not confirm that he hired the Crimson Blades. He will confirm that he hired the party. He will say that the Crown's recovery is a matter of regional security, not personal profit. He will say this in a voice that is not a lie and is not the truth. If the party asks who else he hired, he will smile and say "I'm sure you already know" and mean it as a compliment.

**With Nyx**: If the party brought her, or if she is in town (she is; she has been in town for two days; she is sitting at the bar, not drinking, watching the room), she will confirm what the party suspects: the Ashen Gate's ward is not a lock. It is a binding. Something is holding the gate shut from the inside. She will not say what. She will say that the last person who asked her that question is in a cell in a castle she does not have the name of, and that she would very much like not to be in that cell, and that if the party is going to open the gate, she would very much like to be alive when it opens. She will name her price. It is reasonable. It is not the same price she named the Crimson Blades. The difference is not greed. The difference is the party.

The scene ends with the party choosing a path: cooperate with Seraphina, go it alone, or try to outmaneuver both. The gate is sealed. The Crimson Blades are here. Lord Harrington is here. Nyx is here. And the thing on the other side of the gate has been patient for a very long time, and it does not care who wins, and the equinox is twelve days away, and the salt is still on the road behind them, and the ash is still in the valley ahead.
