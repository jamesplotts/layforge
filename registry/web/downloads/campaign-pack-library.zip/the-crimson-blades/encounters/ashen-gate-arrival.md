---
id: ashen-gate-arrival
location: ashen-gate
involves:
  - seraphina-dusk
  - nyx-guide
chapter: competition-begins
---

The party rounds the last bend in the Ashen Valley and sees the gate. They also see the Crimson Blades' camp, already set up on the gate's far side, already six hours ahead. Seraphina is leaning against the gate's frame, arms crossed, watching them come. Her expression is not triumphant. It is not smug. It is the expression of a person who has been waiting for this moment for two years and is not sure what she expects to happen when it arrives.

The gate is as described: massive, black, half-buried in ash, the spiral carved into its face, the handprint at its center. The ward is visible to anyone with a modicum of magical sensitivity — a faint, slow pulse, like a heartbeat, like breathing, like something alive pressing its palm against the stone from the other side. It is not a lock. It is a holding. Something is holding it shut.

Seraphina's terms are on the table. The party has seen them in Thornhaven. They can accept them, refuse them, or make new ones. The gate does not care. The ward does not care. The thing on the other side does not care. It has been holding the gate for a century, and it will hold it for another, and the only variable in this equation is the people standing in front of it, and what they are willing to do to open it, and what they are willing to lose to open it, and whether they understand, yet, that the cost of the Crown of Ash is not the Crown. The cost is the person who holds it. The cost is the hands. The cost is the name. The cost is the face in the mine shaft that was not his face, that never was his face, that is still his face, and will be his face, and the gate is the only thing between that face and the world, and the gate is going to open, and the thing behind it is going to come out, and it is going to wear the face of someone who is not there anymore, and it is going to say a name, and the person who hears it is going to have to decide, in the space of a single breath, whether to answer.

This is where the chapter ends. The gate is sealed. The rival is here. The party is here. The thing is waiting. And Seraphina is looking at them, and her eyes are not cruel, and her hands are shaking, and she is going to open the gate, and she is going to need someone to help her, and she is going to ask, and the party is going to have to say yes or no, and the answer will be the first real choice this campaign asks of them, and the answer will be the last safe one.
