---
id: seraphina-dusk
location: thornhaven
stat_block_ref: "SRD Veteran"
voice: "Quick, warm, precise — she speaks like she's always one sentence ahead of the conversation, and the sentence she's saving is the one that changes your mind."
chapter: competition-begins
---

Seraphina Dusk is thirty-one, lean, with dark hair cut short and a scar along her jawline that she does not talk about. She is not the strongest person in her party, and she knows it. She is the fastest, the most prepared, and the most certain. Her red cloak is not a fashion choice; it is a signal, a brand, a promise that she is exactly where she says she will be. Her party — four of them, each a specialist, all of them loyal in the way that only fear-and-respect loyalty can be — move as a unit with a precision that comes from years of shared combat.

She is not evil. This is important. Seraphina lost her brother, Cael, two years ago in a collapsed mine shaft in the Thornveil highlands. She was there. She held him. She has the scar from the stone that took his hand. She has been trying to find a way to bring him back ever since, and the Crown of Ash — the one artifact in the world that speaks to the dead and commands their loyalty — is not a power grab. It is a rescue. A desperate, selfish, terrible rescue that she has been planning for two years and that she will not explain to the party unless she has to.

Her alliance offer is genuine in the sense that she means every word of it. She will share information. She will coordinate. She will, if the party agrees, let them have first claim on the Crown's outer wards while her party handles the inner ones. What she does not say — what she will not say, not yet, not until she has no other choice — is that the Crown is not a key. It is a door. And the thing that comes through that door is not her brother. It is something older, something that wore his face in the mine shaft and is still wearing it, and Seraphina is going to open that door because the alternative is that Cael is gone, and she will not accept that, not yet, not while there is a handprint on a gate and a name in a script she cannot read and a patron who is watching from a safe distance and smiling.

She is the party's rival. She is also the person the party will, at the end of this campaign, have to decide whether to help, hinder, or let go. She deserves that decision. She has earned it.
