---
id: nyx-guide
location: vaelmoor
stat_block_ref: "SRD Scout"
voice: "Dry, economical, slightly amused — she speaks in half-sentences and lets the silence do the talking, and her silences are always longer than they need to be."
chapter: competition-begins
---

Nyx is a scout, a cartographer, and a seller of information. She is not a thief, not a spy, not a mercenary. She is a person who knows where things are and how to get there, and she will tell you, for the right price, which of those two facts you need most. She is small, quick, and dresses in the unremarkable grey-brown that lets her stand in any crowd and become part of it. She has been walking the Thornveil roads for eleven years. She has been walking them longer than the town of Vaelmoor has been a town. She knows things about the Ashen Valley that Oren, the cautious mage, does not want to hear, and she has not told anyone in over a decade because the last person she told her the truth to is dead, and the person before that is dead, and the person before that is in a cell in a castle she does not have the name of.

She is selling the Crown's location to the highest bidder. This is not a moral failing. This is her trade. She does not care who wins. She cares that the person who wins pays her, and that the person who pays her is alive, because dead people do not pay, and she has a daughter in a town four days' ride from here who is eating well this month because of it. The Crimson Blades offered first. She took their gold. She will now, if the party offers more, take their gold too. She will tell both parties the same information. She will tell them different information if she thinks one of them is more likely to survive the journey. She is not trustworthy. She is not untrustworthy. She is a person with a price and a daughter and a long memory of people who did not pay.

When Seraphina captures her in Chapter Two, it is not cruelty. It is leverage. Seraphina needs the gate's inner mechanism, and Nyx is the only person who knows it, and Seraphina will not let her die because dead people do not pay and Cael is still in the mine shaft and the door is still closed and the time is running out. Nyx, for her part, will cooperate. She has cooperated with worse. She will keep her daughter's name to herself and her price to herself and her fear to herself, and she will tell Seraphina exactly what she needs to know, because the alternative is a cell in a castle she does not have the name of, and she is not going back there.
