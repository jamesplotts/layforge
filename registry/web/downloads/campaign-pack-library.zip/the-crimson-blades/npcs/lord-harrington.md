---
id: lord-harrington
location: vaelmoor
stat_block_ref: "SRD Noble"
voice: "Polished, warm, faintly amused — a man who has never needed to raise his voice and finds it charming when others must."
chapter: competition-begins
---

Lord Aldric Harrington is a man of fifty-three, broad-shouldered, clean-shaven, with the kind of handsome face that photographs well in the court paintings he commissions. He dresses simply for a noble — dark wool, no jewels, good boots — and speaks as though every conversation is a minor performance he has already rehearsed. He is not cruel. That is what makes him dangerous. He is efficient, and he is patient, and he believes, with the calm certainty of a man who has never been wrong publicly, that he is the cleverest person in any room he enters.

He hired both parties because it is the cheapest, safest way to retrieve the Crown of Ash. He does not need to go into the ruin himself. He does not need to face the ward, the binding, the thing that has held the gate for a century. He needs someone else to do it, and he needs them to do it at the same time, because two parties racing the same goal will push harder, move faster, and — when the thing in the ruin finally opens — they will be the ones standing in front of it, not him.

He is not a villain in the way the party will expect. He is a patron. He is a client. He is the man who signs the contract and shakes your hand and means it, and whose hand is warm, and whose eyes are not. His true goal is not the Crown's power. His true goal is to be the one who decided it was taken, from a safe distance, with no blood on his hands and a ledger to prove it was someone else's choice. He will be in Thornhaven when the party arrives. He will not be at the gate. This is, he believes, the correct arrangement.
