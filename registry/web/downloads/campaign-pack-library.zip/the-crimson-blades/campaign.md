---
id: crown-of-ash-race
title: "The Crown of Ash"
level_range: "3-8"
pvp_policy: pvp_allowed
maturity_tier: standard
image_maturity_tier: family_friendly
shared_knowledge: standard
tone:
  - competitive
  - tense
  - morally complex
  - urgent
author: AI-generated
chapters:
  - id: competition-begins
    title: "The Competition Begins"
    level_range: "3-4"
    summary: "Hired by Lord Harrington to retrieve the Crown of Ash from an ancient ruin, the party discovers The Crimson Blades — a well-funded rival crew led by Seraphina Dusk — are racing them on the same trail. Early encounters establish the dynamic: competition, wary cooperation, or open conflict. Seraphina extends a suspicious alliance offer, and the party reaches the Ashen Gate behind schedule."
  - id: race-intensifies
    title: "The Race Intensifies"
    level_range: "4-6"
    summary: "The Crimson Blades sabotage the party's progress and reach a key waypoint first. The party uncovers Seraphina's true motive — resurrection of a lost loved one — and learns both parties were hired by the same man, Lord Harrington, who intends to claim the Crown himself. Cliffhanger: Seraphina captures Nyx the Guide and forces the Crown's exact location from her."
  - id: the-convergence
    title: "The Convergence"
    level_range: "6-8"
    summary: "Both parties arrive at the ruin simultaneously. A confrontation, negotiation, or combined assault follows. The Crown of Ash's true curse is revealed — it does not merely grant power over the dead, it consumes the wielder. Cliffhanger: Seraphina claims the Crown and begins to transform into something the party can no longer negotiate with."
  - id: the-resolution
    title: "The Resolution"
    level_range: "8"
    summary: "The final confrontation: defeat the transformed rival party, work alongside them to break the Crown's curse, or outmaneuver Lord Harrington who has followed them to the ruin. The party's choices shape what the region becomes — a freed soul, a buried curse, or a new power playing the same old game."
---

# The Crown of Ash

In the coastal marches of the Thornveil region, an old crown sleeps beneath a collapsed temple. For three centuries it has waited, patient as rust. Now two adventuring parties are racing toward it, hired by the same smiling lord who expects neither to survive the attempt. The party the players lead is competent, scrappy, and underfunded. The party racing ahead of them — The Crimson Blades, led by the magnetic and ruthless Seraphina Dusk — has gold, intelligence, and a personal grief that will bend every rule she was taught to follow.

This is a campaign about the space between enemies and allies. Every scene with the Crimson Blades can shift from competition to cooperation to betrayal depending on the players' choices. Seraphina is not a villain; she is a person doing a terrible, loving, selfish thing. Lord Harrington is a man who treats people as tools and expects the tools to thank him. The Crown of Ash is not a MacGuffin; it is a wound in the world, and claiming it is a decision with a cost the party must understand before it is too late.

The campaign is paced in four chapters, each roughly one level of progression. The rival party should always feel like a genuine threat — not a stat block, not a plot device, but a group of people with the same goal, better resources, and a leader whose motivations the players may, at some point, understand too well.

## Hooks

- **The Summons**: Lord Harrington's seal arrives at the party's last town. A courier delivers a letter that is polite, generous, and faintly threatening. The Crown of Ash must be recovered before the autumn equinox. Payment is triple the going rate. The catch: another party has already been contracted.
- **The Guide's Warning**: Nyx, a wandering scout who knows the old roads into the ruin, tells the party the Crown "eats the hands that hold it." She will sell her knowledge to the highest bidder — and the Crimson Blades are already asking.
- **The Rival's Offer**: Seraphina Dusk finds the party at a crossroads, uninvited, smiling. "We're both going to the same place. Let me save you the trouble of dying on the road." Her terms are generous. Her smile is not.
- **The Patron's Chess Game**: A single overheard conversation — two servants, one lord — reveals that Harrington expects both parties to fail, and has already arranged the ruin's collapse for the equinox. The Crown was never meant to be retrieved. It was meant to be freed from the ruin's seal. Both parties are the lockpick and the lock, and the Crown is what lives behind the door.
