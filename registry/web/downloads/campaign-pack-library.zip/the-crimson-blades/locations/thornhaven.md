---
id: thornhaven
connections:
  - salt-road
  - ashen-gate
chapter: competition-begins
---

Thornhaven is a fortress-town carved into the basalt cliffs above the Ashen Valley. Its houses are built into the rock face in tiers, connected by iron stairs and rope bridges. The town was founded three centuries ago by a guild of mine-workers who found the old temple ruins at the valley's bottom and decided to live above them rather than near them. The town's economy is salt, iron, and the steady stream of would-be treasure-seekers who come looking for the Crown of Ash and leave with a bill at the Gilded Anvil tavern and a very strong opinion about the value of going home.

The Gilded Anvil is where the party will meet Seraphina. It is a large, loud, well-lit establishment that seats forty. The Crimson Blades have taken the private room above the kitchen — the one with the iron shutters — and have been drinking there for two days. Their table is visible from the main floor: five seats, five empty chairs, and a spread of food that costs more than the tavern's daily take. Seraphina sits at the head, and she has noticed the party the moment they walked in. She has been waiting, or she was not, and her expression will not say which.

The town's other key figure is the blacksmith, a broad woman named Dora Kael, who will sell the party tools, repair their gear, and tell them, for a silver and a nod, that the last person who asked about the Ashen Gate's inner chambers was a woman in red who paid in gold. Dora does not say whose gold. She does not need to.

South of Thornhaven, the basalt gives way to the Ashen Valley, a long defunct river channel choked with ash-grey soil and the broken columns of the old temple. The approach to the Ashen Gate is a half-mile walk through dead trees, and the gate itself is a massive stone arch, half-collapsed, covered in a script that no one in town can read. The gate is sealed. It has been sealed, by the town's count, for forty-one years. Something on the other side keeps it that way.
