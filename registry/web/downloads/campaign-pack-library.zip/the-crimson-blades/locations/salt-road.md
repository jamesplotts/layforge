---
id: salt-road
connections:
  - vaelmoor
  - thornhaven
chapter: competition-begins
---

The Salt Road is a six-day stretch of white, cracked earth between Vaelmoor and Thornhaven. It crosses the Thornveil marshes' eastern edge, where the ground is soft and the air tastes of brine and old iron. The road itself is a packed track, barely wider than two cartwheels, flanked by salt-crusted scrub and the occasional dead tree standing like a finger pointed at the sky. At the midpoint, the road passes the Ashwell — a shallow spring that the local guidebook calls "drinkable" and the locals call "don't."

This is where the two parties will first share air. The Salt Road is long, exposed, and offers little cover. A confrontation here is a confrontation in the open, where every blow is visible to anyone traveling the next day. A negotiation here is a negotiation in the open, where trust is thin and the sun is not your friend.

The terrain favors the better-prepared. The Crimson Blades, with their mules and their supply train and their map (Nyx's map, paid for in advance), will cover the distance in three days. The party, on foot or on slower transport, will need four or five. That half-day gap is the seed of everything that follows: the Crimson Blades will always arrive first, and the party will always be the ones catching up, finding the camp broken, the trail cold, the evidence of another's passage still warm in the dust.

At the road's northern end, the salt flats give way to the black basalt of the Thornveil highlands, and the road narrows to a single track between two rock walls. This is the Narrows, and it is the only point where the Salt Road can be blocked. The Crimson Blades know this. The party will discover it when they are already on the wrong side.
