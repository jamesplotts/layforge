---
id: vaelmoor
connections:
  - salt-road
chapter: competition-begins
---

Vaelmoor sits in a wide river valley where the Thornveil marshes thin into farmland. It is a trading town of maybe two hundred souls, built around a stone bridge over the River Kael and a market square that smells of fish smoke and cheap ale. The architecture is practical: timber frames, slate roofs, narrow streets that widen only where a cart can turn. It is not a place where adventurers are expected, which is why the arrival of two armed parties within the same week has made the local innkeeper very nervous and very profitable.

Lord Harrington does not live here, but his interests do. A modest stone manor on the eastern ridge — the Duskwater Estate, as the town calls it — houses his steward, a handful of guards, and a cellar the townsfolk insist is much deeper than the foundation should allow. Harrington himself was in town three days ago, charming, well-dressed, generous with coin. The steward, a thin man named Pell, is not charming, and he is not generous, and he will deliver the commission to the party in a back office that smells of ink and anxiety.

The road out of Vaelmoor to the south follows the riverbank for two miles before it climbs into the salt flats. Travelers can see the Thornveil ruins on a clear day — dark shapes on the horizon like broken teeth. No one in town has been there in over a decade. The last expedition, a company of six, came back with three and none of their equipment. The town remembers this. The town talks about it in the low voice people use for things that might still be true.
