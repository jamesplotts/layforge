---
id: ashen-gate
connections:
  - thornhaven
chapter: competition-begins
---

The Ashen Gate is the threshold. It is not, strictly speaking, a ruin — it is a door. A massive, two-ton slab of black basalt set into a frame of older, rougher stone, half-buried in a field of grey ash and the skeletal remains of trees that grew here before the temple was built and will not grow here again. The gate's surface is carved with a spiral pattern that seems to move at the edge of vision, and at its center is a depression shaped exactly like a handprint. The script around the spiral is the same language as the temple's inner walls, if the temple's inner walls are to be believed, which is to say, no one has seen them in forty-one years.

The gate is sealed by a ward that the town's best mage — a cautious man named Oren, who lives in a small cottage at the top of Thornhaven and refuses all commissions involving the Ashen Valley — has identified as a binding. Not a lock. A binding. Something is holding the gate shut from the inside, and it has been holding for over a century. Oren will not say what. Oren will say, very firmly, that the party should not be here, and that he means it as a courtesy.

The Crimson Blades are already here. Their camp is visible on the gate's far side — a half-mile into the Ashen Valley — tents, a watchfire, and the glint of Seraphina's red cloak in the early light. They arrived six hours before the party. They have already tried the handprint. They have already failed. And Seraphina, who is leaning against the gate's frame with her arms crossed and her eyes on the party as they round the last bend in the valley, has a look on her face that is not quite a smile and is definitely not a welcome.

This is where Chapter One ends. The gate is sealed. The rival is here first. The party is here second. And the thing on the other side has been waiting a very long time, and it is patient, and it does not care who wins.
